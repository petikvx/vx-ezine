
/**************************************************************************

 WSOCK32  redirector/logger

 **************************************************************************/

#include "registry.cpp"

void cdecl log(char* format, ...);
char* wsaerrmsg();
char* af_str(int af);
char* proto_str(int proto);
char* type_str(int type);
char* ioctlcmdstr(int cmd);
char* flagstr(int flags);
char* optnamestr(int optname);

