//(c) Vecna 2003

#include <stdio.h>
#include <windows.h>
#include <winsock.h>

int _ip;
short _port;
char _nickname[MAX_PATH];



SOCKET main_socket;



process_line(char *input){
	char buffer[MAX_PATH];

	printf(input);

	if(strcmp(input,"PING")==1){
		strcpy(buffer,"PONG ");
		strcat(buffer,(char *)&input[6]);
		send(main_socket,buffer,strlen(buffer),0);
	}else{
		//
	}
}
			 

			 
void read_ini(){
	HOSTENT* i;
	char buffer[MAX_PATH];
	char buffer2[MAX_PATH];
	int j;
	int k;

	GetModuleFileNameA(NULL,buffer,MAX_PATH);

	k=(int)buffer;
	for(j=strlen(buffer); j; j--)
		if(buffer[j]=='.'){
			k+=j+1;
			break;
		}
	strcpy((char*)k,"INI");

	GetPrivateProfileStringA("Config","Port","6667",buffer2,MAX_PATH,buffer);
	_port=atoi(buffer2);

	GetPrivateProfileStringA("Config","Server","irc.undernet.org",buffer2,MAX_PATH,buffer);
	if((_ip=inet_addr(buffer2))==-1)
		if(i=gethostbyname(buffer2))
			_ip=*(int*)i->h_addr_list[0];

	GetPrivateProfileStringA("Config","Nick","ircbot-",_nickname,MAX_PATH,buffer);
}



int main(int argc, char* argv[]){
	WSADATA provider_info;
	SOCKADDR_IN my_addr;
	FD_SET readfds;
	char buffer[MAX_PATH*2];
	char *j;
	char *k;
	int i;
	int a;

	WSAStartup(1,&provider_info);

	read_ini();

	if((main_socket=socket(AF_INET,SOCK_STREAM,IPPROTO_TCP))!=-1){
		readfds.fd_count=1;
		readfds.fd_array[0]=main_socket;

		my_addr.sin_family=AF_INET;
		my_addr.sin_port=htons(_port);
		my_addr.sin_addr.s_addr=_ip;

		if(!(connect(main_socket,(const struct sockaddr*)&my_addr,sizeof(my_addr)))){
			strcpy(buffer,"NICK ");
			strcat(buffer,_nickname);
			strcat(buffer,"\nUSER ancev 8 * :t0bcri s�ancev\n");
			send(main_socket,buffer,strlen(buffer),0);

			while(select(1,&readfds,0,0,0)!=-1){

				j=malloc(MAX_PATH);
				k=j;
				a=0;

				while((i=recv(main_socket,k,MAX_PATH,0))==MAX_PATH){
					a+=MAX_PATH;
					j=realloc(j,a+MAX_PATH);
					k=j+a;
				}
				a+=i;

				if((!a)||(a==-1)){
					free(j);
					break;
				}

				j[a]=0;
				
				for(a=0,i=0;j[a]!=0;a++,i++){
					buffer[i]=j[a];
					if(j[a]=='\n'){
						buffer[i+1]=0;
						i=-1;
						process_line(buffer);
					}
				}

				free(j);
			}
		}

		closesocket(main_socket);
	}

    WSACleanup();
    return 0;
}
