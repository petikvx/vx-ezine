#!/bin/sh
nasm -o antivir -l antivir.lst antivir.s
chmod +x antivir