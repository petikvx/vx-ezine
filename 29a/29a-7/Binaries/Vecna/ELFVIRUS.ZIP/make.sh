#!/bin/sh
nasm -o vir -l vir.lst vir.s
chmod +x vir