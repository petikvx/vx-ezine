#ifndef _SYNC_SCO_H_
#define _SYNC_SCO_H_

void scodos_main(void);

#endif
