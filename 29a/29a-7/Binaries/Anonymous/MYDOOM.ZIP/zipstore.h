#ifndef _SYNC_ZIPSTORE_H_
#define _SYNC_ZIPSTORE_H_

int zip_store(char *in, char *out, char *store_as);

#endif
