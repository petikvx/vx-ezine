#ifndef _SYNC_XSMTP_H_
#define _SYNC_XSMTP_H_

int smtp_send(struct mxlist_t *primary_mxs, char *message);

#endif
