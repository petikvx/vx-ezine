//(c) uNdErX
//that's the opcode type table

#define O_UNIQUE    0
#define O_PREFIX    1
#define O_IMM8      2
#define O_IMM16     3
#define O_IMM24     4
#define O_IMM32     5
#define O_IMM48     6
#define O_MODRM     7
#define O_MODRM8    8
#define O_MODRM32   9
#define O_EXTENDED 10
#define O_WEIRD    11
#define O_ERROR    12

unsigned char typedef BYTE;

                 // Normal Opcodes
BYTE ttbl[128] = {((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 03
                  ((O_IMM8   << 4)|(O_IMM32))  , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 07
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 0B
                  ((O_IMM8   << 4)|(O_IMM32))  , ((O_UNIQUE << 4)|(O_EXTENDED)), // 0F
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 13
                  ((O_IMM8   << 4)|(O_IMM32))  , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 17
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 1B
                  ((O_IMM8   << 4)|(O_IMM32))  , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 1F
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 23
                  ((O_IMM8   << 4)|(O_IMM32))  , ((O_PREFIX << 4)|(O_UNIQUE)),   // 27
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 2B
                  ((O_IMM8   << 4)|(O_IMM32))  , ((O_PREFIX << 4)|(O_UNIQUE)),   // 2F
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 33
                  ((O_IMM8   << 4)|(O_IMM32))  , ((O_PREFIX << 4)|(O_UNIQUE)),   // 37
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 3B
                  ((O_IMM8   << 4)|(O_IMM32))  , ((O_PREFIX << 4)|(O_UNIQUE)),   // 3F
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 43
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 47
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 4B
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 4F
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 53
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 57
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 5B
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 5F
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_MODRM  << 4)|(O_MODRM)),    // 63
                  ((O_PREFIX << 4)|(O_PREFIX)) , ((O_PREFIX << 4)|(O_PREFIX)),   // 67
                  ((O_IMM32  << 4)|(O_MODRM32)), ((O_IMM8  << 4)|(O_MODRM8)),    // 6B
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 6F
                  ((O_IMM8   << 4)|(O_IMM8))   , ((O_IMM8   << 4)|(O_IMM8)) ,    // 73
                  ((O_IMM8   << 4)|(O_IMM8))   , ((O_IMM8   << 4)|(O_IMM8)) ,    // 77
                  ((O_IMM8   << 4)|(O_IMM8))   , ((O_IMM8   << 4)|(O_IMM8)) ,    // 7B
                  ((O_IMM8   << 4)|(O_IMM8))   , ((O_IMM8   << 4)|(O_IMM8)) ,    // 7F
                  ((O_MODRM8 << 4)|(O_MODRM32)), ((O_MODRM8 << 4)|(O_MODRM8)),   // 83
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 87
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 8B
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 8F
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 93
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 97
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_IMM48  << 4)|(O_UNIQUE)),   // 9B
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 9F
                  ((O_IMM32  << 4)|(O_IMM32))  , ((O_IMM32  << 4)|(O_IMM32)),    // A3
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // A7
                  ((O_IMM8   << 4)|(O_IMM32))  , ((O_UNIQUE << 4)|(O_UNIQUE)),   // AB
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // AF
                  ((O_IMM8   << 4)|(O_IMM8))   , ((O_IMM8   << 4)|(O_IMM8)) ,    // B3
                  ((O_IMM8   << 4)|(O_IMM8))   , ((O_IMM8   << 4)|(O_IMM8)) ,    // B7
                  ((O_IMM32  << 4)|(O_IMM32))  , ((O_IMM32  << 4)|(O_IMM32)),    // BB
                  ((O_IMM32  << 4)|(O_IMM32))  , ((O_IMM32  << 4)|(O_IMM32)),    // BF
                  ((O_MODRM8 << 4)|(O_MODRM8)) , ((O_IMM16  << 4)|(O_UNIQUE)),   // C3
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM8 << 4)|(O_MODRM32)),  // C7
                  ((O_IMM24  << 4)|(O_UNIQUE)) , ((O_IMM16  << 4)|(O_UNIQUE)),   // CB
                  ((O_UNIQUE << 4)|(O_IMM8))   , ((O_UNIQUE << 4)|(O_UNIQUE)),   // CF
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // D3
                  ((O_IMM8   << 4)|(O_IMM8))   , ((O_UNIQUE << 4)|(O_UNIQUE)),   // D7
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // DB
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // DF
                  ((O_IMM8   << 4)|(O_IMM8))   , ((O_IMM8   << 4)|(O_IMM8)) ,    // E3
                  ((O_IMM8   << 4)|(O_IMM8))   , ((O_IMM8   << 4)|(O_IMM8)) ,    // E7
                  ((O_IMM32  << 4)|(O_IMM32))  , ((O_IMM48  << 4)|(O_IMM8)) ,    // EB
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // EF
                  ((O_PREFIX << 4)|(O_UNIQUE)) , ((O_PREFIX << 4)|(O_PREFIX)),   // F3
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_WEIRD  << 4)|(O_WEIRD)),    // F7
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // FB
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_MODRM  << 4)|(O_MODRM))};   // FF

                  // Extended Opcodes
BYTE etbl[128] = {((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 03
                  ((O_ERROR  << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 07
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 0B
                  ((O_ERROR  << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_ERROR)),    // 0F
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 13
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 17
                  ((O_UNIQUE << 4)|(O_ERROR))  , ((O_ERROR  << 4)|(O_ERROR)),    // 1B
                  ((O_ERROR  << 4)|(O_ERROR))  , ((O_ERROR  << 4)|(O_ERROR)),    // 1F
                  ((O_IMM8   << 4)|(O_IMM8))   , ((O_IMM8   << 4)|(O_IMM8)) ,    // 23
                  ((O_IMM8   << 4)|(O_ERROR))  , ((O_IMM8   << 4)|(O_ERROR)),    // 27
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 2B
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 2F
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // 33
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_ERROR  << 4)|(O_ERROR)),    // 37
                  ((O_ERROR  << 4)|(O_ERROR))  , ((O_ERROR  << 4)|(O_ERROR)),    // 3B
                  ((O_ERROR  << 4)|(O_ERROR))  , ((O_ERROR  << 4)|(O_ERROR)),    // 3F
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 43
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 47
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 4B
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 4F
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 53
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 57
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 5B
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 5F
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 63
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 67
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 6B
                  ((O_ERROR  << 4)|(O_ERROR))  , ((O_MODRM  << 4)|(O_MODRM)),    // 6F
                  ((O_MODRM8 << 4)|(O_MODRM8)) , ((O_MODRM8 << 4)|(O_MODRM8)),   // 73
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_UNIQUE)),   // 77
                  ((O_ERROR  << 4)|(O_ERROR))  , ((O_ERROR  << 4)|(O_ERROR)),    // 7B
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 7F
                  ((O_IMM32  << 4)|(O_IMM32))  , ((O_IMM32  << 4)|(O_IMM32)),    // 83
                  ((O_IMM32  << 4)|(O_IMM32))  , ((O_IMM32  << 4)|(O_IMM32)),    // 87
                  ((O_IMM32  << 4)|(O_IMM32))  , ((O_IMM32  << 4)|(O_IMM32)),    // 8B
                  ((O_IMM32  << 4)|(O_IMM32))  , ((O_IMM32  << 4)|(O_IMM32)),    // 8F
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 93
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 97
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 9B
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // 9F
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_MODRM)),    // A3
                  ((O_MODRM8 << 4)|(O_MODRM))  , ((O_ERROR  << 4)|(O_ERROR)),    // A7
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_MODRM)),    // AB
                  ((O_MODRM8 << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // AF
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // B3
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // B7
                  ((O_ERROR  << 4)|(O_UNIQUE)) , ((O_MODRM8 << 4)|(O_MODRM)),    // BB
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // BF
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // C3
                  ((O_MODRM8 << 4)|(O_MODRM8)) , ((O_MODRM8 << 4)|(O_MODRM)),    // C7
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // CB
                  ((O_UNIQUE << 4)|(O_UNIQUE)) , ((O_UNIQUE << 4)|(O_UNIQUE)),   // CF
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // D3
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_ERROR  << 4)|(O_MODRM)),    // D7
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // DB
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // DF
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // E3
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_ERROR  << 4)|(O_MODRM)),    // E7
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // EB
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // EF
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // F3
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // F7
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_MODRM)),    // FB
                  ((O_MODRM  << 4)|(O_MODRM))  , ((O_MODRM  << 4)|(O_UNIQUE))};  // FF

