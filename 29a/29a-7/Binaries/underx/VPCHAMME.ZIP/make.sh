#!/bin/sh
fasm vpchammer.s vpchammer