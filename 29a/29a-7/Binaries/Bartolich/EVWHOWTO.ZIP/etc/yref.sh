#!/bin/sh
[ -n "${SGML_CATALOG_FILES}" ] \
|| export SGML_CATALOG_FILES=/etc/sgml/xml-docbook.cat
[ -f "${SGML_CATALOG_FILES}" ] || exit 1

xslt()
{
  xsltproc --catalogs --nonet --output ${2}/yref/yref.xml \
  	etc/yref-${1}.xslt ${1}/main.xml \
  && mv -f ${2}/yref/yref.xml ${2}/yref.xml
}
 
xslt platform intro
xslt intro platform
