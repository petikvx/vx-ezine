#!/bin/sh
[ -n "${SGML_CATALOG_FILES}" ] \
|| export SGML_CATALOG_FILES=/etc/sgml/xml-docbook.cat
[ -f "${SGML_CATALOG_FILES}" ] || exit 1
 
for dir in intro platform; do
  xsltproc --catalogs etc/titles.xslt ${dir}/main.xml > out/${dir}.titles
done
