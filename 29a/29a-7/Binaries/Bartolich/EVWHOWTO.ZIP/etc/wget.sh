#!/bin/sh
#
# last modification 2002-05-20
#
format="+%Y-%m-%d"

today=${1:-$( date ${format} )}
yesterday=$( date ${format} -d "${today} 1 day ago" )
master=http://virus.enemy.org/archive
archive=public_html/archive

function one_day()
{
  local today=$1
  local html=virus-writing-HOWTO-${today}.html.tar.gz
  local src=virus-writing-HOWTO-${today}.tar.gz

  if [ -e $HOME/${archive}/${html} ]; then
    echo "Nothing to do."
    return 0
  fi
  if cd $HOME/${archive}; then
    wget -c ${master}/${html} ${master}/${src}
    if [ -e $HOME/${archive}/${html} ]; then
      if cd ${HOME}/public_html; then
	rm -rf virus-writing-HOWTO
	tar zxf $HOME/${archive}/${html}

	[ -e ${HOME}/.forward ] && mail $(whoami) -s wget < $HOME/log
	rm $HOME/log
	return 0
      fi
    fi
  fi
  return 1
}

one_day ${today} || one_day ${yesterday} 
