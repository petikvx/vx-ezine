#include "src/one_step_closer/trace_infector.h"
#include "src/one_step_closer/prefix.inc"

#include "src/doing_it_in_c/write_infection.inc"
#include "src/one_step_closer/suffix.inc"

#include "src/segment_padding/new_entry_addr.inc"
#include "src/segment_padding/patch_phdr.inc"
#include "src/segment_padding/patch_shdr.inc"
#include "src/segment_padding/copy_and_infect.inc"
