#!/bin/sh
${TEVWH_PATH_FILE} /var/lib/rpm/*
${TEVWH_PATH_DU} -s /var/lib/rpm
