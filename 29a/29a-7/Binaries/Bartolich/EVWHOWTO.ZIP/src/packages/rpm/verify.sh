#!/bin/sh
${TEVWH_PATH_RPM} -qf /etc/profile
${TEVWH_PATH_RPM} --verify bash
${TEVWH_PATH_ECHO} status=$?
${TEVWH_PATH_RPM} --verify -f /etc/profile
${TEVWH_PATH_ECHO} status=$?
