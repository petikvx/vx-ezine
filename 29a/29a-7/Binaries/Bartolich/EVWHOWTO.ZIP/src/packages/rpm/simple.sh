#!/bin/sh
${TEVWH_PATH_RPM} -qf $( which perl )
