#!/bin/sh
isainfo -v
