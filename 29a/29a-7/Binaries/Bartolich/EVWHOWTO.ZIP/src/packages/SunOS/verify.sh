#!/bin/sh
pkg=$( ${TEVWH_PATH_PKGCHK} -l -p /etc/profile \
| ${TEVWH_PATH_GREP} -v '^[A-Z]' )
${TEVWH_PATH_ECHO} pkg=[${pkg}]
${TEVWH_PATH_PKGCHK} ${pkg} 2>&1 | ${TEVWH_PATH_SED} 11q
${TEVWH_PATH_ECHO} status=$?
