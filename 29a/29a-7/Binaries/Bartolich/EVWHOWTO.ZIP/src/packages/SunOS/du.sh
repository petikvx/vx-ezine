#!/bin/sh
${TEVWH_PATH_FILE} /var/sadm/* | ${TEVWH_PATH_EXPAND} -t 32
${TEVWH_PATH_LS} -l /var/sadm/install/contents
${TEVWH_PATH_DU} -s /var/sadm/pkg /var/sadm/install
