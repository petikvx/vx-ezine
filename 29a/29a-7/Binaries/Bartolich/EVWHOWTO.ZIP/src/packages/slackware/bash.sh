#!/bin/sh
for file in /var/log/packages/bash*; do
  ${TEVWH_PATH_ECHO} "Searching ${file} ..."
  ${TEVWH_PATH_GREP} bin/bash ${file}
done
