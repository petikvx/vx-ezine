#!/bin/sh
# We need this script to copy the id-file into directory out/.
# I use many machines to test examples, but only one to render the document.

${TEVWH_PATH_CAT} ${TEVWH_PATH_DISTID}
