#!/bin/sh
file=$( which perl )
cmd="${TEVWH_PATH_DPKG} -S ${file}"

while file=$( ${TEVWH_PATH_READLINK} ${file} ); do
  cmd="${cmd} ${file}"
done

${TEVWH_PATH_ECHO} ${cmd}
${cmd}
