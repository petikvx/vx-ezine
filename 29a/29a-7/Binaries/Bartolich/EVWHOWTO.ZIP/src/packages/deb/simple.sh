#!/bin/sh
${TEVWH_PATH_DPKG} -S $( which sed )
