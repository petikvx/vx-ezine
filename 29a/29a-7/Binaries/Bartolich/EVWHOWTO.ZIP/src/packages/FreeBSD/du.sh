#!/bin/sh
${TEVWH_PATH_FILE} /var/db/pkg/* | grep -v 'directory$'
${TEVWH_PATH_DU} -s /var/db/pkg
