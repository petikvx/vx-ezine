#!/bin/sh
file=$( which vim )
package=$( ${TEVWH_PATH_PKG_INFO} -qW ${file} )

${TEVWH_PATH_PKG_INFO} -qv ${package} \
| ${TEVWH_PATH_SED} -ne '/^@comment MD5:/,$ p' \
| ${TEVWH_PATH_SED} 10q
