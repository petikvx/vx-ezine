#!/bin/sh
${TEVWH_PATH_MAN} -w 2 kill
