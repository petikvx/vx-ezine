#!/bin/sh
file=${1:-${TEVWH_TMP}/magic_elf/magic_elf}
${TEVWH_PATH_GDB} ${file} -q <<EOT
	break main
	run
	backtrace
	printf "esp=%08x ebp=%08x\n", \$esp, \$ebp
	x/3xw \$sp
	x/3xw \$sp + 12
	x/3xw \$sp + 24
	x/3xw \$sp + 36
EOT
