#!/bin/sh
( src/stub_revisited/intel.sh "$@" 2>&1 ) \
| ${TEVWH_PATH_SED} /ret/q \
| ${TEVWH_PATH_TAIL}
