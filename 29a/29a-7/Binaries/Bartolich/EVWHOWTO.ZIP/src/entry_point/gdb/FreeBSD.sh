#!/bin/sh
${TEVWH_PRE}/entry_point/gdb_core.sh \
| ${TEVWH_PATH_SED} '/<exit>/q' \
| ${TEVWH_PRE}/magic_elf/gdb_format.pl
