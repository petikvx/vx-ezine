#!/bin/sh
${TEVWH_PRE}/entry_point/gdb_core.sh \
| ${TEVWH_PATH_SED} -ne '/\<call\>/,/\<restore\>/p' \
| ${TEVWH_PRE}/magic_elf/gdb_format.pl
