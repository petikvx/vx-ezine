#!/bin/sh
shell=$( ${TEVWH_PATH_SED} 1q \
	${TEVWH_OUT}/scanner/segment_padding/infect )
${TEVWH_PATH_ECHO} "${shell}"
${TEVWH_PATH_LDD} ${TEVWH_PATH_SH}	
