#!/bin/sh
${TEVWH_TMP}/evil_magic/e_entry \
	${TEVWH_PATH_SH} \
	${TEVWH_TMP}/one_step_closer/e1i1/sh_infected \
	${TEVWH_TMP}/one_step_closer/e2i1/sh_infected

