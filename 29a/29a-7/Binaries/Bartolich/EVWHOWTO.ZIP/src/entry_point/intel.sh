#!/bin/sh
shell=$( ${TEVWH_PATH_SED} 1q \
	${TEVWH_OUT}/scanner/segment_padding/infect )
[ -x "${shell}" ] || exit -1

${TEVWH_TMP}/evil_magic/e_entry ${shell} \
| while read entry_point offset
do
  ${TEVWH_PATH_NDISASM} -e "${offset}" -o "0x${entry_point}" -U "${shell}" \
  | ${TEVWH_PATH_PERL} -ne "print $_; exit if m/\b${TEVWH_ASM_RETURN}\b/;"
done
