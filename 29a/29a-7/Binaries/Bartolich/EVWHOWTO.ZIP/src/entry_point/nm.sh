#!/bin/sh
shell=$( ${TEVWH_PATH_SED} 1q \
        ${TEVWH_OUT}/scanner/segment_padding/infect )
library=$(
  ${TEVWH_PATH_LDD} "${shell}" \
  | ${TEVWH_PATH_PERL} -ane 'm/\blibc\b/ && print $F[2];'
)
${TEVWH_PATH_NM} -D ${library} --line-numbers --no-sort \
| ${TEVWH_PATH_GREP} __libc_start_main
