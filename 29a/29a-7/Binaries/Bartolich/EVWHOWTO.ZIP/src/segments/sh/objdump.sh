#!/bin/sh
shell=$( ${TEVWH_PATH_SED} 1q \
	${TEVWH_OUT}/scanner/segment_padding/infect )
[ -x "${shell}" ] || exit 1

${TEVWH_PATH_LS} -Ll ${shell}
${TEVWH_PATH_OBJDUMP} -fp ${shell}
