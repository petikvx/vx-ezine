#define TRACE_ERROR	print_errno
#define TRACE_SCAN	print_errno
#define TRACE_INFECT	(void)
#define TRACE_DEBUG	(void)
