#!/usr/bin/perl -w

my $queue = '';
while (<>)
{
  $queue .= $_;

  next if (m/^In file included from /
  || m/^\s+from /
  || m/^\S+: In function /);

  if (m/: left-hand operand of comma expression has no effect$/)
  { $queue = ''; next; }

  print $queue; $queue = '';
}
