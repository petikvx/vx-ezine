
echo "---"
${TEVWH_PATH_CAT} ${first}_infected > strip_${first}_infected \
&& ${TEVWH_PATH_STRIP} strip_${first}_infected \
&& ${TEVWH_PATH_CHMOD} 755 strip_${first}_infected \
&& ./strip_${first_cmd}
