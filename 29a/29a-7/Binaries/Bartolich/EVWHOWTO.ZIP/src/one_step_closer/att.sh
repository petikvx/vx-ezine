#!/bin/sh
dst=$1; shift
full_dir=${dst%/*}
inf_dir=${full_dir##*/}
tmp_dst=${TEVWH_TMP}/one_step_closer/${inf_dir}/infection

${TEVWH_PATH_CC} -c ${TEVWH_AFLAGS} -o ${tmp_dst} \
	./src/one_step_closer/${inf_dir}/${TEVWH_ASM}.S \
&& ${TEVWH_PATH_OBJDUMP} -d ${tmp_dst} \
| ${TEVWH_PATH_SED} -ne '/^[[:space:]]*[[:xdigit:]]\{1,\}:/ p' \
| ./src/platform/disasm.pl \
	"-identifier=infection" \
	"-last_line_is_ofs=" \
	"$@" \
	> ${dst}
