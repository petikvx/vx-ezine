echo "pid=[$$]"
cd ${tmp}
echo "TERM=[$TERM]"
