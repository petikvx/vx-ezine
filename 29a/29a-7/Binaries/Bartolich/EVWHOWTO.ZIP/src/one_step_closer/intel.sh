#!/bin/sh
dst=$1; shift
full_dir=${dst%/*}
inf_dir=${full_dir##*/}
tmp_dst=${TEVWH_TMP}/one_step_closer/${inf_dir}/infection

${TEVWH_PATH_NASM} -f bin -o ${tmp_dst} \
	./src/one_step_closer/${inf_dir}/${TEVWH_ASM}.S \
&& ${TEVWH_PATH_NDISASM} -U ${tmp_dst} \
| ./src/platform/disasm.pl \
	"-last_line_is_ofs=" \
	"-identifier=infection" \
	"$@" > ${dst}
