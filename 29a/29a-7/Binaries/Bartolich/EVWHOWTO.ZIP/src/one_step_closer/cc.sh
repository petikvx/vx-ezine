#!/bin/sh
project=${1:-one_step_closer}
entry_addr=${2:-e1}
infection=${3:-i1}
main=${4}

${TEVWH_PATH_CC} ${TEVWH_CFLAGS} \
	-I ./src/one_step_closer/${entry_addr} \
	-I ${TEVWH_OUT}/one_step_closer/${infection} \
	-o ${TEVWH_TMP}/${project}/${entry_addr}${infection}/infector \
	${main} 2>&1 \
| ./src/one_step_closer/gcc-filter.pl \
| ${TEVWH_PATH_FMT} -s
