#!/bin/sh
project=${1:-one_step_closer}
entry_addr=${2:-e1}
infection=${3:-i1}
scanner=${4:-segment_padding}

( cd ${TEVWH_TMP}/${project}/${entry_addr}${infection} \
	&& ./infector ) \
< ${TEVWH_OUT}/scanner/${scanner}/infect
