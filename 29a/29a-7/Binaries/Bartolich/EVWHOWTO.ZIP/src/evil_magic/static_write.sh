#!/bin/sh
file=${1:-${TEVWH_TMP}/magic_elf/magic_elf_static}
func=$( src/evil_magic/first_gdb_func.sed \
	< ${TEVWH_OUT}/evil_magic/static_main.gdb )

${TEVWH_PATH_ECHO} "[func=${func}]"
src/magic_elf/gdb_core.sh ${file} ${func} \
| src/magic_elf/gdb_format.pl
