#!/bin/sh
file=${1:-${TEVWH_TMP}/magic_elf/magic_elf_static}

# \< and \> don't work on i386-freebsd4.7
func=$( ${TEVWH_PATH_NM} -p ${file} \
	| ${TEVWH_PATH_SED} -ne '/.*[tTwW] \(__*write\)/ {
		s//\1/
		p
		q
	}' )

${TEVWH_PATH_ECHO} "[func=${func}]"
src/magic_elf/gdb_core.sh ${file} ${func} \
| src/magic_elf/gdb_format.pl
