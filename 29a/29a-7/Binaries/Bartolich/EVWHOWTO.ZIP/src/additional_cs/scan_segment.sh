#!/bin/sh
TEVWH_TMP=${TEVWH_TMP}
export TEVWH_TMP
shell=$( ${TEVWH_PATH_SED} 1q \
	${TEVWH_OUT}/scanner/segment_padding/infect )

${TEVWH_PATH_ECHO} "${shell}
${TEVWH_TMP}/additional_cs/e1i1/${shell##*/}_infected" \
| ${TEVWH_TMP}/scanner/segment_padding
