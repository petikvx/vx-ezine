#!/bin/sh
shell=$( ${TEVWH_PATH_SED} 1q \
	${TEVWH_OUT}/scanner/additional_cs/infect )
[ -x "${shell}" ] || exit 1
cd ${TEVWH_TMP}/additional_cs/e1i1 || exit 2
infected=${shell##*/}_infected

${TEVWH_PATH_LS} -l ${infected}
${TEVWH_PATH_LS} -l strip_${infected}
${TEVWH_PATH_LS} -l ${shell}
${TEVWH_PATH_READELF} -l ${infected}

