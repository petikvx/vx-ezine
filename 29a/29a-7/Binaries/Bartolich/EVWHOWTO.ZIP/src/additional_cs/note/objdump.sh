#!/bin/sh
. ${TEVWH_OUT}/additional_cs/note/objdump-name
${TEVWH_PATH_OBJDUMP} -j ${name} -d ${shell} ${TEVWH_ASM_OBJDUMP} \
2>&1 | ${TEVWH_PRE}/magic_elf/objdump_format.pl
