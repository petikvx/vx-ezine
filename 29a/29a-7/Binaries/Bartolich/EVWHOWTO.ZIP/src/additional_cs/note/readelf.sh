#!/bin/sh
.  ${TEVWH_OUT}/additional_cs/note/readelf-name
${TEVWH_PATH_READELF} -x ${index} ${shell}
${TEVWH_PATH_ECHO} "section=${index} status=$?"
