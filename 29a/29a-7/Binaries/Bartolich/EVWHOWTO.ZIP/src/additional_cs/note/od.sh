#!/bin/sh
. ${TEVWH_OUT}/additional_cs/note/offset
${TEVWH_PATH_DD} if=${shell} bs=1 skip=${off} count=${filesz} \
| ${TEVWH_PATH_OD} -c
