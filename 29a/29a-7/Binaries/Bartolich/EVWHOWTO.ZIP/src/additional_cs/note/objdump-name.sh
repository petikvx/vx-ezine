#!/bin/sh
shell=$( ${TEVWH_PATH_SED} 1q \
	${TEVWH_OUT}/scanner/additional_cs/infect )
[ -x ${shell} ] || exit 1

${TEVWH_PATH_ECHO} shell="${shell}"
${TEVWH_PATH_OBJDUMP} -h ${shell} \
| ${TEVWH_PATH_PERL} -ane \
	'if (/\s+\.note[A-Za-z\.-]*\s+/) {
		print "index=$F[0]\nname=\"$F[1]\"\n# $_";
		exit 0;
	}'
