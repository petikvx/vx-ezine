#!/bin/sh
shell=$( ${TEVWH_PATH_SED} 1q \
	${TEVWH_OUT}/scanner/additional_cs/infect )
[ -x ${shell} ] || exit 1

${TEVWH_PATH_ECHO} shell="${shell}"
${TEVWH_PATH_READELF} -S ${shell} \
| ${TEVWH_PATH_PERL} '-anF/[\s\[\]]+/' -e \
	'if ($F[3] eq "NOTE") {
		print "index=$F[1]\nname=\"$F[2]\"\n";
		exit 0;
	}'
