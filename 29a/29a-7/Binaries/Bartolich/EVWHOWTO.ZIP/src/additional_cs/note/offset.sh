#!/bin/sh
shell=$( ${TEVWH_PATH_SED} 1q \
	${TEVWH_OUT}/scanner/additional_cs/infect )
echo "shell='${shell}'"

${TEVWH_PATH_OBJDUMP} -p ${shell} \
| ${TEVWH_PATH_PERL} -ne \
	'if (s/^\s*NOTE\s+//) {
	   # convert all hexadecimal fields into assignments
	   s/ *(\w+)\s+0x([0-9a-fA-F]+)/sprintf("%s=%d\n", $1, hex($2))/ge;
	   s/\n .*//;	# cut off trailing "align 2**2"
	   $_ .= <>;	# append second line
	   # convert all appended hexadecimal fields into assignments
	   s/ *(\w+)\s+0x([0-9a-fA-F]+)/sprintf("%s=%d\n", $1, hex($2))/ge;
	   s/\n .*//;	# cut off trailing "flags r--"
	   print $_;
	   exit 0;
	}'
