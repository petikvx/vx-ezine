#!/bin/sh
. ${TEVWH_OUT}/additional_cs/note/offset
${TEVWH_PATH_XXD} -l ${filesz} -s ${off} ${shell}
