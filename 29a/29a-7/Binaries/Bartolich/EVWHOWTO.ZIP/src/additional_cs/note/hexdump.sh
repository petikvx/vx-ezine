#!/bin/sh
. ${TEVWH_OUT}/additional_cs/note/offset
${TEVWH_PATH_HEXDUMP} \
	-f ./src/format.hex \
	-s ${off} -n ${filesz} < ${shell}
