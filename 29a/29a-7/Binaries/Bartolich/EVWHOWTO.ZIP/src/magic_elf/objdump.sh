#!/bin/sh
. ${TEVWH_OUT}/magic_elf/addr_of_main
${TEVWH_PATH_OBJDUMP} -d ${TEVWH_ASM_OBJDUMP} \
	--start-address=0x${addr_main_x} \
	${TEVWH_TMP}/magic_elf/magic_elf \
2>&1 | src/magic_elf/objdump_format.pl \
	-start_address=${addr_main_x}
