#!/usr/bin/perl -nw
if (m/([^:]+):\s+(\S+)\s+(.*)/)
{
  # %-30s to cover "0x804c1c0 <__libc_write+32>:"
  printf "%-30s%-13s ", $1 . ':', $2;
  my $opcode = $2;
  my $rest = $3;
  if ($rest =~ s/\s+${TEVWH_ASM_COMMENT}\s*(.*)//)
    { printf "%-20s${TEVWH_ASM_COMMENT} %s\n", $rest, $1; }
  else
    { print $rest . "\n"; }

  exit(0) if ($opcode =~ m/${TEVWH_ASM_RETURN}/);
}
