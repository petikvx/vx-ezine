#!/bin/sh
src=${TEVWH_TMP}/magic_elf/magic_elf
${TEVWH_PATH_OD} -N 16 -c   ${src} | ${TEVWH_PATH_SED} 1q
${TEVWH_PATH_OD} -N 16 -x   ${src} | ${TEVWH_PATH_SED} 1q
${TEVWH_PATH_OD} -N 16 -tx1 ${src} | ${TEVWH_PATH_SED} 1q
${TEVWH_PATH_OD} -N 16 -ta  ${src} | ${TEVWH_PATH_SED} 1q
