#!/bin/sh
${TEVWH_PATH_XXD} -l 80 \
< ${TEVWH_TMP}/magic_elf/magic_elf
