#include <stdio.h>

int main()
{
  printf("# sizeof(unsigned long)=%u\n", (unsigned)sizeof(unsigned long));
  printf("# ${TEVWH_ELF_BASE}=%#02x\n", *(unsigned char*)0x${TEVWH_ELF_BASE});
  printf("# ${TEVWH_ELF_MAGIC}=%.3s\n", (char*)0x${TEVWH_ELF_MAGIC});

  /* output of %p can either be hex or decimal, so comment it out */
  printf("# addr_main_p=%p\n\n", main);

  /* suffix "_x" is required by post-processing (etc/calc.pl) */
  printf("addr_main_x=%lx\n", (unsigned long)main);
  printf("ofs_main_x=%lu\n", (unsigned long)main - 0x${TEVWH_ELF_BASE});
  printf("ofs_main=%lu\n", (unsigned long)main - 0x${TEVWH_ELF_BASE});
  return 0;
}
