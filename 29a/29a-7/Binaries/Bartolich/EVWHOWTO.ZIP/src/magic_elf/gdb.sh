#!/bin/sh
file=${1:-${TEVWH_TMP}/magic_elf/magic_elf}
func=${2:-main}

${TEVWH_PATH_ECHO} "[func=${func}]"
src/magic_elf/gdb_core.sh ${file} ${func} \
| src/magic_elf/gdb_format.pl
