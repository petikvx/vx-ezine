#!/bin/sh
src=${TEVWH_TMP}/magic_elf/magic_elf
[ -s ${src} ] || exit 1

. ${TEVWH_OUT}/magic_elf/addr_of_main
${TEVWH_PATH_NDISASM} -e ${ofs_main} -o 0x${addr_main_x} -U ${src} \
| ${TEVWH_PATH_PERL} \
	-ne "print $_; exit if m/\b${TEVWH_ASM_RETURN}\b/;"
