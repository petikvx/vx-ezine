#!/bin/sh
${TEVWH_PATH_CC} \
	${TEVWH_CFLAGS} \
	-o ${TEVWH_TMP}/magic_elf/magic_elf \
	src/magic_elf/magic_elf.c \
&& ${TEVWH_TMP}/magic_elf/magic_elf
