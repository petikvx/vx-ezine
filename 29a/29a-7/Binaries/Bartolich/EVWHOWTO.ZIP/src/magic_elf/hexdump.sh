#!/bin/sh
${TEVWH_PATH_HEXDUMP} -n 80 -f ./src/format.hex \
< ${TEVWH_TMP}/magic_elf/magic_elf
