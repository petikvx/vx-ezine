#!/bin/sh
# without "-a -n 3" we don't get any output
${TEVWH_PATH_STRINGS} -a -n 3 \
	${TEVWH_TMP}/magic_elf/magic_elf \
| ${TEVWH_PATH_GREP} -n ELF
