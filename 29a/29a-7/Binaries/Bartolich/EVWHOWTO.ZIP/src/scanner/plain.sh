#!/bin/sh
src=$1
dst=$2
scanner=${3:-segment_padding}

[ -s ${src} ] || exit 0
TEVWH_TMP=${TEVWH_TMP}; export TEVWH_TMP

${TEVWH_TMP}/scanner/${scanner} < ${src} 2>&1 \
| ${TEVWH_PATH_TEE} ${dst}.full \
| ${TEVWH_PATH_GREP} -v ' Ok$' \
| ${TEVWH_PATH_TAIL} \
> ${dst}
