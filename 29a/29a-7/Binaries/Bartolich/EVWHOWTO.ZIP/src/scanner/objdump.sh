#!/bin/sh
src="${1}"
dst="${2}"
scanner="${3:-entry_point}"
flags="${4:--fh}"

[ -s "${src}" ] || exit 0
TEVWH_TMP=${TEVWH_TMP}; export TEVWH_TMP

${TEVWH_PATH_XARGS} ${TEVWH_PATH_OBJDUMP} "${flags}" \
< "${src}" \
| "./src/scanner/${scanner}/objdump.pl" \
| ${TEVWH_PATH_TEE} "${dst}.full" \
| ${TEVWH_PATH_TAIL} \
> "${dst}"
