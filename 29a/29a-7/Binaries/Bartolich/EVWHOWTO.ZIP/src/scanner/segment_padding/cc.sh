#!/bin/sh
project=${1:-segment_padding}

${TEVWH_PATH_CC} ${TEVWH_CFLAGS} \
	-o ${TEVWH_TMP}/scanner/${project} \
	./src/scanner/${project}/*.c 2>&1 \
| ./src/one_step_closer/gcc-filter.pl
