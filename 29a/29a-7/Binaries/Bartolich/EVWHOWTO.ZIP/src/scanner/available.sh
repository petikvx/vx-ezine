#!/bin/sh
dst=${1}; shift

# cut off last line (detection statistics), print only first column
${TEVWH_PATH_SED} -ne '$ q' -e '/^\([^ ]*\) .*/s//\1/p' \
< ${dst}.full \
| ${TEVWH_PATH_SORT} - ${dst}.files \
| ${TEVWH_PATH_UNIQ} -u \
> ${dst}.available
