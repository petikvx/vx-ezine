#include "src/one_step_closer/trace_scanner.h"
#include "src/one_step_closer/prefix.inc"

#include "src/scanner/additional_cs/action.inc"
#include "src/scanner/additional_cs/print_summary.inc"

#include "src/one_step_closer/is_elf.inc"
