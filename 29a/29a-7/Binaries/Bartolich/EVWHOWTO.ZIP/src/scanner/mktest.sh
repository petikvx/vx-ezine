#!/bin/sh
src="${1}"

[ -s "${src}" ] || exit 1
shell=$( ${TEVWH_PATH_SED} 1q "${src}" )
echo "#!${shell}"
