#!/bin/sh
[ -s "$1" ] || exit 1
${TEVWH_PATH_XARGS} ${TEVWH_PATH_FILE} < "$1" \
| ${TEVWH_PATH_FMT} -s

