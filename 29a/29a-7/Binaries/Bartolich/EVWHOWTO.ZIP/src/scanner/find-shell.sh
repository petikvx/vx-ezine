#!/bin/sh
scanner="$1"
${TEVWH_PATH_GREP} -h -f ./src/scanner/find-shell.lst \
	${TEVWH_OUT}/scanner/${scanner}/*.ok
exit 0
