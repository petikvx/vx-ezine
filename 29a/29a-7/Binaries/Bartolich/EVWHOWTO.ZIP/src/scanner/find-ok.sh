#!/bin/sh
scanner=${1:-segment_padding}
prefix=$2
for src in ${TEVWH_OUT}/scanner/$1/big.*.full
do
  ${TEVWH_PATH_SED} -ne 's/ \.\.\. .* Ok$//p' \
  < ${src} > ${src%.full}.ok
done
${TEVWH_PATH_WC} -l ${TEVWH_OUT}/scanner/$1/*.ok
