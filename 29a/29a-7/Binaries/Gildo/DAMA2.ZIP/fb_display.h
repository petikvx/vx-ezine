#include <linux/fb.h>

extern "C" {

void fb_display(unsigned char *rgbbuff,
	int x_size, int y_size,
	int x_pan, int y_pan,
	int x_offs, int y_offs);

void closeFB(int fd);
int openFB(const char *file);
void getVarScreenInfo(int fb,struct fb_var_screeninfo *var);
void setVarScreenInfo(int fb,struct fb_var_screeninfo *var);
void getCurrentRes(int *x,int *y);

}
