

//these are the types of graphical objects available in GScene,
//I can create instances of these
#define ID_TYPE_PIECE_NULL 0 //no piece present (eaten)
#define ID_TYPE_PIECE_MY 1  //my piece
#define ID_TYPE_PIECE_OT 2  //other piece
#define ID_TYPE_PIECE_DAMA_MY 3 //my dama
#define ID_TYPE_PIECE_DAMA_OT 4 //other dama 
#define ID_TYPE_BOX_ON 5    //box on witch I can move (the black ones usually)
#define ID_TYPE_BOX_OFF 6   //box on witch nobody can move (the white usualy)
#define ID_TYPE_SEL_HIGHT 7  //the cursor with a current selection
#define ID_TYPE_SEL_DARK 8  //the cursor without a current selection
#define ID_TYPE_DIALOG 9  //the basic window
#define ID_TYPE_WON 10  //the string I won
#define ID_TYPE_LOST 11 //string ...
#define ID_TYPE_QUIT 12 //string ...


#define DAMA_TOP 10  //coordinate
#define DAMA_LEFT 10 

#define BOX_SIZE 60 

#define Z_BOX 3      //a low value (background)
#define Z_PIECE 20   //hight (on foreground)
#define Z_SELECTION 40
#define Z_DIALOG 50 //over the dama
#define Z_STRING 60 //over all


#define VALID_OUT_OF_RANGE -1
#define VALID_IMPOSSIBLE -2
#define VALID_SINGLESTEP_MY 1
#define VALID_SINGLESTEP_OT 2
#define VALID_MYEATOT_MY 3
#define VALID_OTEATMY_OT 4

