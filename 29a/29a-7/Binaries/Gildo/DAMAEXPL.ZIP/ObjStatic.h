#ifndef _ObjStatic_h_
#define _ObjStatic_h_
#include "Obj.h"


class GObjStatic :public GObject
{
public:
  GObjStatic(int ID,char* file);  //open file image
  GObjStatic();
  ~GObjStatic();

  //debug informations
  void Dump();

};








#endif
