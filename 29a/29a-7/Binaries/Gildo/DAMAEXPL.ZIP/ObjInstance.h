#ifndef _ObjInstance_h_
#define _ObjInstance_h_


#include "Obj.h"
#include "IDtype.h"

/*
 this class is the real object that is
 created from the GScene class,
 this is made to reference images
 instead of creating more then one equal images
*/

class GObjInstance
{
public:  
  int ID,      //current object instance
    ID_type,    //Obj to reference
    x_pos,
    y_pos,
    z_pos;

  GObjInstance(int ID,int ID_type,int x_pos,int y_pos,int z_pos):
  	ID (ID),ID_type (ID_type),x_pos (x_pos),
  	y_pos (y_pos),z_pos (z_pos) {}

  int Draw(LScreen *ls);
  
  GObject *obj_ref;  //object reference
};


#endif
