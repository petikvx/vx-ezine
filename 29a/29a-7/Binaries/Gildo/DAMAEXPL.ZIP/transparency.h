#ifndef _transparency_h_
#define _transparency_h_

extern "C" {
#include <gif_lib.h> 
}

/* this is a dirty joke, to interpret 
  this color as transparency
*/


GifColorType TRANSPARENCY_COLOR={1,254,1};


#endif
