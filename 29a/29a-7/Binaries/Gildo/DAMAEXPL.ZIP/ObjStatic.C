#ifndef _ObjStatic_C_
#define _ObjStatic_C_

#include "ObjStatic.h"
//#include "Obj.h"

extern "C" {
#include <gif_lib.h>
}
extern GifColorType TRANSPARENCY_COLOR;  //is (1,254,1) used as transparent color

//class GObjStatic :public GObj

void GObjStatic::Dump()
{
  printf("ID=%u\nclass_ID=%u\nx_pos=%u\n"
  	"y_pos=%u\nz_pos=%u\nx_size=%u\n"
  	"y_size=%u\nImage=0x%p\n",
	ID,class_ID,x_pos,y_pos,z_pos,
	x_size,y_size,Image);

}

GObjStatic::GObjStatic()
{
  //GObject::GObject();
}

GObjStatic::GObjStatic(int ID,char* file) :GObject(ID)
{
  struct formathandler *fh;
  
  //GObject::GObject();
  fh=fh_getsize(file,&x_size,&y_size);
  Image=get_image(file);
  if(fh==NULL || Image==NULL)
  {
    this->~GObjStatic();
    return;
  }
}


GObjStatic::~GObjStatic()
{
  if(Image!=NULL)
    delete Image;
  this->GObject::~GObject();
}  



#endif
