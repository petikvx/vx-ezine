
int fh_gif_id(char *name);
inline void m_rend_gif_decodecolormap(unsigned char *cmb,unsigned char *rgbb,ColorMapObject *cm,int s,int l);
int fh_gif_load(char *name,unsigned char *buffer,int x,int y);
int fh_gif_getsize(char *name,int *x,int *y);

