/* define.h   some definitions
 *
 * Gildo backdoor generator is copyright (C) 2002 Mauro Meneghin.
 * All rights reserved. The software is redistributable under
 * the licence given in the file "Licence" distributed in the
 * Gbkdoor archive.
 */





#ifndef _define_h_
#define _define_h_





//Chunk defines
#define CHNK_MINSIZE	5	//the littler useful chunk of NOPs

//List1 defines
#define LIST1_BASH_ARGC 12      //the number of arguments +1 where
#define LIST2_BASH_ARGC 12      //program to execute will be














#endif

