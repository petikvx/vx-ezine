September 2003

NT PASSWORD CREATION

I cannot finish this code until next year..so
instead of keep it lying around, i thought
i'd pass it out.

The plan was to create a packet capture utility for win2k
and "audit" nt authentication hashes going over the network.
I will release mmx code sometime next year which creates 2 lanman
hashes at once speeding up an audit x 2.

bcom@hushmail.com


NTLM1 = MD4(Unicode Password)

The following is taken from L0phtcrack documentation.

  LANMAN One Way Passwords are created in the following fashion:
	. The password is first converted to uppercase
	. If the password is longer than 14 chars (bytes) then it
		is truncated
	. If the password is less than 14 chars (bytes) then it is
		padded with NULL's to 14 bytes.
	. The padded/truncated password is then split in half and each
		half is used to generate an odd parity DES key
	. An 8 byte fixed value is then encrypted with each of the
		DES keys - these two results are concatenated together
		to produce a 16byte hash.

	The fixed value that is encrypted by each of the DES keys is the 
	decryption of the value 0xAAD3B435B51404EE with a key of all zeros.


For description of NTLM2, read this Powerpoint presentation:

http://cnscenter.future.co.kr/resource/rsc-center/presentation/black-ws/2002/urity-winsec02.ppt
