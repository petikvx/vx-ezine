DoS IP Spoofing Library 1.0 by Aphex for Winsock 2.0

This library comes as a DLL which can be used with Delphi, VB, VC++, etc and also a native
Delphi compiled unit. Both versions include examples. All code within these libraries is 100%
my own work, obviously, since this is the first component for delphi that can spoof icmp/tcp/udp.

Dynamic install: Simply include the DLL with your application, making sure it is in the same
                 directory as the application file or in the windows system directory.

Static install: For all you elite Delphi users I have included a version of this library
                as a compiled unit. Simply copy Dos.dcu to your Delphi\Lib directory and
                you can use this in any application without the need of seperate files.
                Also, NO uses are required so no extra overhead is added!

Note: email all bugs to unremote@knology.net