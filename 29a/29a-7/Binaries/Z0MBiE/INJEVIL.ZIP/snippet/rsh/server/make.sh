#!/bin/sh
nasm -f bin -o rsh.bin rsh.asm
