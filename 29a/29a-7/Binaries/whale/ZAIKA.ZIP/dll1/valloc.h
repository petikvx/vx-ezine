#ifndef JHGYGYUI
#define JHGYGYUI
char *valloc(DWORD num);
BOOL vfree(void *p);

#endif