#ifndef __dfgsfdgfsd__
#define __dfgsfdgfsd__
#include <windows.h>
DWORD WINAPI proxy(HINSTANCE);
#endif