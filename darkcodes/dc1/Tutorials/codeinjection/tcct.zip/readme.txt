


Tsongkie's Code Cave Tool (TCCT)
--------------------------------
v1.1 by Tsongkie




I. Introduction



What Is a code cave?
--------------------

	For those of you who do not know, code caves are 00's and 90's in a 
program's space. We can use these code caves as places wherein we can inject 
our own code...


Program Description
-------------------

	This program searches the first few thousand bytes of memory of the
process (games) for code caves. I got tired of using fancy si commands for
this purpose.

	Also, let me point out that THIS PROGRAM DOES NOT CODE INJECT OR 
TEACHES YOU HOW TO, Read [sheep]'s or my tutorial on code injection in
www.gamehacking.com



II. Instructions


Using TCCT
----------

	1) Run the game/application and alt+tab out of it. 
	2) Run TCCT
	3) In Game Window, write the name of the target window name of the game.
	4) Press Search (Searches for a minimum of 100 00's)


Using TCCT with SoftIce
-----------------------

	1) Be sure dump window is there by typing wd in softice
	2) press u <address> wherein <address> is a result addie from the search OR
	3) press d <address> OR e <address>




III. Other Info


About
-----

	TCCT is released under CES (www.gamehacking.com). You can email me
root@tsongkie.com for questions/suggestions/bug reports or you can visit my
site www.tsongkie.com

--> Tsongkie




IV. History

1.1 May 28,2003

Added Hotkey Feature
added Number of Results
A Few tweaking
Changed from Tool to Dialog Window




Greetz in no special order
---------------------------

	* nh2 * stonerifik * ddh * [sheep] * invader * iCarus * no_mercy *
* SubZero * Orr * SnipeR * Reaper32 * Snow * ratattack * Xan * Tracer * 007Cheater *
* #gamehacking in EFNET * TEAM EXTALIA * CES CREW * Inferno Industries *
* Evil Eye Software * SRN Software * And all that belongs here... *
