::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::::
:::::::[XOS.ArcusDaemonica.PS.Perforin-vxnetw0rk]:::::::::::::::::::::::
::::::::::::::::::::::::::[PS]::::::::::::::::::::::[Perforin]::::::::::
::::::::::::::::::::::::::::::::::::::[LIP]:::::::::::::::::::::::::::::


PostScript by Wikipedia:
"PostScript (PS) is a computer language for creating vector graphics.
It is a dynamically typed, concatenative programming language and was
created by John Warnock and Charles Geschke in 1982. It is best known
for its use as a page description language in the electronic and desktop
publishing areas."

This is my PS creation which I created for the LIP [1] contest by SPTH.
It's goal is to erase every PostScript file in the current directory
and drop a text file with the following content:

++++++++++++++++++++++++++++++++++++++++++++++++++++++
+ One unbreakable shield against the coming darkness +
+ One last blade forged in defiance of fate          +
+ Let them be my legacy to the galaxy I conquered    +
+ And my final gift to the species I failed          +
++++++++++++++++++++++++++++++++++++++++++++++++++++++


It also splashes it's name as a PDF.


Execute it with the following command:

ghostscript virus.ps
or
gs virus.ps



Sadly this is not one of my best creations but I'm running out of time
to code something else in PS. But PS looks very promising as nearly 
every printer uses it. And printers have their own filesystem. I guess
that you could create a backdoor into your printer with a PostScript
file :)

This is a language you and I should have an eye on!



[1] http://spth.virii.lu/LIP.html 

Perforin - virii@tormail.org - virii.lu
