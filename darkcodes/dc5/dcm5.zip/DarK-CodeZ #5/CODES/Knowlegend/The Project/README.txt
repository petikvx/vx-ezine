/*
	Author: Know v3.0
	Twitter: @KnowV3
	Email: know [dot] omail [dot] pro
	Website: knowlegend.ws / knowlegend.me

	(c) 2013 - Know v3.0 alias Knowlgend
*/


a few months ago i started the project called "The Project", now it's a piece of shit cause i don't have enaugh time to
finish this project. atm it works fine - mostly. you will only get the source-code, if you realy want to create a executable with the given code,
you will find a way to do it. the project will only works if the MetaEngine-Class is compiled as dll, crypted and appendent to the main executable - yes i have a builder, but you need to do it with your hands :o
you can find the pussy algorithm in the code. just a bit of the project is from another programmer name, email etc are in the code.
only the main files are commented e.g. the MetaEngine-Class(~2800 lines) isn't.. im just to lazy.. and the most functions are self-explanatory.
~ knowlegend - vxnetw0rk - germany


greetz to
TgZero, virii, R3s1stanc3 && zec0