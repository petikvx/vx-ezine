



          Just run the eml file.When you sellect to open the attachment ,not to save to disk,
     an exe is going to run,without any warning.To change the eml,rename it in .txt and make
     any modifications U want...This exploit can be used for a Worm in Outlook,not Outlook
     Express.But Express can be used as a Bobmer Mail deliver...Enjoy Microsoft's shit...


          From the KaGra
         
          mail:roallercoaster1@yahoo.com