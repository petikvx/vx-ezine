alcopaul's picture steganographer v1.0b

july 13, 2002 - apsv1.0b is released

target files : jpeg, gif and bmp files...

components

insert.exe : inserts passworded message to pictures
read.exe : reads the message from modified pictures

it's not your conventional picture file steganographer that modifies pixels and stuff...

alcopaul
alcopaul@digitelone.com