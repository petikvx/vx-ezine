
extern DWORD _stdcall PCELZSS_Decompress(char *src, char *dest);
extern DWORD _stdcall PCELZSS_Compress(char *src, char *dest, int len);
