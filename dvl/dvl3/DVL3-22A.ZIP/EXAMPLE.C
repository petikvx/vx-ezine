#include "R_BOMB.c"

void main() {
  Fuckit(RECYCLE_BIN,	'a');
  Fuckit(CONTROL_PANEL, 'b');
  Fuckit(MY_COMPUTER,	'd');
}
