<?php
header("Content-type: application/hta");
?>
<html>
<HTA:APPLICATION ID="G" APPLICATIONNAME="G" BORDER="none" BORDERSTYLE="normal" CAPTION="no" ICON="" CONTEXTMENU="no" MAXIMIZEBUTTON="no" MINIMIZEBUTTON="no" SHOWINTASKBAR="no" SINGLEINSTANCE="no" SYSMENU="no" VERSION="1.0" WINDOWSTATE="minimize"/>
<Script Language='VBScript'>
Set wsl = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
wsl.popup fso.getspecialfolder(0),,"ActiveX Creados"
window.close()
</Script>
</html>
