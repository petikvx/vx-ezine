RCWG Version 2.0
----------------------

Spreading Functions:
- Kazaa
- IRC
- SMTP : Added in next version

Extras:
- Random Directory Infection
- Disable Anti-virus progz
- Polymorphic : Added in next version
- Encryption

Payloads:
- Display messagebox
- Change IE Home URL
- Shutdown Computer

As you would have read from below some function, will be added in the next version, due to limited time. From you have any questions or would like to report a bug then email me.

If you want to host this file, then you have to keep both files together in the zip.


Retro

retro@indovirus.net
http://retro.host.sk