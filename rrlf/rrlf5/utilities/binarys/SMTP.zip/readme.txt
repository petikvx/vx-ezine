Using API's for SMTP in VB
-----------------------------------
Files:
       SMTP.bas  		- Too send email
       WinSockBas.bas	- Complete works of MSWinSck.ocx

You can use both the modules in your VB appz
to send email via SMTP. WinSock.bas can also
be using in anyother appz without the use of
WinSock.ocx.




