function kjp(a1){
 a2 = new Array("kjp", "a1", "a2", "a3", "a4", "a5", "a6", "a7");
 for(a3 in a2){
  a4 = "";
  for(a5 = 0; a5 < Math.round(Math.random() * 6) + 4; a5++)
   a4 += String.fromCharCode(Math.round(Math.random() * 22) + 97);
  for(var a6 = 0; a6 < a1.length; a6++) a1 = a1.replace(a2[a3], a4);
 }
 return(a1);
}