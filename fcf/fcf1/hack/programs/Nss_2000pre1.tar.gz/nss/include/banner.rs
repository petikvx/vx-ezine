# Read "ReadMe.txt/.html" for ...

sub banner {
    system("clear");
    print "\t\t\tNarrow Security Scanner - 2000pre1\n";
    print "\t\t\t==================================\n\n";
}
print;