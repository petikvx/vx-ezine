# Read "ReadMe.txt/.html" for ...

sub logs {
$file = shift;
$cmd  = shift;

if($cmd eq "open") { open(LOG, ">>$file") || die "open: $!\n"; }
if($cmd eq "close") { close LOG; }
}

sub last {
$last_host = shift;
    open(LAST, ">last-connect") || die "open: $!\n";
    $time = localtime;
    print LAST "Last scanned host: $last_host - $time";
    close LAST;
}
print;