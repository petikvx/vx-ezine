# Read "ReadMe.txt/.html" for ...

sub count {
$hostfile_to_count = shift;
open(COUNT, "<$hostfile_to_count") || die "open: $!\n";

while(<COUNT>) {
    s/[ \t\r\n]//g; # remove excess cruft
    push @cnt, $_ if ($_ ne "");
}
close COUNT;
}
print;