# Read "ReadMe.txt/.html" for ...

push @plugins, 'sshd';

sub sshd {
if($debug) { print "Checking for sshd ...\n"; }
$sshd_host = shift; $x=0;
$remote = $netbios_host; $port = 22;
$iaddr = inet_aton($remote) || $x++;
$paddr = sockaddr_in($port, $iaddr);
$proto = getprotobyname('tcp');
socket(ssh, PF_INET, SOCK_STREAM, $proto) || $x++;
connect(ssh, $paddr) || $x++;

if($x == 0) {
while(<ssh>) { sleep(1); $ver = $_; chomp $ver; close ssh; }
if($ver =~ /ssh\-1.2.27/i) {
    print "[$sshd_host] - [SSH-1.2.27]\n";
    print LOG "[$sshd_host] - [SSH-1.2.27]\n";
}
} else { close ssh; }
}
print;