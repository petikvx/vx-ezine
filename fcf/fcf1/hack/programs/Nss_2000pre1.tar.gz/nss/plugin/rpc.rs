# Read "ReadMe.txt/.html" for ...

push @plugins, 'rpc';

sub rpc {
if($debug) { print "Checking for RPC ...\n"; }
$rpc_host = shift;
open(CMD, "rpcinfo -p $rpc_host |");
while(<CMD>) {
chomp;
($temp1,$temp2,$proto,$port,$rpcname) = split;
if($rpcname eq "amd") {
    print "[$rpc_host] - [RPC: amd ($proto port: $port)]\n";
    print LOG "[$rpc_host] - [RPC: amd ($proto port: $port)]\n";
}
if($rpcname eq "mountd") {
    print "[$rpc_host] - [RPC: mountd ($proto port: $port)]\n";
    print LOG "[$rpc_host] - [RPC: mountd ($proto port: $port)]\n";
}
if($rpcname eq "cmsd") {
    print "[$rpc_host] - [RPC: cmsd ($proto port: $port)]\n";
    print LOG "[$rpc_host] - [RPC: cmsd ($proto port: $port)]\n";
}
if($rpcname eq "status") {
    print "[$rpc_host] - [RPC: status ($proto port: $port)]\n";
    print LOG "[$rpc_host] - [RPC: status ($proto port: $port)]\n";
}
if($rpcname eq "nfsd") {
    print "[$rpc_host] - [RPC: nfsd ($proto port: $port)]\n";
    print LOG "[$rpc_host] - [RPC: nfsd ($proto port: $port)]\n";
}
if($rpcname eq "nisd") {
    print "[$rpc_host] - [RPC: nisd ($proto port: $port)]\n";
    print LOG "[$rpc_host] - [RPC: nisd ($proto port: $port)]\n";
}
if($rpcname eq "ttdbserver") {
    print "[$rpc_host] - [RPC: ttdbserver ($proto port: $port)]\n";
    print LOG "[$rpc_host] - [RPC: ttdbserver ($proto port: $port)]\n";
}
if($rpcname eq "statd") {
    print "[$rpc_host] - [RPC: statd ($proto port: $port)]\n";
    print LOG "[$rpc_host] - [RPC: statd ($proto port: $port)]\n";
}
if($rpcname eq "yppasswd") {
    print "[$rpc_host] - [RPC: yppasswd ($proto port: $port)]\n";
    print LOG "[$rpc_host] - [RPC: yppasswd ($proto port: $port)]\n";
}
if($rpcname eq "ypsnarf") {
    print "[$rpc_host] - [RPC: ypsnarf ($proto port: $port)]\n";
    print LOG "[$rpc_host] - [RPC: ypsnarf ($proto port: $port)]\n";
}
if($rpcname eq "sadmind") {
    print "[$rpc_host] - [RPC: sadmind ($proto port: $port)]\n";
    print LOG "[$rpc_host] - [RPC: sadmind ($proto port: $port)]\n";
}
}
close CMD;
}
print;