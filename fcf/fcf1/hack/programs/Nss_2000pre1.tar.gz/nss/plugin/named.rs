# Read "ReadMe.txt/.html" for ...

push @plugins, 'named';

sub named {
if($debug) { print "Checking for named ...\n"; }
$named_host = shift; $x=0;
$remote = $named_host; $port = 53;
$iaddr = inet_aton($remote) || $x++;
$paddr = sockaddr_in($port, $iaddr);
$proto = getprotobyname('tcp');
socket(named, PF_INET, SOCK_STREAM, $proto) || $x++;
connect(named, $paddr) || $x++;
close named;

if($x == 0) {
open(CMD, "dig \@$named_host chaos txt version.bind |");
while(<CMD>) {
chomp;
($string, $os, $chaos, $txt, $version) = split;
if($string eq "VERSION.BIND.") {

if($version =~ /4.9.5-REL/) {
    print "[$named_host] - [Named: $version]\n";
    print LOG "[$named_host] - [Named: $version]\n";
    close CMD;
    return;
}
if($version =~ /4.9.5-P1/) {
    print "[$named_host] - [Named: $version]\n";
    print LOG "[$named_host] - [Named: $version]\n";
    close CMD;
    return;
}
if($version =~ /4.9.6-REL/) {
    print "[$named_host] - [Named: $version]\n";
    print LOG "[$named_host] - [Named: $version]\n";
    close CMD;
    return;
}
if($version =~ /8.1-REL/) {
    print "[$named_host] - [Named: $version]\n";
    print LOG "[$named_host] - [Named: $version]\n";
    close CMD;
    return;
}
if($version =~ /8.1.1/) {
    print "[$named_host] - [Named: $version]\n";
    print LOG "[$named_host] - [Named: $version]\n";
    close CMD;
    return;
}
if($version =~ /4.9.5-REL/) {
    print "[$named_host] - [Named: $version]\n";
    print LOG "[$named_host] - [Named: $version]\n";
    close CMD;
    return;
}
if($version =~ /4.9.6/) {
    print "[$named_host] - [Named: $version]\n";
    print LOG "[$named_host] - [Named: $version]\n";
    close CMD;
    return;
}
if($version =~ /4.9.3-P1/) {
    print "[$named_host] - [Named: $version]\n";
    print LOG "[$named_host] - [Named: $version]\n";
    close CMD;
    return;
}
if($version =~ /8.2.1/) {
    print "[$named_host] - [Named: $version]\n";
    print LOG "[$named_host] - [Named: $version]\n";
    close CMD;
    return;
}
if($version =~ /8.2/ && $version !~ /8.2.2-P([3-5])/) {
    print "[$named_host] - [Named: $version]\n";
    print LOG "[$named_host] - [Named: $version]\n";
    close CMD;
    return;
  }
 }
}
close CMD;
 }
}
print;