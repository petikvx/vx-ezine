# Read "ReadMe.txt/.html" for ...

push @plugins, 'imapd';

sub imapd {
if($debug) { print "Checking for imapd ...\n"; }
$imapd_host = shift; $x=0;
$remote = $imapd_host; $port = 143;
$iaddr = inet_aton($remote) || $x++;
$paddr = sockaddr_in($port, $iaddr);
$proto = getprotobyname('tcp');
socket(imapd, PF_INET, SOCK_STREAM, $proto) || $x++;
connect(imapd, $paddr) || $x++;

if($x == 0) {
while(<imapd>) {
chomp;
    if(/imap4rev1/i && /10.171/) {
	print "[$imapd_host] - [IMAPD 10.171]\n";
	print LOG "[$imapd_host] - [IMAPD 10.171]\n";
	close imapd;
	return;
    }
    if(/imap4rev1/i && /10.183/) {
	print "[$imapd_host] - [IMAPD 10.183]\n";
	print LOG "[$imapd_host] - [IMAPD 10.183]\n";
	close imapd;
	return;
    }
    if(/imap4rev1/i && /10.190/) {
	print "[$imapd_host] - [IMAPD 10.190]\n";
	print LOG "[$imapd_host] - [IMAPD 10.190]\n";
	close imapd;
	return;
    }
    if(/imap4rev1/i && /10.191/) {
	print "[$imapd_host] - [IMAPD 10.191]\n";
	print LOG "[$imapd_host] - [IMAPD 10.191]\n";
	close imapd;
	return;
    }
    if(/imap4rev1/i && /9.0/) {
	print "[$imapd_host] - [IMAPD 9.0]\n";
	print LOG "[$imapd_host] - [IMAPD 9.0]\n";
	close imapd;
	return;
    }
    if(/imap4rev1/i && /10.166/) {
	print "[$imapd_host] - [IMAPD 10.166]\n";
	print LOG "[$imapd_host] - [IMAPD 10.166]\n";
	close imapd;
	return;
    }
    if(/imap4rev1/i && /10.203/) {
	print "[$imapd_host] - [IMAPD 10.203]\n";
	print LOG "[$imapd_host] - [IMAPD 10.203]\n";
	close imapd;
	return;
    }
    if(/imap4rev1/i && /10.205/) {
	print "[$imapd_host] - [IMAPD 10.205]\n";
	print LOG "[$imapd_host] - [IMAPD 10.205]\n";
	close imapd;
	return;
    }
    if(/imap4rev1/i && /10.233/) {
	print "[$imapd_host] - [IMAPD 10.233]\n";
	print LOG "[$imapd_host] - [IMAPD 10.233]\n";
	close imapd;
	return;
    }
    if(/imap4rev1/i && /10.234/) {
	print "[$imapd_host] - [IMAPD 10.234]\n";
	print LOG "[$imapd_host] - [IMAPD 10.234]\n";
	close imapd;
	return;
    }
    if(/imap4rev1/i && /v10.223/) {
    	print "[$imapd_host] - [IMAPD 10.223]\n";
	print LOG "[$imapd_host] - [IMAPD 10.223]\n";
	close imapd;
	return;
    }
    if(/imap4 service/i && /8.3/) {
	print "[$imapd_host] - [IMAPD Service 8.3]\n";
	print LOG "[$imapd_host] - [IMAPD Service 8.3]\n";
	close imapd;
	return;
    }
close imapd;
  }
 }
}
print;