# Read "ReadMe.txt/.html" for ...

push @plugins, 'pop3';

sub pop3 {
if($debug) { print "Checking for pop3 ...\n"; }
$pop3_host = shift; $x=0;
$remote = $pop3_host; $port = 110;
$iaddr = inet_aton($remote) || $x++;
$paddr = sockaddr_in($port, $iaddr);
$proto = getprotobyname('tcp');
socket(pop3, PF_INET, SOCK_STREAM, $proto) || $x++;
connect(pop3, $paddr) || $x++;

if($x == 0) {
while(<$pop3>) {
chomp;
    if(/qpop/i && /ersion 2.4b2/) {
	print "[$pop3_host] - [QPOP 2.4b2]\n";
	print LOG "[$pop3_host] - [QPOP 2.4b2]\n";
	close pop3;
	return;
    }
    if(/qpop/i && /ersion 2.41beta1/) {
	print "[$pop3_host] - [QPOP 2.41beta1]\n";
	print LOG "[$pop3_host] - [QPOP 2.41beta1]\n";
	close pop3;
	return;
    }
    if(/qpop/i && /ersion 3.0b([12-20])/) {
	print "[$pop3_host] - [QPOP 3.0b$1]\n";
	print LOG "[$pop3_host] - [QPOP 3.0b$1]\n";
	close pop3;
	return;
    }
    if(/sco/i && /2.1.4\-R3/) {
	print "[$pop3_host] - [ScoPOP 2.1.4\-R3]\n";
	print LOG "[$pop3_host] - [ScoPOP 2.1.4\-R3]\n";
	close pop3;
	return;
    }
    if(/sco/i && /5.0.0/) {
	print "[$pop3_host] - [ScoPOP 5.0.0]\n";
	print LOG "[$pop3_host] - [ScoPOP 5.0.0]\n";
	close pop3;
	return;
    }
    if(/qpop/i && /ersion 2.2/) {
	print "[$pop3_host] - [QPOP 2.2]\n";
	print LOG "[$pop3_host] - [QPOP 2.2]\n";
	close pop3;
	return;
    }
    if(/qpop/i && /ersion 2.3/) {
	print "[$pop3_host] - [QPOP 2.3]\n";
	print LOG "[$pop3_host] - [QPOP 2.3]\n";
	close pop3;
	return;
    }
    if(/qpop/i && /ersion 2.4/) {
	print "[$pop3_host] - [QPOP 2.4]\n";
	print LOG "[$pop3_host] - [QPOP 2.4]\n";
	close pop3;
	return;
    }
    if(/fusemail/i && /2.7/) {
	print "[$pop3_host] - [FuseMail 2.7]\n";
	print LOG "[$pop3_host] - [FuseMail 2.7]\n";
	close pop3;
	return;
    }
    if(/imail/i && /5.07/) {
	print "[$pop3_host] - [IMail 5.07]\n";
	print LOG "[$pop3_host] - [IMail 5.07]\n";
	close pop3;
	return;
    }
    if(/ucb/i && /popper/i && /1.831beta/) {
	print "[$pop3_host] - [UCB Pop Server 1.831beta]\n";
	print LOG "[$pop3_host] - [UCB Pop Server 1.831beta]\n";
	close pop3;
	return;
    }
close pop3;
  }
 }
}
print;