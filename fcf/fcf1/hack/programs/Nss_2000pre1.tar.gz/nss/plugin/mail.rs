# Read "ReadMe.txt/.html" for ...

push @plugins, 'mail';

sub mail {
if($debug) { print "Checking for mail ...\n"; }
$mail_host = shift; $x=0;
$remote = $mail_host; $port = 25;
$iaddr = inet_aton($remote) || $x++;
$paddr = sockaddr_in($port, $iaddr);
$proto = getprotobyname('tcp');
socket(mail, PF_INET, SOCK_STREAM, $proto) || $x++;
connect(mail, $paddr) || $x++;

if($x == 0) {
while(<mail>) {
chomp;
    if(/microsoft exchange/i && /5.0.1457.7/) {
	print "[$mail_host] - [MS Exchange 5.0]\n";
	print LOG "[$mail_host] - [MS Exchange 5.0]\n";
	close mail;
	return;
    }
    if(/slmail/i && /v2.6/) {
	print "[$mail_host] - [SLMail v2.6]\n";
	print LOG "[$mail_host] - [SLMail v2.6]\n";
	close mail;
	return;
    }
    if(/slmail/i && /3.1/) {
	print "[$mail_host] - [SLMail v3.1]\n";
	print LOG "[$mail_host] - [SLMail v3.1]\n";
	close mail;
	return;
    }
    if(/slmail/i && /3.2/) {
	print "[$mail_host] - [SLMail v3.2]\n";
	print LOG "[$mail_host] - [SLMail v3.2]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /4.1/) {
	print "[$mail_host] - [Sendmail 4.1]\n";
	print LOG "[$mail_host] - [Sendmail 4.1]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /5.55/) {
	print "[$mail_host] - [Sendmail 5.55]\n";
	print LOG "[$mail_host] - [Sendmail 5.55]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /5.61/) {
	print "[$mail_host] - [Sendmail 5.61]\n";
	print LOG "[$mail_host] - [Sendmail 5.61]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /5.65/) {
	print "[$mail_host] - [Sendmail 5.65]\n";
	print LOG "[$mail_host] - [Sendmail 5.65]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.65/) {
	print "[$mail_host] - [Sendmail 8.65]\n";
	print LOG "[$mail_host] - [Sendmail 8.65]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.7.([0-9])/) {
	print "[$mail_host] - [Sendmail 8.7.$1]\n";
	print LOG "[$mail_host] - [Sendmail 8.7.$1]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.8.0/) {
	print "[$mail_host] - [Sendmail 8.8.0]\n";
	print LOG "[$mail_host] - [Sendmail 8.8.0]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.8.2/) {
	print "[$mail_host] - [Sendmail 8.8.2]\n";
	print LOG "[$mail_host] - [Sendmail 8.8.2]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.8.4/) {
	print "[$mail_host] - [Sendmail 8.8.4]\n";
	print LOG "[$mail_host] - [Sendmail 8.8.4]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.8.5/) {
	print "[$mail_host] - [Sendmail 8.8.5]\n";
	print LOG "[$mail_host] - [Sendmail 8.8.5]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.8.8/) {
	print "[$mail_host] - [Sendmail 8.8.8]\n";
	print LOG "[$mail_host] - [Sendmail 8.8.8]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.6.4/) {
	print "[$mail_host] - [Sendmail 8.6.4]\n";
	print LOG "[$mail_host] - [Sendmail 8.6.4]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.6.7/) {
	print "[$mail_host] - [Sendmail 8.6.7]\n";
	print LOG "[$mail_host] - [Sendmail 8.6.7]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.6.9/) {
	print "[$mail_host] - [Sendmail 8.6.9]\n";
	print LOG "[$mail_host] - [Sendmail 8.6.9]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.6.10/) {
	print "[$mail_host] - [Sendmail 8.6.10]\n";
	print LOG "[$mail_host] - [Sendmail 8.6.10]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.6.12/) {
	print "[$mail_host] - [Sendmail 8.6.12]\n";
	print LOG "[$mail_host] - [Sendmail 8.6.12]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.9.2/) {
	print "[$mail_host] - [Sendmail 8.9.2]\n";
	print LOG "[$mail_host] - [Sendmail 8.9.2]\n";
	close mail;
	return;
    }
    if(/sendmail/i && /8.9.3\/8.9.3/) {
	print "[$mail_host] - [Sendmail 8.9.3]\n";
	print LOG "[$mail_host] - [Sendmail 8.9.3]\n";
	close mail;
	return;
    }
    if(/avirt mail/i) {
	print "[$mail_host] - [aVirt Mail]\n";
	print LOG "[$mail_host] - [aVirt Mail]\n";
	close mail;
	return;
    }
    if(/cmail server/i && /version/i && /2.([3-4])/) {
	print "[$mail_host] - [CMail Server 2.$1]\n";
	print LOG "[$mail_host] - [CMail Server 2.$1]\n";
	close mail;
	return;
    }
    if(/netscape messaging server/i && /3.62/) {
	print "[$mail_host] - [Netscape Messaging Server 3.62]\n";
	print LOG "[$mail_host] - [Netscape Messaging Server 3.62]\n";
	close mail;
	return;
    }
    if(/interscan viruswall nt/i && /3.23/) {
	print "[$mail_host] - [InterScan VirusWall NT ESMTP 3.23]\n";
	print LOG "[$mail_host] - [InterScan VirusWall NT ESMTP 3.23]\n";
	close mail;
	return;
    }
    if(/xtramail/i && /v1.11/) {
	print "[$mail_host] - [XtraMail v1.11]\n";
	print LOG "[$mail_host] - [XtraMail v1.11]\n";
	close mail;
	return;
    }
    if(/smail/i && /\-3.2/) {
	print "[$mail_host] - [SMail 3.2]\n";
	print LOG "[$mail_host] - [SMail 3.2]\n";
	close mail;
	return;
    }
    if(/internet anywhere mail server/i && /2.3.1/) {
	print "[$mail_host] - [Internet Anywhere Mail Server 2.3.1]\n";
	print LOG "[$mail_host] - [Internet Anywhere Mail Server 2.3.1]\n";
	close mail;
	return;
    }
    if(/skyfull mail server/i && /1.1.4/) {
	print "[$mail_host] - [Skyfull Mail Server 1.1.4]\n";
	print LOG "[$mail_host] - [Skyfull Mail Server 1.1.4]\n";
	close mail;
	return;
    }
    if(/zetamail/i && /2.1/) {
	print "[$mail_host] - [ZetaMail 2.1 (SMTP)]\n";
	print LOG "[$mail_host] - [ZetaMail 2.1 (SMTP)]\n";
	close mail;
	return;
    }
    if(/netcplus smartserver3/i) {
	print "[$mail_host] - [NetcPlus SmartServer3]\n";
	print LOG "[$mail_host] - [NetcPlus SmartServer3]\n";
	close mail;
	return;
    }
    if(/zom\-mail/i && /1.09/) {
	print "[$mail_host] - [Zom-Mail 1.09]\n";
	print LOG "[$mail_host] - [Zom-Mail 1.09]\n";
	close mail;
	return;
    }
close mail;
  }
 }
}
print;