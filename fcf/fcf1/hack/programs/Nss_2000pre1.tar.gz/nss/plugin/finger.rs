# Read "ReadMe.txt/.html" for ...

push @plugins, 'finger';

sub finger {
if($debug) { print "Checking for finger ...\n"; }
$finger_host = shift; $x=0;
$remote = $finger_host; $port = 79;
$iaddr = inet_aton($remote) || $x++;
$paddr = sockaddr_in($port, $iaddr);
$proto = getprotobyname('tcp');
socket(sock, PF_INET, SOCK_STREAM, $proto) || $x++;
connect(sock, $paddr) || $x++;
close sock;

if($x == 0) {
    print "[$finger_host] - [Finger]\n";
    print LOG "[$finger_host] - [Finger]\n";
}
}
print;