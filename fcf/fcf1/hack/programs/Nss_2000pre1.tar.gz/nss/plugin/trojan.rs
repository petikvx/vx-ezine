# Read "ReadMe.txt/.html" for ...

push @plugins, 'trojan';

sub trojan {
if($debug) { print "Checking for trojans ...\n"; }
$trojan_host = shift;
if(!&connt($trojan_host, 12345)) {
    print "[$trojan_host] - [NetBus: 12345]\n";
    print LOG "[$trojan_host] - [NetBus: 12345]\n";
}
if(!&connt($trojan_host, 10752)) {
    print "[$trojan_host] - [BitchX Backdoor: 10752]\n";
    print LOG "[$trojan_host] - [BitchX Backdoor: 10752]\n";
}
if(!&connt($trojan_host, 21554)) {
    print "[$trojan_host] - [GirlFriend: 21554]\n";
    print LOG "[$trojan_host] - [GirlFriend: 21554]\n";
}
if(!&connt($trojan_host, 1524)) {
    print "[$trojan_host] - [SunOS Backdoor: 1524]\n";
    print LOG "[$trojan_host] - [SunOS Backdoor: 1524]\n";
}
if(!&connt($trojan_host, 23456)) {
    print "[$trojan_host] - [EvilFTP: 23456]\n";
    print LOG "[$trojan_host] - [EvilFTP: 23456]\n";
}
if(!&connt($trojan_host, 6969)) {
    print "[$trojan_host] - [GateCrasher: 6969]\n";
    print LOG "[$trojan_host] - [GateCrasher: 6969]\n";
}
if(!&connt($trojan_host, 555)) {
    print "[$trojan_host] - [phAse Zero: 555]\n";
    print LOG "[$trojan_host] - [phAse Zero: 555]\n";
}
}

sub connt {
$remote = shift; $port = shift;
$iaddr = inet_aton($remote) || return 1;
$paddr = sockaddr_in($port, $iaddr);
$proto = getprotobyname('tcp');
socket(sock, PF_INET, SOCK_STREAM, $proto) || return 1;
connect(sock, $paddr) || return 1;
close sock;
return 0;
}
print;