# Read "ReadMe.txt/.html" for ...

push @plugins, 'cgi';

sub cgi {
if($debug) { print "Checking for CGI ...\n"; }
$cgi_host = shift; $x=0; $i=0;
@cgi_script=("/cgi-bin/faxsurvey","/cgi-bin/wrap","/cgi-bin/webdist.cgi",
	     "/cgi-bin/handler","/cgi-bin/pfdispaly.cgi","/cgi-bin/view-source",
	     "/cgi-bin/php.cgi","/cgi-bin/aglimpse","/cgi-bin/webgais",
	     "/cgi-bin/campas","/cgi-bin/www-sql","/cgi-bin/info2www",
	     "/cgi-bin/man.sh","/scripts/convert.bas","/cgi-bin/whois_raw.cgi",
	     "/cgi-bin/nph-test-cgi","/cgi-bin/wguest.exe","/cgi-bin/rguest.exe",
	     "/cgi-bin/dbmlparser.exe","/samples/search/queryhit.htm",
	     "/msadc/Samples/SELECTOR/showcode.asp","/cgi-bin/perl.exe",
	     "/cgi-bin/htmlscript","/carbo.dll","/cgi-bin/textcounter.pl",
	     "/cfdocs/expelval/displayopenedfile.cfm","/msadc/Samples/SELECTOR/codebrws.cfm",
	     "/iissamples/sdk/asp/docs/codebrws.asp","/ASPSamp/AdvWorks/equipment/catalog_type.asp",
	     "/AdvWorks/equipment/catalog_type.asp","/cgi-bin/w3-msql","/_vti_pvt/service.pwd",
	     "/_vti_pvt/users.pwd","/_vti_pvt/authors.pwd","/_vti_pvt/administrators.pwd",
	     "/cfdocs/expelval/sendmail.cfm","/cfdocs/expelval/exprcalc.cfm",
	     "/showfile.asp","/cfdocs/expelval/openfile.cfm","/ws_ftp.ini",
	     "/cgi-dos/args.cmd","/cgi-shl/win-c-sample.exe","/cgi-bin/passwd.txt",
	     "/cgi-win/uploader.exe","/........./autoexec.bat",
	     "/cgi-bin/rwwwshell.pl","/cgi-bin/unlg1.1","/.html/............/autoexec.bat",
	     "/cgi-bin/add_ftp.cgi","/scripts/iisadmin/ism.dll?http/dir","..\../",
	     "/cgi-bin/websendmail","/cgi-bin/AT-admin.cgi","/cgi-bin/AT-generate.cgi",
	     "/cgi-bin/jj","/cgi-bin/finger","/cgi-bin/bnbform.cgi","/cgi-bin/survey.cgi",
	     "/cgi-bin/AnyForm2","/cgi-bin/classifieds.cgi","/scripts/CGImail.exe",
	     "/search97.vts","/cgi-bin/fpexplorer.exe",
	     "/adsamples/config/site.csc","/cgi-bin/formmail.pl","/cgi-bin/w3-sql",
	     "/search","/cgi-bin/test.bat","/cgi-bin/input.bat","/cgi-bin/input2.bat",
	     "/ssi/envout.bat","/msadc/msadcs.dll","/scripts/tools/newdsn.exe","/cgi-bin/get32.exe\|dir",
	     "/cgi-bin/alibaba.pl\|dir","/cgi-bin/tst.bat\|dir","/publisher/","/.htaccess",
	     "/.htpasswd","/cgi-bin/Cgitest.exe","NOTE: Your server has been scanned for default vulnerabilities!");
@cgi_names= ("faxsurvey","wrap","webdist","handler","pfdispaly","view-source",
	     "php","aglimpse","webgais","campas","www-sql","info2www","man.sh",
	     "convert.bas","whois_raw.cgi","nph-test-cgi","wguest.exe","rguest.exe",
	     "dbmlparser.exe","queryhit.htm","showcode.asp","perl.exe","htmlscript",
	     "carbo.dll","textcounter.pl","displayopenedfile","codebrws","codebrws2",
	     "catalog_type","catalog_type2","w3-msql","service.pwd","users.pwd",
	     "authors.pwd","administrators.pwd","sendmail.cfm","exprcalc.cfm",
	     "showfile.asp","openfile.cfm","ws_ftp.ini","args.cmd","win-c-sample.exe",
	     "passwd.txt","uploader.exe","FrontPage \"..\"","rwwwshell.pl",
	     "unlg1.1","\.html","add_ftp.cgi","ism.dll","\"..\\../\" BUG","websendmail",
	     "AT-admin.cgi","AT-generate.cgi","jj","finger","bnbform.cgi","survey.cgi",
	     "AnyForm2","classifieds.cgi","CGImail.exe","search97.vts","fpexplorer.exe",
	     "site.csc","formmail.pl","w3-sql","Zeus Search",
	     "test.bat","input.bat","input2.bat","envout.bat","msadcs.dll","newdsn.exe",
	     "get32.exe","alibaba.pl","tst.bat","/publisher",".htaccess",".htpasswd",
	     "Cgitest.exe");
$remote = $cgi_host; $port = 80;
$iaddr = inet_aton($remote) || $x++;
$paddr = sockaddr_in($port, $iaddr);
$proto = getprotobyname('tcp');
socket(sock, PF_INET, SOCK_STREAM, $proto) || $x++;
connect(sock, $paddr) || $x++;
close sock;

if($x == 0) {
foreach $get (@cgi_script) {
$remote = $cgi_host; $port = 80;
$iaddr = inet_aton($remote) || $x++;
$paddr = sockaddr_in($port, $iaddr);
$proto = getprotobyname('tcp');
socket(sock, PF_INET, SOCK_STREAM, $proto) || $x++;
connect(sock, $paddr) || $x++;
send(sock, "HEAD $get HTTP/1.0\n\n", 0);
@dat=<sock>;
($ver,$code,$met) = split(/ /, @dat[0]);
if($code == 200) {
    $cgi_name_less = @cgi_names[$i];
    print "[$cgi_host] - [CGI: $cgi_name_less]\n";
    print LOG "[$cgi_host] - [CGI: $cgi_name_less]\n";
}
close sock;
$i++;
  }
 }
}
print;