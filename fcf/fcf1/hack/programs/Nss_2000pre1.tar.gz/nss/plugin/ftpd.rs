# Read "ReadMe.txt/.html" for ...

push @plugins, 'ftpd';

sub ftpd {
if($debug) { print "Checking for ftpd ...\n"; }
$ftpd_host = shift; $x=0;
$remote = $ftpd_host; $port = 21;
$iaddr = inet_aton($remote) || $x++;
$paddr = sockaddr_in($port, $iaddr);
$proto = getprotobyname('tcp');
socket(ftpd, PF_INET, SOCK_STREAM, $proto) || $x++;
connect(ftpd, $paddr) || $x++;
if($x == 0) {
while(<ftpd>) {
chomp;
    if(/wu-2.5.0\(1\)/i) {
	print "[$ftpd_host] - [WU-2.5\(1\)]\n";
	print LOG "[$ftpd_host] - [WU-2.5\(1\)]\n";
	close ftpd;
    	return;
    }
    if(/wu-2.4(1)/i) {
	print "[$ftpd_host] - [WU-2.4\(1\)]\n";
	print LOG "[$ftpd_host] - [WU-2.4\(1\)]\n";
	close ftpd;
    	return;
    }
    if(/wu-1.2(1)/i) {
	print "[$ftpd_host] - [WU-1.2\(1\)]\n";
	print LOG "[$ftpd_host] - [WU-1.2\(1\)]\n";
	close ftpd;
    	return;
    }
    if(/wu-2.4.2-academ\[BETA-1([2-8])\]/) {
	print "[$ftpd_host] - [WU-2.4.2-academ BETA 1$1]\n";
	print LOG "[$ftpd_host] - [WU-2.4.2-academ BETA 1$1]\n";
	close ftpd;
    	return;
    }
    if(/proftpd/i && /1.2.0pre([1-6])/) {
	print "[$ftpd_host] - [ProFTPD 1.2.0pre$1]\n";
	print LOG "[$ftpd_host] - [ProFTPD 1.2.0pre$1]\n";
	close ftpd;
    	return;
    }
    if(/serv-u/i && /2.3/) {
	print "[$ftpd_host] - [Serv-U 2.3]\n";
	print LOG "[$ftpd_host] - [Serv-U 2.3]\n";
	close ftpd;
    	return;
    }
    if(/serv-u/i && /2.2/) {
	print "[$ftpd_host] - [Serv-U 2.2]\n";
	print LOG "[$ftpd_host] - [Serv-U 2.2]\n";
	close ftpd;
    	return;
    }
    if(/serv-u/i && /2.0c/) {
	print "[$ftpd_host] - [Serv-U 2.0c]\n";
	print LOG "[$ftpd_host] - [Serv-U 2.0c]\n";
	close ftpd;
    	return;
    }
    if(/serv-u/i && /2.5/) {
	print "[$ftpd_host] - [Serv-U 2.5]\n";
	print LOG "[$ftpd_host] - [Serv-U 2.5]\n";
	close ftpd;
    	return;
    }
    if(/ncftp/i && /2.4.2/) {
	print "[$ftpd_host] - [NcFTP 2.4.2]\n";
	print LOG "[$ftpd_host] - [NcFTP 2.4.2]\n";
	close ftpd;
    	return;
    }
    if(/war/i && /1.65/) {
	print "[$ftpd_host] - [War FTPD 1.65]\n";
	print LOG "[$ftpd_host] - [War FTPD 1.65]\n";
	close ftpd;
    	return;
    }
    if(/war/i && /1.70/) {
	print "[$ftpd_host] - [War FTPD 1.70]\n";
	print LOG "[$ftpd_host] - [War FTPD 1.70]\n";
	close $ftpd;
	return;
    }
    if(/expressfs/i && /2.([0-9])/) {
	print "[$ftpd_host] - [ExpressFS 2.$1]\n";
	print LOG "[$ftpd_host] - [ExpressFS 2.$1]\n";
	close ftpd;
    	return;
    }
    if(/wftpd/i && /2.([34-40])/) {
	print "[$ftpd_host] - [WFTPD 2.$1]\n";
	print LOG "[$ftpd_host] - [WFTPD 2.$1]\n";
	close ftpd;
    	return;
    }
    if(/tiny/i && /0.51/) {
	print "[$ftpd_host] - [Tiny FTPd 0.51]\n";
	print LOG "[$ftpd_host] - [Tiny FTPd 0.51]\n";
	close ftpd;
	return;
    }
    if(/bisonware/i && /3.5/) {
	print "[$ftpd_host] - [BisonWare FTP Server 3.5]\n";
	print LOG "[$ftpd_host] - [BisonWare FTP Server 3.5]\n";
	close ftpd;
	return;
    }
    if(/nextftp/i && /1.82/) {
	print "[$ftpd_host] - [NextFTP v1.82]\n";
	print LOG "[$ftpd_host] - [NextFTP v1.82]\n";
	close ftpd;
	return;
    }
    if(/pftpd/i && /0.26/) {
	print "[$ftpd_host] - [PFTPD v0.26]\n";
	print LOG "[$ftpd_host] - [PFTPD v0.26]\n";
	close ftpd;
	return;
    }
close ftpd;
  }
 }
}
print;