			Narrow Security Scanner - 2000pre1
================================================================================

	1.0 About NSS
	1.1 NSS History
	1.2 NSS Author
	1.3 Disclaimer

	2.0 How to use NSS?
	2.1 Tools needed to run NSS
	2.2 How to use Subdomain Generator?
	2.3 System Recommended
	2.4 NSS Bugs

	3.0 Mirror Sites
	3.1 How to contect the author?
	3.2 Greetings

================================================================================

1.0 - About Narrow Security Scanner
-----------------------------------
Narrow Security Scanner searches for 249 default vulnerabilities on *YOUR*
server! It was programmed on the language Perl.
This script should work on all systems that supports Perl 5 or higher! The
script was tested on systems: RedHat (4.2, 5.0, 6.0), FreeBSD 3.0, OpenBSD 2.5,
Slackware 4.0 and SusE 6.1.

1.1 - Narrow Security Scanner History
-------------------------------------
I really enjoyed writing NSS. It all started in a very *HOT* summer in June.
I wanted to check my little Perl and security skills. Before NSS I was working
on NGC - Narrow CGI Check. First version of NSS (Narrow Security Scanner) was
released in June only for friends. Then they suggested to make it better. I did
it better and better. But I still had some bad nights too :). First version
searched only for 12 vulnerabilities. Before I published it I gave a copy of
NSS to ".rain.forest.puppy." aka .r.f.p. After some days I got an response from
him. He recoded it a bit and the script was running better than ever and the
size got lesser. Version 2.2 was the first public version of NSS!

1.2 - Narrow Security Scanner Author
------------------------------------
Sorry, I will not give you my real name and my credit card number ;)

1.3 - Disclaimer
----------------
The author "Narrow" is not responsible for any damage you do or problems you
get with this script. The script is 100% Virus/Trojan FREE! You can use/copy
this script unless these comments stay. Before you upload/send this script to
a ftp/web server, contact the author first. Scanner for admins who want to
check their network for vulnerabilities !!! 

	    !!!THIS SCRIPT IS FOR EDUCATIONAL USE ONLY!!!

                                                           

2.0 - How to use NSS?
---------------------
It's very easy to use NSS. To run it just type "perl scanner" in the directory.
NOTE: If it is packed, unpack it! :)
NSS usage: (perl) ./scanner <host file> <log file>

<host file> - It is a file with hosts to scan. An example host file is attached
	      with the script.
<log file > - File where all results will be recorded.

Before using NSS you need to configure it. Configuration file is "nss.conf".
By default the script scans for *ALL* vulnerabilities. NOTE: Enabling all will
slow down your Internet connection! But who cares, you will scan your local
network, right?

2.1 - Tools needed to run NSS
-----------------------------
Tools needed: Perl 5 or higher, dig and rpcinfo.
If you don't have dig. Set $scan_named to ZERO ($scan_named = 0).
If you don't have rpcinfo. Set $scan_rcp to ZERO ($scan_rcp = 0).

2.2 - How to use Subdomain Generator?
-------------------------------------
If you have many other subdomains, you can use Subdomain Generator to write
them all to a file. It can be used for making a host file. To run this script
type: "(perl) ./generate". It should work on systems that supports Perl 5 or
higher. The script is attached with NSS.
NOTE: Subdomain generator uses the program "host" to get all the subdomains!
Windows users can't use it!

Subdomain Generator usage: (perl) ./generate <host> <log file>

<host> - Enter your host here, like: host.com (no www before it!)
<log file> - File where all subdomains will be recorded.

2.3 - System Recommended
------------------------
System....: Any that supports Perl 5 or higher!
Memory....: So many to run an Unix machine.
Free Space: 100 Kb
Connection: 28,800 or higher.

2.4 - Narrow Security Scanner Bugs
----------------------------------
1. - If you are logged as root try: "perl scanner /etc/(passwd or shadow)
     blah.log


3.0 - Mirror Sites
------------------
1. http://www.legion2000.cc
2. http://www.wiretrip.net/rfp/
3. http://packetstorm.securify.com
4. http://www.securityfocus.com


3.1 - How to contact the author? 
--------------------------------
E-Mail: narr0w@legion2000.cc

3.2 - Greetings
---------------
nikel-com, _shocker_, tf8, wider, sid, sidux, _GrYpHoN_, .rain.forest.puppy.,
gov-boi, Condor, Packet Storm, Security Focus (BUGTRAQ), Hacker News, Zero,
Josh, cripto AND who wanted to be greeted :)
