


           This zip file contains Vbswg.exe,whitch is the Vbs worm generator ver 2b
    made by [K].But this copy is undetectable by AV,till now 13/11/2002.I've packed the
    original version and this is for U.But the generated worms are being found by AV's.So
    in this zip file I've also put a prog call vbsenc.exe,and U 'll have to use it to
    encrypt the vbs worms createsd with [K] 's kit.Vbsenc.exe file is my creation,and it can
    be used in ANY vbs file,in order to decrypt it.Read the Help of vbsenc.exe file for more
    details.Be carefull using vbsenc.exe and this new [K] 's kit I've produced.

     
             ReGards,
              KaGra,member of Brigada ocho virii Group

    
    Contact me at: roallercoaster1@yahoo.com
