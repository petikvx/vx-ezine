public class victim {

    public static void main(String argv[]) {
        System.out.println("I am not the victimiser,");
        System.out.println("I am the victim.");
    }

}
