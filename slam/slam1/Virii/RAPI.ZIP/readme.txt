Virus decrypted by 
    ______            _____            _____                    _____      
   /  __  \  __  __  /  __ \  _____   /  __ \    _____ ______  /  __ \  ___ _
  /  /_/  / / / / / /  / / / /  __ \ /  / /  \  / __ //  ___/ /  / / / /  // \
 /  / /  / / /_/ / /  /_/ / /  /_/ //  /_/   / / /_///  _/_  /  /_/ / /  _~  /
/__/ /__/,/_____/ /__/ \  > \_____//________/ /_//_//_____/ /  ____/ /__//__/
====*****{=========-====\/=====[ Bonnet@defiant.ILF.NET ]===\_/===============
         '            Web Page = www.ilf.net/AURODREPH/virus.htm

-----BEGIN PGP PUBLIC KEY BLOCK-----
Version: 2.7.1

mQBtAzKH0rYAAAEDAL0VC29QvNER+LBp+ov1OBce8lrLwli8aHNQYq6aFA+cyVOq
xc61IDBsi/37AaNmV1/eczN8sX2UAMVCTnLxHtMsWHky67Ct0/9NcMBtu283vaWo
2kMJIS9zoGyyflEFbwAFEbQeQVVST0RSRVBIPGJvbm5ldEBpc2FyYS5pcGwuZnI+
=DFDU
-----END PGP PUBLIC KEY BLOCK-----
