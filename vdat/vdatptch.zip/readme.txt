
                          VDAT Release 2.000.1
                          ====================

By using a popular patch utility this edition of VDAT is the
first version that is "patchable" from a previous version of
VDAT. For now it will only work when updating VDAT 2.000.0 to
2.000.1, but maybe later I will release patches to older versions
of VDAT. The "patch" will decrease the download/online time
necessary to get a new VDAT release and should accomodate those
that have been complaining about the size of VDAT. I would like
to have some feedback/ideas on this new feature, maybe other uses
of this feature are possible.

VDAT distribution blues (continued):

I have had, read and heard many reactions to my decision to limit
the distribution of VDAT. Some were understanding, some were
angry and most were disappointed. Many misunderstood the intent
of my decision but since I can not explain it any better than I
did in the last release I am not going to explain it all over
again. Suffice to say that the limitation on distribution is for
the general "Gee-see-what-I-found" user only, for many not much
will change. Those of you that read this are welcome to this new
edition of VDAT and I hope you will find it useful. I have no
illusions about the issued key files being kept confidential, I
can only ask you to keep the file to yourself, there is no way I
can force you.

VDAT inclusion parameters:

The choice of subjects and the decisions on what to include in
VDAT are getting more blurred every day. Not only is size a
consideration but also the situation that more and more
activities in the VX scene are becoming mixed with non-VX
matters.

Hacking, cracking and computer viruses are getting more and more
interconnected, VX groups are widening their range of interests
(ASM, Cybernetic Crew, UCSI, ZeroGravity etc.), hacking groups
are expanding in VX related subjects (Net Rage Gerrilleros, FCF,
BHA, Top Device E-zine) and last but not least AV companies are
supporting detection of not just viruses but the wider phenomenon
called "malware". The enormous increase in the number of
"backdoors", "trojans" and other "security tools" has forced
these companies to detect these utililties. Many virus
collections are cluttered with these non-viruses just because
they are detected by AV sofware. Contrary to fully functional and
viable "single file" viruses most samples that are ID'd as a
"backdoors" are not functional without any of the accompanying
files included in the originally distributed archive. The
detected software thus becomes "cripled" and is just some binary
code that some AV software generate "hits" on.

Many so called "pro-VX" websites are muddying the waters by also
including "backdoor" and "trojan" material. I have the impression
that some webmasters don't even know the difference between these
files and functional viruses. There are too many mixups in
terminology, even in the scene itself. (A backdoor is not a virus
although viruses can theoretically have backdoor features, a
trojan is not a virus although a virus can be distributed as a
trojan or can have a trojan as payload). I have no intention of
including any "backdoor", "trojan" or other non-virus related
material in future releases of VDAT. Although for trading
purposes I had to "bow to the majority" and include these
"backdoor" and "trojan" hits in my virus collection, I will try
to keep VDAT as "clean" as possible.

I make subjective choices on what to enter in the "Engines &
Tools" section. Many viruses contain polymorphic or mutation
routines. Some of these routines are portable to other viruses
and are called "engines", some routines are so embedded in a
virus that they are not portable without major modifications.
Basically all "Engines & Tools" that are in some way named by
their authors will be included in VDAT. Some "engines" that might
be portable but are not named will not be included in VDAT since
there is no effective way to identify or refer to these properly
(eg polymorphic routines or engines used in viruses such Natas,
Cocaine etc.)

  "People are cranking-out poly engines like maniacs, just so
  Cicatrix can shove yet another 3 letter acronym on his Engine
                          list" / T-2000"

Judging from this quote I'm part of some large "cause-and-effect"
loop. I find it hard to believe VDAT is the reason people program
polymorphic engines or other virus related utilities. Some might
spend a little extra time naming their creations just so the name
"sounds" right (e.g. MeDriPolEn) but I don't think an entry in
VDAT is a goal in creating/developing such routines.

Future of VDAT:

As you have noticed it has taken 4 months for a new VDAT release
to appear. Personally I kind of like this interval since it
allows for some time to gather new information (there are often
extended periods of inactivity in the VX scene) and people don't
have to download 8+ Mb's that contain just minor updates. I'm
still thinking about releasing an uncompiled HTML version (easier
and smaller updates) but I have not made up my mind yet. Also
there have been (for now minor) lapses in my own motivation to
continue this project (often synchronous with periods of
inactivity in the scene) but I think there still is some kind of
future for VDAT.

Cicatrix
May 2000

                             Acknowledgements:
                             =================

For more information about the past, present and future of VDAT please read
my "Editorial" linked on VDAT's main page.

I'd like to thank those that have contributed and still contribute to my
collection and those that have provided information for use in VDAT.

         In alphabetical order:

         - 1nternal
         - Anti-State Tortoise
         - Aurodreph
         - Bayros
         - Billy Belceb�
         - Bozo
         - Chili
         - Cryotek
         - Darkbyte
         - Dark Fiber
         - Dark Killer
         - Dark Knight
         - Darkman
         - Darkside
         - D.G. (Italy)
         - Dirty Nazi
         - Duke (SMF)
         - Evil Avatar
         - Evul
         - Executioner
         - Foxz
         - Glitch
         - God@rky
         - Gothmog
         - Griyo
         - Horny Toad
         - Icebreaker
         - Jack T. Ripper
         - jackie twoflower
         - Jerk1N
         - JHB
         - Knight Of Virus
         - Knowdeth
         - Kronos
         - Landing Camel
         - LovinGod
         - Lord Arz
         - LordDark
         - Lord Julius
         - Lord Natas
         - Lucifer Messiah
         - Methyl
         - MGL
         - Mister Sandman
         - Neophyte
         - Nightmare Joker
         - Nucleii
         - Omega
         - Opic
         - Phreakx
         - Poltergeist
         - Putoksa Kawayan
         - Pyro
         - Owl
         - Q The Misanthrope
         - Recoder
         - RedArc
         - Reptile
         - Rhape79
         - Sepultura
         - Shadow Seeker
         - Silver Surfer AKA ...
         - Slagehammer
         - Spanska
         - Spooky
         - Stealth Warrior
         - Stormbringer
         - Tally
         - Talon
         - Techno Phunk
         - The Unforgiven
         - Ultras
         - Vecna
         - VEiN
         - VicodinES
         - Virogen
         - Virtual Daemon
         - VirusBuster
         - WaveFunc
         - Zhuge Jin

and quite a few I'm sure don't want to be mentioned by name or
handle ;-) (you know who you are!) or some that I forgot (my
apologies).
