#include "../k2common.h"

#define		ID_EDIT			100
#define		ID_STATIC		101
#define		ID_BUTTON		102
#define		ID_TV			103
#define		ID_STATUS		104
#define		ID_BUTTON_UP	110
#define		ID_BUTTON_DOWN	111
#define		ID_BUTTON_RUN	112
#define		ID_BUTTON_DEL	113
#define		ID_ENAME		114
#define		ID_BUTTON_CLEAN 115

#define		ID_STATIC_R		120
#define		ID_EDIT_R		121
#define		ID_BUTTON_R		122

#define		ID_STATIC_U		130
#define		ID_EDIT_U		131
#define		ID_BUTTON_U		132

#define		UM_ASYNCEND		WM_USER+1

#define		IDM_EXPAND		1000
#define		IDM_UNSEEN		1001
#define		IDM_DOWNLOAD	1002
#define		IDM_DELETE		1003
#define		IDM_RUN			1004

#define		ID_LISTBOX		140
