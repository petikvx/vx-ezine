
#define		ID_STATIC1		100
#define		ID_EDIT1		101
#define		ID_BUTTON1		102

#define		ID_STATIC2		103
#define		ID_EDIT2		104
#define		ID_BUTTON2		105

#define		ID_INFECT		106
#define		ID_INFO			107
