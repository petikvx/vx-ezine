blueEbola's Opcode tracer

 All directions for using this utility are in opcode.asm.  The compiled
copy has an int 3 (0CCh byte) breakpoint in the beginning, so you
can see how to use it.  You can use this source code freely (just put
me name in the source and im fine :)

                                 -blueEbola