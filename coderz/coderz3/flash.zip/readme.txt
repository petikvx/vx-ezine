Welcome to the human race!


DISCLAIMER:
===========
If you use this demo to create a malicious movie (.swf, .spl or .exe)
and/or distribute it to any system where it does not belong
you alone will be responsible for your actions.
This demo is strictly intended for educational purposes only.


Files Included:
===============
Here's a brief explanation of the demo files:

virus.exe       - Not a virus! It's really debug.exe but renamed for testing purposes.
host.swf        - Colorful neutrons orbiting all around with their commet like tail.
virhost.swf     - The result of merging virus.exe/host.swf together!
flashpla.exe    - The unpatched Flash 5 standalone player.
flash.asm       - Source code. (plus important info on 'how it works')
flash.exe       - Binary code. (main trojanizer!)
swf.asm         - Source code. (bonus material: swf/lfm-926)
readme.txt      - You're reading it. ;)


To run:
=======
Simply type: FLASH.EXE


Note:
=====
VIRHOST.SWF can be converted to VIRHOST.EXE using the 'Create Projector' 
menu item from an unpatched (flashpla.exe) windows Flash 5 standalone player.


Personal Note:
==============
At least users can now watch a pretty graphics movie while the trojan goes to work.
Certainly more entertaining than watching the Hard Disk light flickering on/off. ;)


Enjoy!

