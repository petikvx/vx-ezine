The WalruS Visual Basic Virus Generator (VBVx)

The WalruS Visual Basic Virus Generator is a very easy to use virus generator for creating Visual Basic viruses for use with VB5 and above.
To use VBVX just run the VBVX.exe file provided in this Zip file. 

VBVX requires VB runtimes 6 to Work. Should VBVX not work, try downloading and installing the runtimes from http://dcanet.softseek.com/Utilities/VBRUN_and_other_DLLs_and_Runtime_Files/Review_19823_index.html

Currently VBVx has the following virus options.

Virus Details: Virus name, Author, Vx Marker, Comments (Optional).
Infection Method: Infect Current Dir Files, Infect Files As They Are Run.
Payload: None, CD Tray Madness, Message box, Crash Windows, Delete *.* Current Dir, Delete *.* Windows Dir.
Payload Trigger: None, On Every Run, Random, By Date.
About VBVX: Mail WalruS, Visit The WalruS Homepage.
Exit.

How it works: The virus source code will be created in a directory of the same name as the virus which is saved in the same directory as what VBVX is being ran from. The virus source code needs to know how large it is in order to replicate correctly. After the virus source code has been created for the first time VBVX will ask you to enter the compiled size of the virus. To find this out either launch Visual Basic manually and compile the source code, or hit "Launch Source In VB" which should do the same automatically. If you intend to pack the finished virus then do this now and enter the compiled size of the virus exe file in the text box provided. Next shut down Visual Basic and hit continue on VBVX. Your virus will be recompiled containing the virus compiled size in its source code. This source code is now complete and ready to compile into a working virus.

Every option has an associated help button that explains the options aim.

VBVX has an extras screen where the following can be done:-

Drop A WalruS Virus : Drop a WalruS virus Lennon, Neo.

Scattered throughout VBVX are hidden secrets and funny things just for fun :-)

VBVX was designed and tested initially on Windows XP with Visual Basic 5 & 6.

For Any Comments, Questions Or Bugs Contact WalruS Direct Below.

WalruS@iamit.com
http://walrus.up.to/