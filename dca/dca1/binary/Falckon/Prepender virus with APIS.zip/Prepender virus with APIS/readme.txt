This is a sample of prepender virus made in VB, just with APIS!
is very slow...
infect's a goat in c:\ (Goat.exe)
binary: Prepender by Flckon.exe