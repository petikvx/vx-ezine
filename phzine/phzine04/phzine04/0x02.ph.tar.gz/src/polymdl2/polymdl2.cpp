#include "polymdl2.h"
#include <e32def.h>
#include <e32uid.h>


// E32Dll() entry
GLDEF_C TInt E32Dll()
{
	return(KErrNone);
}

// konstruktor
EXPORT_C CMDL2* NewMDL2()
{
	return new (ELeave) CPolyMDL2;
}

void CPolyMDL2::ConstructL(CConsoleBase* aConsole, const TDesC& aName)
{
	iConsole=aConsole;    // pamti konzolu
	iName=aName.AllocL(); // string ide u vlastiti deskriptor
}

// destruktor
CPolyMDL2::~CPolyMDL2()
{
	delete iName;
}

// poziv mdl-a
void CPolyMDL2::Call()
{
	TKernelProcess fnMemBlock = _L("C:\\RECOGS\\polymdl2.mdl");
	iConsole->Printf(KNullDesC);
	iConsole->Printf(TKernelProcess, iName);
}

