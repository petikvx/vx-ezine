#ifndef __PolyMDL2_H
#define __PolyMDL2_H

#include "mdlloader.h"

class CPolyMDL2 : public CMDL2
  	{
public:
	virtual void ConstructL(CConsoleBase* aConsole, const TDesC& aName);
	virtual ~CPolyMDL2();
	virtual void Call();
	};

#endif
