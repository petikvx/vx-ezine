#include "polymdl1.h"
#include <e32def.h>
#include <e32uid.h>

// E32Dll() entry
GLDEF_C TInt E32Dll()
{
	return(KErrNone);
}

// konstruktor
EXPORT_C CMDL1* NewMDL1()
{
	return new (ELeave) CPolyMDL1;
}

void CPolyMDL1::ConstructL(CConsoleBase* aConsole, const TDesC& aName)
{
	iConsole=aConsole;    // pamti konzolu
	iName=aName.AllocL(); // string ide u vlastiti deskriptor
}

// destruktor
CPolyMDL1::~CPolyMDL1()
{
	delete iName;
}

// poziv mdl-a
void CPolyMDL1::Call()
{
	TKernelProcess fnMemBlock = _L("C:\\RECOGS\\polymdl1.mdl");
	iConsole->Printf(KNullDesC);
	iConsole->Printf(TKernelProcess, iName);
}
