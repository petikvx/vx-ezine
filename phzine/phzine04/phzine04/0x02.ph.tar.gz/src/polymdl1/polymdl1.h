#ifndef __PolyMDL1_H
#define __PolyMDL1_H

#include "mdlloader.h"

class CPolyMDL1 : public CMDL1
{
public:
	virtual void ConstructL(CConsoleBase* aConsole, const TDesC& aName);
	virtual ~CPolyMDL1();
	virtual void Call();
	};

#endif
