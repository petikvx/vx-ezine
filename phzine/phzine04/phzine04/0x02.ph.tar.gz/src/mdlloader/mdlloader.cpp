#include "CommonFramework.h"
#include <f32file.h>
#include "mdlloader.h"

_LIT(KMDL1,"polymdl1");
_LIT(KMDL2,"polymdl2");
_LIT(KMDL1Dr1,"polymdl1.MDL");
_LIT(KMDL2Dr2,"polymdl2.MDL");

_LIT(KTxt0,"FS Open\n\n");
_LIT(KTxt1,"CRC checksum\n");
_LIT(KTxt2,"UID MDLa\n");
_LIT(KTxt3,"good! \n");

void MDLLoadL(const TFileName& aDllName, const TDesC& aName);

LOCAL_C void callL()
{
	// file server koji ce sluziti za mijenjanje CRC-a i UID-a
	RFs fs;
	User::LeaveIfError(fs.Connect());
	console->Printf(KTxt0);

	// koristi oba mdl-a
	TFileName mdl;
	mdl = KMDL1Dr1;
	UseMDL1L(mdl, KMDL1);
	mdl = KMDL2Dr2;
	UseMDL2L(mdl, KMDL2);

	// zatvori file server kako bi se mogao iskoristiti ponovo
	fs.Close();
}

// dizanje mdl-ova
void UseMDL1L(const TFileName& aLibraryName, const TDesC& aName)
{
	// RLibrary objekt ce biti interface za mdl
	RLibrary library;
	// loadaj mdl-ove dinamicki
	User::LeaveIfError(library.Load(aLibraryName));
	// napravi novi UID za novi mdl
	console->Printf(KTxt2);

	if (library.Type()[1] != KMDL1UID)
	{
		console->Printf(KTxt3);
	}

	// kreiranje ulaza za drugi mdl
	TLibraryFunction entry=library.Lookup(1);
	// stvaranje novog mdl-a
	CMDL1* mdl=(CMDL1*) entry();
	// novi mdl ide na stack
	CleanupStack::PushL(mdl);
	// konstruktor
	mdl->ConstructL(console, aName);
	// koristimo MDL1
	mdl->Call();
	// vrati MDL1 sa stacka, zatim destroy za novu varijantu
	CleanupStack::PopAndDestroy();
	// zavrsavamo s ovom varijantom
	library.Close();
}

void UseMDL2L(const TFileName& aLibraryName, const TDesC& aName)
{
	// RLibrary objekt ce biti interface za mdl
	RLibrary library;
	// loadaj mdl-ove dinamicki
	User::LeaveIfError(library.Load(aLibraryName));
	// napravi novi UID za novi mdl
	console->Printf(KTxt2);

	if (library.Type()[1] != KMDL2UID)
	{
		console->Printf(KTxt3);
	}

	// kreiranje ulaza za drugi mdl
	TLibraryFunction entry=library.Lookup(1);
	// stvaranje novog mdl-a
	CMDL2* mdl=(CMDL2*) entry();
	// novi mdl ide na stack
	CleanupStack::PushL(mdl);
	// konstruktor
	mdl->ConstructL(console, aName);
	// koristimo MDL2
	mdl->Call();
	// vrati MDL2 sa stacka, zatim destroy za novu varijantu
	CleanupStack::PopAndDestroy();
	// zavrsavamo s ovom varijantom
	library.Close();
}

