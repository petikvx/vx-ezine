#include <e32cons.h>

#ifndef __Mdlloader_H
#define __Mdlloader_H

const TInt KMdlloaderUidValue=0x10000000;
const TUid KMdlloaderUid={KmdlloaderUidValue};

class CMdlloader : public CBase
{
public:
	virtual void ConstructL(CConsoleBase* aConsole, const TDesC& aName)=0;
	virtual void Call();
protected:
	CConsoleBase* iConsole;
	HBufC*        iName;
};

#endif
