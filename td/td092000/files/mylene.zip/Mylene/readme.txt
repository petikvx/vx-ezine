Win32.Libertina dissembling
~~~~~~~~~~~~~~~~~~~~~~~~~~~

