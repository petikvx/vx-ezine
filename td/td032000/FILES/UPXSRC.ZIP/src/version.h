#define UPX_VERSION_STRING      "0.99.1"
#define UPX_VERSION_DATE        "Feb 29th 2000"
