JULIET.MRC II (B) File Information:

JULIET2.EXE - Fully compiled worm
Create.EXE  - Juliet and icon joiner
Juliet.ico  - Juliet's icon
Juliet.pas  - Juliet's pascal code
Juliet.txt  - Juliet's documentation (fer viewing in FC viewer)